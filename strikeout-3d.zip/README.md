# STRIKEOUT 3D

Fast first-person arena shooter for phones and desktop browsers (Godot 4.4 Web export, plays on GitHub Pages).

## Publish it (from your phone)
1. Upload `strikeout-3d.zip` to your repo root (**Add file -> Upload files**).
2. Put `build.yml` at `.github/workflows/build.yml` (it replaces your old workflow).
3. **One time:** repo Settings -> Pages -> Build and deployment -> Source = **GitHub Actions**.
4. *(Optional, for sound)* Settings -> Secrets and variables -> Actions -> `ELEVENLABS_API_KEY`.
5. Actions -> run the workflow. Your game appears at `https://<you>.github.io/<repo>/`.

The first run also **deletes the old anime game's voice + sound-effect mp3s and its old zip from your repo**.
Godot generates `index.html` itself. Sound effects + the "STRIKEOUT!" announcer are generated once with ElevenLabs
and committed to `assets/audio/` (never regenerated unless you edit `data/audio.json`). Character voice lines are off.

## Controls
Touch: left stick move, drag right side to aim, FIRE, AIM/scope, JUMP, RELOAD, SWAP, PICK UP (near a table).
Desktop: WASD, mouse (click to capture), LMB fire, RMB aim, R reload, Q swap, E pick up, Space jump, Tab scoreboard.

## Modes
- **PLAY** searches online for ~8 s (Trystero peer-to-peer, no server), then offers Play vs Bots.
- **Friend Duel**: both enter the same room code.
- Score: first to 15 points. Headshots, long shots, air shots and no-scope marksman shots give STRIKEOUT bonus points (ACE: double).

## Assets
All 3D assets are real downloaded models + their original textures (Godot TPS demo: robots, containers, crates, barriers, floor and wall pieces; weapon pack: AK-47, shotgun, sniper, pistol). Nothing is built from primitives in code.
The first CI import also compresses the textures for phones (`tools/prepare_textures.py`).

## Performance
Compatibility/WebGL2, no post-processing, props baked into a few meshes, three render resolutions in Settings (480p / 720p / 900p+shadows).

## Credits
See `CREDITS.md`. All 3D assets (characters, weapons, props, floor and wall pieces) are real downloaded models, nothing is built from primitives in code.
Networking: Trystero (MIT), bundled in `web/strikeout_net.js`.
