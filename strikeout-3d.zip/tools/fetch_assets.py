#!/usr/bin/env python3
"""Downloads the character models listed in tools/assets.json (run on GitHub's servers by the workflow).

Skips files that already exist. Exits with code 1 if the required download fails, so the build
never silently ships without its model.
"""
import json
import os
import struct
import sys
import time
import urllib.request

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def download(url: str, dest: str, retries: int = 4) -> bool:
    for attempt in range(1, retries + 1):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "strikeout-build"})
            with urllib.request.urlopen(req, timeout=120) as r, open(dest + ".part", "wb") as f:
                while True:
                    chunk = r.read(1 << 16)
                    if not chunk:
                        break
                    f.write(chunk)
            os.replace(dest + ".part", dest)
            return True
        except Exception as e:  # noqa: BLE001
            print(f"  attempt {attempt}/{retries} failed: {e}")
            time.sleep(2 * attempt)
    return False


def main() -> int:
    with open(os.path.join(ROOT, "tools", "assets.json"), encoding="utf-8") as f:
        manifest = json.load(f)
    failed = 0
    for a in manifest["assets"]:
        dest = os.path.join(ROOT, a["dest"])
        os.makedirs(os.path.dirname(dest), exist_ok=True)
        if os.path.exists(dest) and os.path.getsize(dest) >= a.get("min_bytes", 1):
            print(f"[cached]   {a['name']} ({os.path.getsize(dest) // 1024} KB)")
        else:
            print(f"[download] {a['name']} <- {a['url']}")
            if download(a["url"], dest) and os.path.getsize(dest) >= a.get("min_bytes", 1):
                print(f"           ok, {os.path.getsize(dest) // 1024} KB  ({a['license']})")
            else:
                print(f"::error::could not download {a['name']}")
                failed += 1
                continue
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
