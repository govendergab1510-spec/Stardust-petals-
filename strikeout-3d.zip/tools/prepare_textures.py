#!/usr/bin/env python3
"""Run after the first Godot import: makes the downloaded textures phone-friendly
(lossless WebP, mipmaps, size limit, normal-map flag; fast to import and light on download) by patching their .import files. Godot then re-imports them."""
import glob, os, re, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BIG = ("set_asphalt", "container", "red_robot_albedo")  # 1024 px, everything else 512 px
changed = 0
for f in glob.glob(os.path.join(ROOT, "assets", "textures", "*.png.import")):
    name = os.path.basename(f)
    s = open(f, encoding="utf-8").read()
    limit = 1024 if any(b in name for b in BIG) else 512
    o = s
    s = re.sub(r"^compress/mode=.*$", "compress/mode=0", s, flags=re.M)
    s = re.sub(r"^mipmaps/generate=.*$", "mipmaps/generate=true", s, flags=re.M)
    s = re.sub(r"^process/size_limit=.*$", f"process/size_limit={limit}", s, flags=re.M)
    s = re.sub(r"^compress/normal_map=.*$", "compress/normal_map=%d" % (1 if "normal" in name else 0), s, flags=re.M)
    if s != o:
        open(f, "w", encoding="utf-8").write(s)
        changed += 1
print(f"patched {changed} texture import files")
