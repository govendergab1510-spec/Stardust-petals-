class_name GunModel
extends RefCounted
## Real low-poly weapon models (pistol, AK-47, shotgun, sniper) from the downloaded Weapons.fbx.
## Barrel points down -Z, origin near the grip. Node "Muzzle" marks the barrel tip.

const PATH := "res://assets/models/weapons/Weapons.fbx"
const NODE := {"pistol": "Pistol", "rifle": "Gun-AK47", "shotgun": "ShotGun", "sniper": "Sniper"}
static var _src: Node3D


static func build(id: String, scale := 1.0) -> Node3D:
	var root := Node3D.new()
	if _src == null and ResourceLoader.exists(PATH):
		_src = (load(PATH) as PackedScene).instantiate()
	var muzzle := Marker3D.new()
	muzzle.name = "Muzzle"
	root.add_child(muzzle)
	if _src == null or not NODE.has(id):
		muzzle.position = Vector3(0, 0.03, -0.5)
		return root
	var src := _src.find_child(NODE[id], true, false) as MeshInstance3D
	var mi := MeshInstance3D.new()
	mi.mesh = src.mesh
	mi.scale = src.scale
	mi.rotation = src.rotation
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	# the FBX is authored with the barrel along +X: pivot turns it to -Z
	var pivot := Node3D.new()
	pivot.rotation.y = PI * 0.5
	root.add_child(pivot)
	pivot.add_child(mi)
	var bb: AABB = Transform3D(Basis.from_euler(src.rotation) * Basis.from_scale(src.scale), Vector3.ZERO) * src.mesh.get_aabb()
	# put the grip (about 40 % from the rear) at the origin
	mi.position = -Vector3(bb.position.x + bb.size.x * 0.4, bb.get_center().y + bb.size.y * 0.15, bb.get_center().z)
	muzzle.position = Vector3(0, bb.size.y * 0.15, -(bb.size.x * 0.6))
	root.scale = Vector3.ONE * scale
	return root
