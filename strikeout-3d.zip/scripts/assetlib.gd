class_name AssetLib
extends RefCounted
## Loads real downloaded models once and hands out their meshes by name prefix.

const PROPS := "res://assets/models/Props.glb"
const STRUCT := "res://assets/models/Structure.glb"
static var _scenes := {}
static var _meshes := {}


static func scene(path: String) -> Node3D:
	if not _scenes.has(path):
		if not ResourceLoader.exists(path):
			return null
		var inst := (load(path) as PackedScene).instantiate()
		apply(inst)
		_scenes[path] = inst
	return _scenes[path]


## {"mesh": Mesh, "aabb": AABB, "xf": Transform3D} for the first MeshInstance3D whose name starts with prefix.
static func find(path: String, prefix: String) -> Dictionary:
	var key := path + "|" + prefix
	if _meshes.has(key):
		return _meshes[key]
	var res := {}
	var root := scene(path)
	if root:
		for c in root.get_children():
			if c is MeshInstance3D and String(c.name).begins_with(prefix) and (c as MeshInstance3D).mesh:
				var mi := c as MeshInstance3D
				res = {"mesh": mi.mesh, "aabb": mi.mesh.get_aabb()}
				break
	_meshes[key] = res
	return res


const PALETTES := {
	"prop_container": [Color(0.86, 0.38, 0.12), Color(0.15, 0.42, 0.78), Color(0.2, 0.52, 0.32), Color(0.72, 0.16, 0.16), Color(0.88, 0.72, 0.2), Color(0.55, 0.58, 0.64)],
	"prop_cargobox": [Color(0.62, 0.5, 0.32), Color(0.4, 0.46, 0.32), Color(0.66, 0.54, 0.36)],
	"prop_barrel": [Color(0.75, 0.15, 0.12), Color(0.15, 0.4, 0.75), Color(0.9, 0.75, 0.15)],
	"prop_barrier": [Color(0.92, 0.78, 0.12)],
	"prop_transitbarrierdirection": [Color(0.92, 0.78, 0.12)],
	"prop_pellet": [Color(0.55, 0.4, 0.25)],
	"prop_gas": [Color(0.8, 0.2, 0.15)],
	"scificar": [Color(0.4, 0.48, 0.58)],
	"prop_reactorcylinder": [Color(0.3, 0.55, 0.7)],
	"FLOOR": [Color(0.2, 0.22, 0.28)],
	"hallreactor": [Color(0.16, 0.18, 0.24)],
	"hall_": [Color(0.42, 0.47, 0.56), Color(0.36, 0.4, 0.5)],
	"Reactor": [Color(0.55, 0.62, 0.7)],
	"prop_floodlight": [Color(0.7, 0.72, 0.76)],
	"prop_steelbeam": [Color(0.8, 0.45, 0.15)],
	"prop_cargolift": [Color(0.75, 0.6, 0.2)],
}


## Palette colour for a prop (the downloaded meshes ship untextured, so they are tinted per type).
static func tint(prefix: String, i: int) -> Color:
	for k in PALETTES:
		if prefix.begins_with(k):
			var arr: Array = PALETTES[k]
			return arr[i % arr.size()]
	return Color(0.5, 0.55, 0.62)


static func make_mat() -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.vertex_color_use_as_albedo = true
	m.vertex_color_is_srgb = true
	m.metallic = 0.15
	m.roughness = 0.7
	m.specular_mode = BaseMaterial3D.SPECULAR_DISABLED
	m.cull_mode = BaseMaterial3D.CULL_DISABLED  # some structure pieces (floor slabs) face down
	return m


# ---- the downloaded meshes ship without materials: re-apply the original textures by material name ----
const TEX := {
	"container2": ["container2_albedo", "container2_normal"], "container3": ["container3_albedo", "container3_normal"],
	"container4": ["container4_albedo", "container4_normal"], "mid_cargo_box": ["mid_cargo_box_albedo", "mid_cargo_box_normal"],
	"reactor_cylinder": ["reactor_cylinder_albedo", "reactor_cylinder_normal"], "scifi_car": ["scificar_albedo", "scificar_normal"],
	"floor_grate_wholes": ["floor_grate_wholes_albedo", "floor_grate_wholes_normal"], "set_asphalt": ["set_asphalt_albedo", ""],
	"tile_painted_gun_metal": ["tile_painted_gun_metal_albedo", "tile_painted_gun_metal_normal"],
	"tile_rivet_panels": ["tile_rivet_panels_albedo", "tile_rivet_panels_normal"],
	"tile_scifi_floor_panel": ["tile_scifi_floor_panel_albedo", "tile_scifi_floor_panel_normal"],
	"tile_default_metal": ["tile_default_metal_albedo", "tile_default_metal_normal"],
	"tile_anti_slip_metal": ["tile_anti_slip_albedo", "tile_anti_slip_metal_normal"], "tile_metal_pillars": ["tile_metal_pillars_albedo", ""],
	"column": ["column_albedo", "column_normal"], "EvilRobo": ["red_robot_albedo", "red_robot_normal"],
}
const EMIT := {
	"flat_emitter_orange": Color(1.0, 0.5, 0.1), "flat_emitter_orange_dull": Color(0.8, 0.4, 0.1), "flat_emitter_white": Color(1, 1, 1),
	"flat_emitter_powerful_white": Color(1, 1, 1), "flat_emitter_blue": Color(0.3, 0.6, 1.0), "flat_emitter_red": Color(1, 0.2, 0.2),
	"cycles_glow_orange": Color(1.0, 0.5, 0.1), "reactor_emitter": Color(0.3, 0.7, 1.0), "robotemitter": Color(0.3, 0.8, 1.0),
}
static var _mats := {}


static func _tex(n: String) -> Texture2D:
	var p := "res://assets/textures/%s.png" % n
	return load(p) as Texture2D if (n != "" and ResourceLoader.exists(p)) else null


static func _material(name: String) -> Material:
	if _mats.has(name):
		return _mats[name]
	var m: Material = null
	if TEX.has(name):
		var sm := StandardMaterial3D.new()
		sm.albedo_texture = _tex(TEX[name][0])
		var nt := _tex(TEX[name][1])
		if nt:
			sm.normal_enabled = true
			sm.normal_texture = nt
			sm.normal_scale = 0.8
		sm.metallic = 0.25
		sm.roughness = 0.7
		sm.specular_mode = BaseMaterial3D.SPECULAR_DISABLED
		m = sm
	elif EMIT.has(name):
		var em := StandardMaterial3D.new()
		em.albedo_color = Color(0.05, 0.05, 0.05)
		em.emission_enabled = true
		em.emission = EMIT[name]
		em.emission_energy_multiplier = 0.55
		m = em
	elif name.begins_with("tile_") or name.begins_with("flat_") or name.begins_with("trim_") or name in ["train_texture", "train_inner", "scifi_car_glass", ""]:
		var fm := StandardMaterial3D.new()
		fm.albedo_color = Color(0.1, 0.11, 0.13) if "black" in name or "glass" in name else Color(0.13, 0.14, 0.17)
		fm.metallic = 0.3
		fm.roughness = 0.6
		fm.specular_mode = BaseMaterial3D.SPECULAR_DISABLED
		m = fm
	_mats[name] = m
	return m


static func apply(root: Node) -> void:
	for node in root.find_children("*", "MeshInstance3D", true, false):
		var mesh := (node as MeshInstance3D).mesh
		if mesh == null:
			continue
		for i in mesh.get_surface_count():
			var src := mesh.surface_get_material(i)
			var nm := ""
			if mesh is ArrayMesh:
				nm = (mesh as ArrayMesh).surface_get_name(i)  # the glTF material name lives in the surface name
			if nm == "" and src:
				nm = String(src.resource_name)
			var m := _material(nm)
			if m != null:
				mesh.surface_set_material(i, m)
