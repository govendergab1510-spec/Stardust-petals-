extends Node3D
## Main menu: 3D character stage + big touch-friendly UI.

const RED := Color(1.0, 0.2, 0.28)
const CYAN := Color(0.15, 0.8, 1.0)
const ORANGE := Color(1.0, 0.5, 0.12)

var ui: CanvasLayer
var root: Control
var chars: Array = []
var lights: Array = []
var cards: Array = []
var cam: Camera3D
var _t := 0.0
var _search: Control
var _search_label: Label
var _search_t := 0.0
var _searching := false
var _prompt: Control
var _fv: FontVariation
var _play_btn: Button
var _menu_i := 0


func _ready() -> void:
	_fv = FontVariation.new()
	_fv.base_font = ThemeDB.fallback_font
	_fv.variation_embolden = 0.9
	_fv.variation_transform = Transform2D(Vector2(1, 0), Vector2(-0.22, 1), Vector2.ZERO)
	_build_stage()
	_build_ui()
	_select(Game.character, false)


# ------------------------------------------------------------------ 3D stage
func _build_stage() -> void:
	var we := WorldEnvironment.new()
	var env := Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = Color(0.025, 0.03, 0.05)
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.reflected_light_source = Environment.REFLECTION_SOURCE_DISABLED
	env.ambient_light_color = Color(0.25, 0.28, 0.4)
	env.ambient_light_energy = 0.7
	env.fog_enabled = true
	env.fog_light_color = Color(0.04, 0.05, 0.09)
	env.fog_density = 0.035
	we.environment = env
	add_child(we)
	cam = Camera3D.new()
	cam.fov = 38.0
	cam.position = Vector3(2.1, 1.0, 6.8)
	add_child(cam)
	cam.look_at(Vector3(2.1, 0.55, 0))
	# floor + backdrop: real sci-fi floor tiles, shipping containers and floodlights
	var tile := AssetLib.find(AssetLib.STRUCT, "FLOORhall_Road")
	if not tile.is_empty():
		var bb: AABB = tile["aabb"]
		for ix in range(-2, 3):
			for iz in range(-2, 2):
				_menu_prop(tile, Vector3(ix * bb.size.x, -bb.size.y, iz * bb.size.z - 4.0), 0.0, "FLOOR")
	for i in 7:
		var cd := AssetLib.find(AssetLib.PROPS, "prop_container")
		_menu_prop(cd, Vector3(-12.0 + i * 4.2, 0.0, -9.5), PI * 0.5)
		_menu_prop(cd, Vector3(-10.0 + i * 4.2, 3.1, -9.5), PI * 0.5)
	for sx in [-5.0, 12.0]:
		_menu_prop(AssetLib.find(AssetLib.PROPS, "prop_floodlight"), Vector3(sx, 0, -6.0), 0.4, "prop_floodlight")
	# characters on pedestals
	for i in 2:
		var holder := Node3D.new()
		holder.position = Vector3(2.6 if i == 0 else 5.0, 0, 0)
		add_child(holder)
		_menu_prop(AssetLib.find(AssetLib.PROPS, "prop_pellet"), holder.position, 0.0, "prop_pellet")
		var m := Game.make_model(i)
		var model: Node3D = m["root"]
		model.rotation.y = PI + (0.3 if i == 0 else -0.3)
		model.position.y = 0.3
		holder.add_child(model)
		Game.play_anim(m["anim"], "idle")
		var gun := GunModel.build(Game.CHARS[i]["start"], 1.7)
		gun.position = Vector3(-1.25 if i == 0 else 1.25, 1.35, 0.2)
		gun.rotation.y = PI * 0.5
		holder.add_child(gun)
		chars.append({"holder": holder, "gun": gun})
		var l := OmniLight3D.new()
		l.light_color = ORANGE if i == 0 else CYAN
		l.omni_range = 7.0
		l.position = Vector3(holder.position.x + (-0.8 if i == 0 else 0.8), 2.4, 2.6)
		add_child(l)
		lights.append(l)
	var d := DirectionalLight3D.new()
	d.light_energy = 0.5
	d.light_color = Color(0.7, 0.8, 1.0)
	add_child(d)
	d.basis = Basis.looking_at(Vector3(0.2, -0.5, -1.0))


func _menu_prop(d: Dictionary, pos: Vector3, yaw: float, prefix := "prop_container") -> void:
	if d.is_empty():
		return
	var bb: AABB = d["aabb"]
	var mi := MeshInstance3D.new()
	mi.mesh = d["mesh"]
	mi.position = pos + Basis(Vector3.UP, yaw) * Vector3(-bb.get_center().x, -bb.position.y, -bb.get_center().z)
	mi.rotation.y = yaw
	add_child(mi)


# ------------------------------------------------------------------ UI
func _style(color: Color, border := Color(1, 1, 1, 0.0), radius := 16, bw := 0) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = color
	s.set_corner_radius_all(radius)
	s.border_color = border
	s.set_border_width_all(bw)
	return s


func _grad_style(c1: Color, c2: Color, border: Color, bw := 2) -> StyleBoxTexture:
	var g := Gradient.new()
	g.set_color(0, c1)
	g.set_color(1, c2)
	var gt := GradientTexture2D.new()
	gt.gradient = g
	gt.fill_from = Vector2(0, 0)
	gt.fill_to = Vector2(1, 1)
	gt.width = 256
	gt.height = 64
	var sb := StyleBoxTexture.new()
	sb.texture = gt
	sb.axis_stretch_horizontal = StyleBoxTexture.AXIS_STRETCH_MODE_STRETCH
	sb.axis_stretch_vertical = StyleBoxTexture.AXIS_STRETCH_MODE_STRETCH
	return sb


func _btn(text: String, pos: Vector2, size: Vector2, color: Color, fsize := 34, parent: Control = null) -> Button:
	var b := Button.new()
	b.text = text
	b.position = pos
	b.size = size
	b.pivot_offset = size * 0.5
	b.add_theme_font_size_override("font_size", fsize)
	b.add_theme_font_override("font", _fv)
	b.add_theme_color_override("font_color", Color.WHITE)
	b.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.6))
	b.add_theme_constant_override("outline_size", 6)
	b.add_theme_stylebox_override("normal", _grad_style(color.lightened(0.18), color.darkened(0.35), Color.WHITE))
	b.add_theme_stylebox_override("hover", _grad_style(color.lightened(0.38), color.darkened(0.1), Color.WHITE))
	b.add_theme_stylebox_override("pressed", _grad_style(color.darkened(0.2), color.darkened(0.5), Color.WHITE))
	b.focus_mode = Control.FOCUS_NONE
	# esports-style frame: bright top edge + accent bar on the left
	var edge := ColorRect.new()
	edge.color = Color(1, 1, 1, 0.55)
	edge.size = Vector2(size.x, 2)
	edge.mouse_filter = Control.MOUSE_FILTER_IGNORE
	b.add_child(edge)
	var bar := ColorRect.new()
	bar.color = color.lightened(0.5)
	bar.size = Vector2(8, size.y)
	bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	b.add_child(bar)
	var glow := ColorRect.new()
	glow.color = Color(color.r, color.g, color.b, 0.18)
	glow.size = Vector2(size.x + 16, size.y + 16)
	glow.position = Vector2(-8, -8)
	glow.mouse_filter = Control.MOUSE_FILTER_IGNORE
	glow.show_behind_parent = true
	b.add_child(glow)
	b.mouse_entered.connect(func(): create_tween().tween_property(b, "scale", Vector2(1.04, 1.04), 0.08))
	b.mouse_exited.connect(func(): create_tween().tween_property(b, "scale", Vector2.ONE, 0.08))
	b.pressed.connect(func(): Sfx.play("ui_click"))
	(parent if parent else root).add_child(b)
	return b


func _label(text: String, pos: Vector2, size_px: int, color: Color, parent: Control = null, italic := false) -> Label:
	var l := Label.new()
	l.text = text
	l.position = pos
	l.add_theme_font_size_override("font_size", size_px)
	l.add_theme_color_override("font_color", color)
	l.add_theme_constant_override("outline_size", maxi(4, size_px / 10))
	l.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.85))
	if italic:
		l.add_theme_font_override("font", _fv)
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	(parent if parent else root).add_child(l)
	return l


func _build_ui() -> void:
	ui = CanvasLayer.new()
	add_child(ui)
	root = Control.new()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	ui.add_child(root)
	# title
	_label("STRIKEOUT", Vector2(54, 34), 128, Color.WHITE, null, true).add_theme_color_override("font_outline_color", Color(0.9, 0.1, 0.2))
	_label("3D", Vector2(800, 70), 96, RED, null, true)
	_label("FIRST-PERSON ARENA SHOOTER", Vector2(62, 186), 24, Color(1, 1, 1, 0.75))
	# buttons
	_play_btn = _btn("PLAY", Vector2(60, 250), Vector2(470, 108), RED, 58)
	_play_btn.pressed.connect(_on_play)
	_btn("FRIEND DUEL  1v1", Vector2(60, 372), Vector2(470, 74), Color(0.12, 0.16, 0.26), 32).pressed.connect(_open_friend)
	_btn("PLAY VS BOTS", Vector2(60, 458), Vector2(470, 74), Color(0.12, 0.16, 0.26), 32).pressed.connect(func(): _start("bots"))
	_btn("SETTINGS", Vector2(60, 544), Vector2(470, 74), Color(0.12, 0.16, 0.26), 32).pressed.connect(_open_settings)
	var tw := create_tween().set_loops()
	tw.tween_property(_play_btn, "modulate", Color(1.25, 1.1, 1.1), 0.7)
	tw.tween_property(_play_btn, "modulate", Color.WHITE, 0.7)
	# character cards (right side)
	for i in 2:
		var c: Dictionary = Game.CHARS[i]
		var card := Panel.new()
		card.position = Vector2(700 + i * 290, 470)
		card.size = Vector2(270, 220)
		root.add_child(card)
		var accent := ORANGE if i == 0 else CYAN
		_label(String(c["name"]), Vector2(18, 8), 52, Color.WHITE, card, true)
		_label(String(c["role"]), Vector2(20, 66), 22, accent, card)
		var names := ["SPEED", "FIRE", "POWER"]
		for k in 3:
			_label(names[k], Vector2(20, 100 + k * 34), 18, Color(1, 1, 1, 0.8), card)
			var bg := ColorRect.new()
			bg.color = Color(1, 1, 1, 0.15)
			bg.position = Vector2(100, 108 + k * 34)
			bg.size = Vector2(150, 12)
			card.add_child(bg)
			var fill := ColorRect.new()
			fill.color = accent
			fill.size = Vector2(150.0 * float(c["stats"][k]), 12)
			bg.add_child(fill)
		var hit := Button.new()
		hit.flat = true
		hit.size = card.size
		hit.focus_mode = Control.FOCUS_NONE
		hit.pressed.connect(func(): _select(i, true))
		card.add_child(hit)
		cards.append(card)
	_label("CHOOSE YOUR OPERATIVE", Vector2(700, 430), 26, Color(1, 1, 1, 0.8), null, true)
	_label("v%s  -  Models: Godot TPS demo (CC-BY 3.0, Godot community), weapons by amaraha  -  Trystero P2P" % Game.VERSION, Vector2(60, 684), 15, Color(1, 1, 1, 0.5))


func _select(i: int, speak: bool) -> void:
	Game.character = i
	Game.save_settings()
	for k in cards.size():
		var accent := ORANGE if k == 0 else CYAN
		var on := k == i
		(cards[k] as Panel).add_theme_stylebox_override("panel", _style(Color(0.08, 0.1, 0.16, 0.92) if on else Color(0.05, 0.06, 0.1, 0.75), accent if on else Color(1, 1, 1, 0.12), 16, 4 if on else 1))
		(lights[k] as OmniLight3D).light_energy = 4.5 if on else 0.7
		create_tween().tween_property(chars[k]["holder"], "scale", Vector3.ONE * (1.1 if on else 0.94), 0.2)
	if speak:
		Sfx.voice(Game.CHARS[i]["id"], "select", 1, 0.0)


func _process(delta: float) -> void:
	_t += delta
	cam.position.x = 2.1 + sin(_t * 0.3) * 0.35
	cam.look_at(Vector3(2.1, 0.55, 0))
	for k in chars.size():
		(chars[k]["gun"] as Node3D).rotation.y += delta * 0.8
	if _searching:
		_search_t += delta
		var n := int(_search_t * 2.0) % 4
		_search_label.text = "SEARCHING FOR PLAYERS" + ".".repeat(n)
		if Net.peer_count() > 0:
			_searching = false
			_launch()
		elif _search_t > (8.0 if Net.available else 2.5):
			_searching = false
			_search.visible = false
			_open_bots_prompt()


# ------------------------------------------------------------------ flows
func _modal(title: String, size: Vector2) -> Control:
	var m := Control.new()
	m.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.add_child(m)
	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, 0.72)
	dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	m.add_child(dim)
	var p := Panel.new()
	p.size = size
	p.position = (Vector2(1280, 720) - size) * 0.5
	p.add_theme_stylebox_override("panel", _style(Color(0.07, 0.09, 0.14, 0.98), RED, 20, 3))
	m.add_child(p)
	_label(title, Vector2(28, 18), 40, Color.WHITE, p, true)
	return m


func _panel_of(m: Control) -> Panel:
	return m.get_child(1) as Panel


func _on_play() -> void:
	Game.mode = "quick"
	Net.join("quick-v1")
	_search = _modal("QUICK MATCH", Vector2(640, 300))
	_search_label = _label("SEARCHING FOR PLAYERS", Vector2(30, 110), 34, Color(1, 0.85, 0.3), _panel_of(_search))
	var cancel := _btn("CANCEL", Vector2(160, 200), Vector2(320, 70), Color(0.2, 0.22, 0.3), 30, _panel_of(_search))
	cancel.pressed.connect(func():
		_searching = false
		Net.leave()
		_search.queue_free())
	_search_t = 0.0
	_searching = true


func _open_bots_prompt() -> void:
	_prompt = _modal("NO PLAYERS ONLINE YET", Vector2(700, 320))
	var p := _panel_of(_prompt)
	_label("Want to jump in against bots?\nYou will be switched to a live match if\nreal players join later.", Vector2(30, 96), 26, Color(1, 1, 1, 0.85), p)
	_btn("PLAY VS BOTS", Vector2(30, 220), Vector2(310, 72), RED, 30, p).pressed.connect(func(): _start("bots"))
	_btn("KEEP SEARCHING", Vector2(360, 220), Vector2(310, 72), Color(0.2, 0.22, 0.3), 28, p).pressed.connect(func():
		_prompt.queue_free()
		_search.visible = true
		_search_t = 0.0
		_searching = true)


func _open_friend() -> void:
	var m := _modal("FRIEND DUEL  1v1", Vector2(700, 380))
	var p := _panel_of(m)
	_label("Both players enter the SAME room code.", Vector2(30, 90), 24, Color(1, 1, 1, 0.8), p)
	var le := LineEdit.new()
	le.position = Vector2(30, 140)
	le.size = Vector2(640, 80)
	le.placeholder_text = "ROOM CODE  (e.g. TIKTOK)"
	le.max_length = 12
	le.add_theme_font_size_override("font_size", 40)
	le.alignment = HORIZONTAL_ALIGNMENT_CENTER
	p.add_child(le)
	_btn("JOIN ROOM", Vector2(30, 250), Vector2(310, 76), RED, 32, p).pressed.connect(func():
		var code := le.text.strip_edges().to_upper()
		if code.length() >= 3:
			Game.room_code = code
			_start("friend"))
	_btn("BACK", Vector2(360, 250), Vector2(310, 76), Color(0.2, 0.22, 0.3), 30, p).pressed.connect(func(): m.queue_free())


func _open_settings() -> void:
	var m := _modal("SETTINGS", Vector2(760, 560))
	var p := _panel_of(m)
	_label("GRAPHICS", Vector2(30, 90), 24, Color(1, 0.8, 0.3), p)
	var names := ["LOW", "MEDIUM", "HIGH"]
	var btns: Array = []
	for i in 3:
		var b := _btn(names[i], Vector2(30 + i * 235, 126), Vector2(220, 64), RED if Game.quality == i else Color(0.2, 0.22, 0.3), 28, p)
		btns.append(b)
		b.pressed.connect(func():
			Game.quality = i
			Game.apply_quality()
			Game.save_settings()
			for k in 3:
				(btns[k] as Button).add_theme_stylebox_override("normal", _style(RED if k == i else Color(0.2, 0.22, 0.3), Color(1, 1, 1, 0.25), 14, 2)))
	_label("Low = 480p fastest  -  Medium = 720p  -  High = 900p + shadows + AA", Vector2(30, 196), 18, Color(1, 1, 1, 0.55), p)
	_slider(p, "VOLUME", 250, Game.volume, 0.0, 1.0, func(v): Game.volume = v; Game.apply_quality(); Game.save_settings())
	_slider(p, "AIM SENSITIVITY", 330, Game.sensitivity, 0.4, 2.5, func(v): Game.sensitivity = v; Game.save_settings())
	var cb := CheckButton.new()
	cb.text = "  CLEAN HUD (for recording)"
	cb.button_pressed = Game.minimal_hud
	cb.position = Vector2(30, 412)
	cb.add_theme_font_size_override("font_size", 26)
	cb.toggled.connect(func(on): Game.minimal_hud = on; Game.save_settings())
	p.add_child(cb)
	var le := LineEdit.new()
	le.text = Game.player_name
	le.position = Vector2(30, 470)
	le.size = Vector2(380, 56)
	le.max_length = 12
	le.add_theme_font_size_override("font_size", 28)
	le.text_changed.connect(func(t): Game.player_name = t.strip_edges().to_upper() if t.strip_edges() != "" else "PLAYER"; Game.save_settings())
	p.add_child(le)
	_btn("DONE", Vector2(450, 466), Vector2(280, 64), RED, 30, p).pressed.connect(func(): m.queue_free())


func _slider(p: Control, text: String, y: float, val: float, lo: float, hi: float, cb: Callable) -> void:
	_label(text, Vector2(30, y), 22, Color(1, 0.8, 0.3), p)
	var s := HSlider.new()
	s.position = Vector2(30, y + 38)
	s.size = Vector2(700, 30)
	s.min_value = lo
	s.max_value = hi
	s.step = 0.05
	s.value = val
	s.value_changed.connect(cb)
	p.add_child(s)


func _start(mode: String) -> void:
	_searching = false
	Game.mode = mode
	if mode == "friend":
		Net.join("fc-" + Game.room_code)
	elif mode == "bots":
		Net.leave()
	_launch()


func _launch() -> void:
	Game.save_settings()
	Sfx.play("ui_start")
	get_tree().change_scene_to_file("res://scenes/arena.tscn")
