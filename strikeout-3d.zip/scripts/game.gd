extends Node
## Global settings, character + weapon data (autoload "Game").

const VERSION := "0.1.0"
const TARGET_KILLS := 15
## Character voice lines are switched off (announcer + sound effects only).
const CHARACTER_VOICES := false
const CHARS := [
	{"id": "rush", "name": "RUSH", "role": "ASSAULT", "model": "Player", "speed": 1.2, "hp": 100, "start": "rifle", "second": "pistol",
	 "bio": "Fast movement. Rapid-fire close-range.", "stats": [0.95, 0.9, 0.55], "bonus": 1,
	 "anim": {"idle": "Idlecombat", "walk": "walking_gun", "run": "running_gun", "hit": "flinch1"}, "scale": 1.0, "yaw": 0.0},
	{"id": "ace", "name": "ACE", "role": "PRECISION", "model": "Robot", "speed": 0.95, "hp": 100, "start": "sniper", "second": "pistol",
	 "bio": "Heavy hits. Trick shots earn double STRIKEOUT points.", "stats": [0.55, 0.45, 1.0], "bonus": 2,
	 "anim": {"idle": "Idle", "walk": "Walk", "run": "Walk", "hit": "Damage_take1"}, "scale": 0.78, "yaw": 0.0},
]
# dmg, rate (shots/s), mag, reserve, reload (s), spread (hip), pellets, scope fov (0 = no scope), auto
const WEAPONS := {
	"pistol":  {"name": "M1911 PISTOL", "dmg": 24, "rate": 4.5, "mag": 12, "reserve": 60, "reload": 1.2, "spread": 0.012, "pellets": 1, "zoom": 0.0, "auto": false, "kick": 0.012, "snd": "gun_pistol"},
	"rifle":   {"name": "AK-47 RIFLE", "dmg": 20, "rate": 10.0, "mag": 30, "reserve": 150, "reload": 1.8, "spread": 0.026, "pellets": 1, "zoom": 0.0, "auto": true, "kick": 0.009, "snd": "gun_rifle"},
	"shotgun": {"name": "PUMP SHOTGUN", "dmg": 11, "rate": 1.1, "mag": 6, "reserve": 30, "reload": 2.4, "spread": 0.07, "pellets": 9, "zoom": 0.0, "auto": false, "kick": 0.05, "snd": "gun_shotgun"},
	"sniper":  {"name": "AWM SNIPER", "dmg": 100, "rate": 1.0, "mag": 5, "reserve": 25, "reload": 2.6, "spread": 0.08, "pellets": 1, "zoom": 14.0, "auto": false, "kick": 0.06, "snd": "gun_sniper"},
}

var character := 0
var player_name := "PLAYER"
var quality := 1
var sensitivity := 1.0
var volume := 0.9
var minimal_hud := false
var mode := "bots"      # bots | quick | friend
var room_code := ""


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	load_settings()
	apply_quality()


func apply_quality() -> void:
	var sizes := [Vector2i(854, 480), Vector2i(1280, 720), Vector2i(1600, 900)]
	var w := get_tree().root
	w.content_scale_size = sizes[clampi(quality, 0, 2)]
	w.msaa_3d = Viewport.MSAA_2X if quality == 2 else Viewport.MSAA_DISABLED
	AudioServer.set_bus_volume_db(0, linear_to_db(maxf(volume, 0.001)))


func load_settings() -> void:
	var cf := ConfigFile.new()
	if cf.load("user://strikeout.cfg") != OK:
		quality = 0 if (OS.has_feature("web") and DisplayServer.screen_get_size().x < 900) or OS.has_feature("android") else 1
		return
	character = int(cf.get_value("s", "character", 0))
	player_name = String(cf.get_value("s", "name", "PLAYER"))
	quality = int(cf.get_value("s", "quality", 1))
	sensitivity = float(cf.get_value("s", "sens", 1.0))
	volume = float(cf.get_value("s", "volume", 0.9))
	minimal_hud = bool(cf.get_value("s", "minimal", false))


func save_settings() -> void:
	var cf := ConfigFile.new()
	cf.set_value("s", "character", character)
	cf.set_value("s", "name", player_name)
	cf.set_value("s", "quality", quality)
	cf.set_value("s", "sens", sensitivity)
	cf.set_value("s", "volume", volume)
	cf.set_value("s", "minimal", minimal_hud)
	cf.save("user://strikeout.cfg")


## Builds a character from the downloaded Godot shooter-demo models. Returns {"root", "anim", "map"}.
func make_model(idx: int) -> Dictionary:
	var c: Dictionary = CHARS[idx]
	var path := "res://assets/models/%s.glb" % c["model"]
	var root := Node3D.new()
	var anim: AnimationPlayer = null
	if ResourceLoader.exists(path):
		var inst := (load(path) as PackedScene).instantiate() as Node3D
		inst.scale = Vector3.ONE * float(c["scale"])
		inst.rotation.y = float(c["yaw"])
		AssetLib.apply(inst)
		root.add_child(inst)
		var aps := inst.find_children("*", "AnimationPlayer", true, false)
		if aps.size() > 0:
			anim = aps[0] as AnimationPlayer
			for key in c["anim"]:
				var n := String(c["anim"][key])
				if anim.has_animation(n) and key != "hit":
					anim.get_animation(n).loop_mode = Animation.LOOP_LINEAR
	return {"root": root, "anim": anim, "map": c["anim"]}


func play_anim(anim: AnimationPlayer, key: String, map: Dictionary = {}) -> void:
	if anim == null:
		return
	var n := String(map.get(key, key))
	if anim.has_animation(n) and anim.current_animation != n:
		anim.play(n, 0.2)


## The downloaded characters ship untextured: give each a team colour (alternating light/dark parts keeps the detail).
func _tint_model(inst: Node, col: Color) -> void:
	for mi in inst.find_children("*", "MeshInstance3D", true, false):
		var m := mi as MeshInstance3D
		for i in m.mesh.get_surface_count():
			var src := m.mesh.surface_get_material(i)
			var nm: StandardMaterial3D = (src.duplicate() as StandardMaterial3D) if src is StandardMaterial3D else StandardMaterial3D.new()
			nm.metallic = 0.2
			nm.roughness = 0.6
			nm.specular_mode = BaseMaterial3D.SPECULAR_DISABLED
			nm.albedo_color = col * (1.0 if i % 2 == 0 else 0.55)
			m.set_surface_override_material(i, nm)
