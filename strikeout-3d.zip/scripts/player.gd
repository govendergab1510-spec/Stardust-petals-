class_name Player
extends CharacterBody3D
## First-person player: move, look, shoot, scope, reload, pick up weapons, health + armor.

var arena
var cam: Camera3D
var vm: Node3D
var gun_node: Node3D
var flash: MeshInstance3D
var hp := 100.0
var armor := 0.0
var alive := true
var slots: Array = []
var cur := 0
var yaw := 0.0
var pitch := 0.0
var ads := false
var move_vec := Vector2.ZERO
var look_delta := Vector2.ZERO
var fire_held := false
var jump_req := false
var reload_req := false
var swap_req := false
var pick_req := false
var ads_req := false
var frozen := true
var _fire_cd := 0.0
var _reload_t := 0.0
var _kick := 0.0
var _bob := 0.0
var _flash_t := 0.0
var _step_t := 0.0
var _latch := false
var airborne := false


func setup(a) -> void:
	arena = a
	collision_layer = 4
	collision_mask = 1
	var cs := CollisionShape3D.new()
	var cap := CapsuleShape3D.new()
	cap.radius = 0.34
	cap.height = 1.75
	cs.shape = cap
	cs.position.y = 0.875
	add_child(cs)
	cam = Camera3D.new()
	cam.position.y = 1.62
	cam.near = 0.03
	cam.far = 220.0
	cam.fov = 78.0
	add_child(cam)
	cam.current = true
	vm = Node3D.new()
	cam.add_child(vm)
	flash = MeshInstance3D.new()
	var q := QuadMesh.new()
	q.size = Vector2(0.22, 0.22)
	flash.mesh = q
	var fm := StandardMaterial3D.new()
	fm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	fm.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
	fm.albedo_color = Color(1.0, 0.75, 0.3)
	fm.billboard_mode = BaseMaterial3D.BILLBOARD_ENABLED
	fm.no_depth_test = true
	flash.material_override = fm
	flash.visible = false
	reset_loadout()


func reset_loadout() -> void:
	var c: Dictionary = Game.CHARS[Game.character]
	hp = float(c["hp"])
	armor = 0.0
	alive = true
	slots = [_slot(c["start"]), _slot(c["second"])]
	cur = 0
	_equip()


func _slot(id: String) -> Dictionary:
	var w: Dictionary = Game.WEAPONS[id]
	return {"id": id, "mag": w["mag"], "reserve": w["reserve"]}


func cur_id() -> String:
	return String(slots[cur]["id"])


func cur_w() -> Dictionary:
	return Game.WEAPONS[cur_id()]


func give_weapon(id: String) -> void:
	for i in slots.size():
		if slots[i]["id"] == id:
			slots[i]["reserve"] = Game.WEAPONS[id]["reserve"] + Game.WEAPONS[id]["mag"]
			return
	slots[cur] = _slot(id)
	_equip()


func _equip() -> void:
	if gun_node:
		gun_node.queue_free()
	gun_node = GunModel.build(cur_id(), {"pistol": 0.75, "rifle": 0.5, "shotgun": 0.5, "sniper": 0.42}.get(cur_id(), 0.5))
	vm.add_child(gun_node)
	var m := gun_node.get_node("Muzzle") as Marker3D
	if flash.get_parent():
		flash.get_parent().remove_child(flash)
	m.add_child(flash)
	_reload_t = 0.0
	ads = false
	Sfx.play("pickup_weapon", -6.0)


func muzzle_pos() -> Vector3:
	return (gun_node.get_node("Muzzle") as Node3D).global_position


func take_damage(dmg: float, from_name: String, hs: bool) -> void:
	if not alive:
		return
	var absorbed := minf(armor, dmg * 0.6)
	armor -= absorbed
	hp -= dmg - absorbed
	Sfx.play("hurt", -4.0)
	arena.hud.damage_flash()
	if hp <= 0.0:
		hp = 0.0
		alive = false
		arena.player_died(from_name, hs)
	elif hp < 30.0:
		Sfx.voice(Game.CHARS[Game.character]["id"], "low", 2, 6.0)
	else:
		Sfx.voice(Game.CHARS[Game.character]["id"], "hurt", 2, 4.0)


func spread_now() -> float:
	var w := cur_w()
	var s: float = float(w["spread"])
	if ads:
		s *= 0.12
	if Vector2(velocity.x, velocity.z).length() > 1.0:
		s *= 1.5
	if airborne:
		s *= 2.0
	return s


func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
		look_delta += event.relative * 0.55
	elif event is InputEventMouseButton and not DisplayServer.is_touchscreen_available():
		if Input.mouse_mode != Input.MOUSE_MODE_CAPTURED and not DisplayServer.is_touchscreen_available() and event.pressed:
			Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
		elif event.button_index == MOUSE_BUTTON_LEFT:
			fire_held = event.pressed
		elif event.button_index == MOUSE_BUTTON_RIGHT:
			ads_req = event.pressed
	elif event is InputEventKey and event.pressed and not event.echo:
		match event.keycode:
			KEY_R: reload_req = true
			KEY_Q, KEY_1, KEY_2: swap_req = true
			KEY_E: pick_req = true
			KEY_SPACE: jump_req = true


func _process(delta: float) -> void:
	var w := cur_w()
	var zoom: float = float(w["zoom"])
	var want_ads := ads_req and alive and not frozen
	if want_ads != ads:
		ads = want_ads
		if ads and zoom > 0.0:
			Sfx.play("scope", -6.0)
	var target_fov := (zoom if (ads and zoom > 0.0) else (58.0 if ads else 78.0))
	cam.fov = lerpf(cam.fov, target_fov, clampf(14.0 * delta, 0.0, 1.0))
	# viewmodel: sway, bob, recoil, ads
	var scoped := ads and zoom > 0.0 and cam.fov < zoom + 14.0
	vm.visible = not scoped and alive
	var hip := Vector3(0.2, -0.17, -0.32)
	var aim := Vector3(0.0, -0.095, -0.3)
	var sp := Vector2(velocity.x, velocity.z).length()
	_bob += delta * (sp * 1.6)
	var bob := Vector3(sin(_bob) * 0.006, absf(cos(_bob)) * 0.008, 0.0) * (0.3 if ads else 1.0)
	vm.position = vm.position.lerp((aim if ads else hip) + bob + Vector3(0, 0, _kick * 0.9), clampf(16.0 * delta, 0.0, 1.0))
	vm.rotation.x = lerpf(vm.rotation.x, _kick * 2.2 - (0.5 if _reload_t > 0.0 else 0.0), clampf(18.0 * delta, 0.0, 1.0))
	vm.rotation.z = lerpf(vm.rotation.z, -move_vec.x * 0.04, clampf(8.0 * delta, 0.0, 1.0))
	_kick = lerpf(_kick, 0.0, clampf(12.0 * delta, 0.0, 1.0))
	if _flash_t > 0.0:
		_flash_t -= delta
		flash.visible = _flash_t > 0.0
	# look
	var sens := 0.0028 * Game.sensitivity * (cam.fov / 78.0 if ads else 1.0)
	if not frozen and alive:
		yaw -= look_delta.x * sens
		pitch = clampf(pitch - look_delta.y * sens, -1.45, 1.45)
	look_delta = Vector2.ZERO
	rotation.y = yaw
	cam.rotation.x = pitch


func _physics_process(delta: float) -> void:
	var c: Dictionary = Game.CHARS[Game.character]
	var mv := Vector2.ZERO
	if not frozen and alive:
		mv = move_vec
		var kx := int(Input.is_physical_key_pressed(KEY_D)) - int(Input.is_physical_key_pressed(KEY_A))
		var ky := int(Input.is_physical_key_pressed(KEY_S)) - int(Input.is_physical_key_pressed(KEY_W))
		mv += Vector2(kx, ky)
		if mv.length() > 1.0:
			mv = mv.normalized()
	var dir := (transform.basis * Vector3(mv.x, 0, mv.y))
	var speed := 6.4 * float(c["speed"]) * (0.55 if ads else 1.0)
	var hv := Vector3(velocity.x, 0, velocity.z).move_toward(dir * speed, (38.0 if mv.length() > 0.01 else 30.0) * delta)
	velocity.x = hv.x
	velocity.z = hv.z
	airborne = not is_on_floor()
	if is_on_floor():
		velocity.y = -0.5
		if jump_req and not frozen and alive:
			velocity.y = 6.8
			Sfx.play("jump", -6.0)
	else:
		velocity.y -= 20.0 * delta
	jump_req = false
	move_and_slide()
	if is_on_floor() and hv.length() > 2.0:
		_step_t -= delta
		if _step_t <= 0.0:
			Sfx.play("footstep", -12.0, randf_range(0.9, 1.1))
			_step_t = 0.42 - clampf(hv.length() / 8.0, 0.0, 0.5) * 0.2
	# combat
	_fire_cd -= delta
	var w := cur_w()
	if _reload_t > 0.0:
		_reload_t -= delta
		if _reload_t <= 0.0:
			var s: Dictionary = slots[cur]
			var need: int = int(w["mag"]) - int(s["mag"])
			var take := mini(need, int(s["reserve"]))
			s["mag"] += take
			s["reserve"] -= take
	if swap_req and alive and not frozen:
		cur = 1 - cur
		_equip()
	swap_req = false
	if reload_req and alive and _reload_t <= 0.0:
		var s2: Dictionary = slots[cur]
		if int(s2["mag"]) < int(w["mag"]) and int(s2["reserve"]) > 0:
			_reload_t = float(w["reload"])
			Sfx.play("reload", -2.0)
			Sfx.voice(c["id"], "reload", 1, 8.0)
	reload_req = false
	if fire_held and alive and not frozen and _reload_t <= 0.0:
		if w["auto"] or not _latch:
			_try_fire(w)
		_latch = true
	elif not fire_held:
		_latch = false
	if pick_req and alive:
		arena.try_pickup(self)
	pick_req = false


func _try_fire(w: Dictionary) -> void:
	if _fire_cd > 0.0:
		return
	var s: Dictionary = slots[cur]
	if int(s["mag"]) <= 0:
		Sfx.play("empty", -4.0)
		_fire_cd = 0.3
		reload_req = true
		return
	s["mag"] -= 1
	_fire_cd = 1.0 / float(w["rate"])
	_kick = float(w["kick"]) * (0.5 if ads else 1.0)
	pitch += float(w["kick"]) * 0.7
	_flash_t = 0.05
	flash.visible = true
	flash.rotation.z = randf() * TAU
	arena.player_fire(self, w, cur_id(), ads, spread_now())
