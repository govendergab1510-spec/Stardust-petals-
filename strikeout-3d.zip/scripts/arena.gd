extends Node3D
## The battle arena + match logic (bots / peer-to-peer players). Built entirely in code.

const SIZE := 48.0
const HUD := preload("res://scripts/hud.gd")
const PROPS := "res://assets/models/Props.glb"
const STRUCT := "res://assets/models/Structure.glb"
const TABLE_SPOTS := [
	[Vector3(-14, 0, -10), "rifle"], [Vector3(14, 0, -10), "shotgun"], [Vector3(-14, 0, 10), "sniper"], [Vector3(14, 0, 10), "pistol"],
	[Vector3(0, 0, -24), "sniper"], [Vector3(0, 0, 24), "rifle"], [Vector3(-26, 0, 0), "shotgun"], [Vector3(26, 0, 0), "rifle"],
	[Vector3(-38, 0, -20), "pistol"], [Vector3(38, 0, 20), "shotgun"], [Vector3(-38, 0, 22), "rifle"], [Vector3(38, 0, -22), "sniper"],
	[Vector3(-12, 0, -38), "rifle"], [Vector3(12, 0, 38), "sniper"],
]
const HEALTH_SPOTS := [Vector3(-9, 0, 0), Vector3(9, 0, 9), Vector3(0, 0, -14), Vector3(0, 0, 14), Vector3(-24, 0, -30), Vector3(24, 0, 30), Vector3(-40, 0, 6), Vector3(40, 0, -6)]
const ARMOR_SPOTS := [Vector3(0, 0, -9), Vector3(-9, 0, 9), Vector3(-24, 0, 30), Vector3(24, 0, -30), Vector3(-40, 0, -8), Vector3(40, 0, 8), Vector3(-18, 0, -4), Vector3(18, 0, 4)]
const BOT_NAMES := ["VIPER", "GHOST", "NOVA", "BLITZ", "REAPER", "HAWK", "COBRA", "TITAN"]

var player: Player
var hud
var fighters: Array = []
var remotes := {}
var tid_map := {}
var scores := {}
var tables: Array = []
var _batches := {}
var _tint_i := 0
var pickups: Array = []
var col_body: StaticBody3D
var started := false
var ended := false
var _net_t := 0.0
var _last_hit_ctx := {}
var _pool: Array = []
var _time := 0.0
var _last_attacker := ""


func _ready() -> void:
	Net.peer_msg.connect(_on_net)
	Net.peer_left.connect(_on_peer_left)
	Net.peer_joined.connect(func(_t): _send_state(true))
	col_body = StaticBody3D.new()
	col_body.collision_layer = 1
	add_child(col_body)
	_build_env()
	_build_arena()
	_build_pickups()
	player = Player.new()
	add_child(player)
	player.setup(self)
	player.global_position = spawn_point()
	scores[Game.player_name] = {"k": 0, "d": 0, "pts": 0}
	hud = HUD.new()
	add_child(hud)
	hud.setup(self, player)
	if Game.mode == "bots":
		for i in 6:
			_add_bot(BOT_NAMES[i], i % 2, ["rifle", "pistol", "shotgun", "sniper", "rifle", "shotgun", "pistol"][i])
	_countdown()


func _build_env() -> void:
	var we := WorldEnvironment.new()
	var env := Environment.new()
	env.background_mode = Environment.BG_SKY
	var sk := Sky.new()
	var psm := ProceduralSkyMaterial.new()
	psm.sky_top_color = Color(0.2, 0.42, 0.82)
	psm.sky_horizon_color = Color(0.72, 0.82, 0.95)
	psm.ground_horizon_color = Color(0.55, 0.6, 0.66)
	psm.ground_bottom_color = Color(0.22, 0.24, 0.28)
	psm.sun_angle_max = 25.0
	sk.sky_material = psm
	sk.radiance_size = Sky.RADIANCE_SIZE_32
	env.sky = sk
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.reflected_light_source = Environment.REFLECTION_SOURCE_DISABLED
	env.ambient_light_color = Color(0.62, 0.68, 0.82)
	env.ambient_light_energy = 0.7
	env.fog_enabled = true
	env.fog_light_color = Color(0.5, 0.62, 0.8)
	env.fog_density = 0.0022
	we.environment = env
	add_child(we)
	var sun := DirectionalLight3D.new()
	sun.light_energy = 1.15
	sun.light_color = Color(1.0, 0.96, 0.9)
	sun.shadow_enabled = Game.quality == 2
	sun.directional_shadow_mode = DirectionalLight3D.SHADOW_ORTHOGONAL
	sun.directional_shadow_max_distance = 60.0
	add_child(sun)
	sun.basis = Basis.looking_at(Vector3(-0.45, -0.8, -0.35))


## Places a real model from the downloaded packs. Batched into MultiMeshes (one draw call per model type).
func _prop(prefix: String, pos: Vector3, yaw := 0.0, collide := true, path := PROPS) -> float:
	var d := AssetLib.find(path, prefix)
	if d.is_empty():
		return 0.0
	var bb: AABB = d["aabb"]
	var c := bb.get_center()
	var base := Transform3D(Basis(Vector3.UP, yaw), pos)
	var xf := base * Transform3D(Basis.IDENTITY, Vector3(-c.x, -bb.position.y, -c.z))
	var key := "%d|%d|%d" % [(d["mesh"] as Mesh).get_instance_id(), int(floor((pos.x + 100.0) / 70.0)), int(floor((pos.z + 100.0) / 70.0))]
	if not _batches.has(key):
		_batches[key] = {"mesh": d["mesh"], "items": []}
	(_batches[key]["items"] as Array).append({"xf": xf, "c": AssetLib.tint(prefix, _tint_i)})
	_tint_i += 1
	if collide:
		var cs := CollisionShape3D.new()
		var bs := BoxShape3D.new()
		bs.size = bb.size
		cs.shape = bs
		cs.transform = base * Transform3D(Basis.IDENTITY, Vector3(0, bb.size.y * 0.5, 0))
		col_body.add_child(cs)
	return bb.size.y


func _stack(prefix: String, pos: Vector3, yaw: float, n: int) -> void:
	var y := 0.0
	for i in n:
		y += _prop(prefix, pos + Vector3(0, y, 0), yaw)


func _flush_props() -> void:
	for key in _batches:
		var mesh: Mesh = _batches[key]["mesh"]
		var xfs: Array = _batches[key]["items"]
		var mm := MultiMesh.new()
		mm.transform_format = MultiMesh.TRANSFORM_3D
		mm.mesh = mesh
		mm.instance_count = xfs.size()
		for i in xfs.size():
			mm.set_instance_transform(i, xfs[i]["xf"])
		var mmi := MultiMeshInstance3D.new()
		mmi.multimesh = mm
		mmi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON if Game.quality == 2 else GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		add_child(mmi)
	_batches.clear()


func _build_arena() -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = 2024
	var taken: Array = []   # [Vector2 centre, radius] to keep scatter props apart
	# ---- floor: real sci-fi road tiles
	var fl := AssetLib.find(STRUCT, "FLOORhall_Road")
	var fb := CollisionShape3D.new()
	var fs := BoxShape3D.new()
	fs.size = Vector3(SIZE * 2.6, 2, SIZE * 2.6)
	fb.shape = fs
	fb.position.y = -1
	col_body.add_child(fb)
	# ground slabs (real structure piece) under the road tiles so there are no gaps
	for gx in [-1.0, 1.0]:
		for gz in [-1.0, 1.0]:
			_prop("hallreactor_circ4500_ReactorOuterCeiling", Vector3(gx * 36.9, -2.06, gz * 31.2), 0.0, false, STRUCT)
	if not fl.is_empty():
		var bb: AABB = fl["aabb"]
		var nx := int(ceil(SIZE * 2.4 / bb.size.x))
		var nz := int(ceil(SIZE * 2.4 / bb.size.z))
		for ix in nx:
			for iz in nz:
				_prop("FLOORhall_Road", Vector3((ix - (nx - 1) * 0.5) * bb.size.x, -bb.size.y, (iz - (nz - 1) * 0.5) * bb.size.z), 0.0, false, STRUCT)
	# ---- perimeter: tall industrial hall wall panels + floodlights
	var pw := 20.4
	var n := int(ceil(SIZE * 2.0 / pw)) + 1
	for i in n:
		var t := -SIZE + i * pw
		_prop("hall_circ1125_upperdeckwall_0base", Vector3(t, 0, -SIZE - 0.8), 0.0, true, STRUCT)
		_prop("hall_circ1125_upperdeckwall_0base", Vector3(t, 0, SIZE + 0.8), PI, true, STRUCT)
		_prop("hall_circ1125_upperdeckwall_0base", Vector3(-SIZE - 0.8, 0, t), PI * 0.5, true, STRUCT)
		_prop("hall_circ1125_upperdeckwall_0base", Vector3(SIZE + 0.8, 0, t), -PI * 0.5, true, STRUCT)
	for i in 5:
		var t2 := -SIZE + 8.0 + i * (SIZE * 2.0 - 16.0) / 4.0
		_prop("prop_floodlight", Vector3(t2, 0, -SIZE + 2.0), 0.0, false)
		_prop("prop_floodlight", Vector3(t2, 0, SIZE - 2.0), PI, false)
		_prop("prop_floodlight", Vector3(-SIZE + 2.0, 0, t2), PI * 0.5, false)
		_prop("prop_floodlight", Vector3(SIZE - 2.0, 0, t2), -PI * 0.5, false)
	# ---- centre landmark: reactor machine ringed with barrels
	_prop("Reactor_greeblemachine", Vector3(0, 0, 0), 0.0)
	taken.append([Vector2(0, 0), 11.0])
	for k in 6:
		var a := TAU * k / 6.0
		_prop("prop_barrel", Vector3(cos(a) * 9.5, 0, sin(a) * 9.0), a)
	# ---- four container yards with crate stairs up to the roofs (trick-shot spots)
	for sx in [-1.0, 1.0]:
		for sz in [-1.0, 1.0]:
			var cx: float = sx * 32.0
			var cz: float = sz * 30.0
			_prop("prop_container", Vector3(cx - 1.55, 0, cz), 0.0)
			_prop("prop_container", Vector3(cx + 1.55, 0, cz), 0.0)
			_prop("prop_container", Vector3(cx, 0, cz + sz * 8.5), PI * 0.5)
			var dirx: float = -sx
			_stack("prop_cargobox1_a", Vector3(cx + dirx * 4.1, 0, cz), 0.0, 3)
			_stack("prop_cargobox1_a", Vector3(cx + dirx * 5.9, 0, cz), 0.0, 2)
			_stack("prop_cargobox1_a", Vector3(cx + dirx * 7.7, 0, cz), 0.0, 1)
			_prop("prop_pellet", Vector3(cx + dirx * 4.0, 0, cz + sz * 5.0), 0.3)
			taken.append([Vector2(cx, cz), 12.0])
	# ---- mid-field vehicles and beams
	for v in [Vector3(0, 0, -36), Vector3(0, 0, 36)]:
		_prop("scificar_dump", v, 1.57)
		taken.append([Vector2(v.x, v.z), 5.0])
	for v in [Vector3(-40, 0, 0), Vector3(40, 0, 0)]:
		_prop("prop_steelbeam", v + Vector3(0, 0, -6), 0.0)
		_prop("prop_steelbeam", v + Vector3(0, 0.8, -6), 0.0)
		_prop("prop_cargolift", v + Vector3(0, 0, 8), 0.0)
		taken.append([Vector2(v.x, v.z), 9.0])
	# ---- tables (cargo crates) with a real weapon on top
	for t in TABLE_SPOTS:
		var p: Vector3 = t[0]
		var h := _prop("prop_cargobox1_a", p, 0.0)
		var g := GunModel.build(t[1], 1.0)
		add_child(g)
		g.position = p + Vector3(0, h + 0.14, 0)
		g.rotation.y = PI * 0.5 + rng.randf() * 0.4
		tables.append({"node": g, "id": t[1], "pos": p + Vector3(0, h, 0), "t": 0.0})
		taken.append([Vector2(p.x, p.z), 3.2])
	for p2 in HEALTH_SPOTS + ARMOR_SPOTS:
		taken.append([Vector2(p2.x, p2.z), 2.5])
	# ---- scattered cover: barriers, crates, barrels, pallets, tanks, beams
	var kinds := ["prop_barrier", "prop_transitbarrierdirection", "prop_barrel", "prop_cargobox1_b", "prop_pellet", "prop_smallbox", "prop_gastriple", "prop_cargobox5a", "prop_barrel", "prop_transitbarrierdirection"]
	var placed := 0
	var tries := 0
	while placed < 80 and tries < 1500:
		tries += 1
		var pos := Vector3(rng.randf_range(-SIZE + 7.0, SIZE - 7.0), 0, rng.randf_range(-SIZE + 7.0, SIZE - 7.0))
		var ok := true
		for t3 in taken:
			if Vector2(pos.x, pos.z).distance_to(t3[0]) < float(t3[1]):
				ok = false
				break
		if not ok:
			continue
		var kind: String = kinds[rng.randi() % kinds.size()]
		var yaw := rng.randf() * PI
		if kind.begins_with("prop_cargobox"):
			_stack(kind, pos, yaw, 1 + rng.randi() % 2)
		else:
			_prop(kind, pos, yaw)
		taken.append([Vector2(pos.x, pos.z), 4.0])
		placed += 1
	_flush_props()


func _build_pickups() -> void:
	var box := AssetLib.find(PROPS, "prop_smallbox")
	for kind in ["health", "armor"]:
		var spots: Array = HEALTH_SPOTS if kind == "health" else ARMOR_SPOTS
		for sp in spots:
			var n := Node3D.new()
			add_child(n)
			n.position = sp + Vector3(0, 1.0, 0)
			if not box.is_empty():
				var mi := MeshInstance3D.new()
				mi.mesh = box["mesh"]
				var bb: AABB = box["aabb"]
				mi.position = -bb.get_center()
				var mat := StandardMaterial3D.new()
				mat.albedo_color = Color(0.2, 0.9, 0.4) if kind == "health" else Color(0.25, 0.6, 1.0)
				mat.metallic = 0.0
				mat.roughness = 0.6
				mat.emission_enabled = true
				mat.emission = mat.albedo_color
				mat.emission_energy_multiplier = 0.8
				mi.material_override = mat
				var holder := Node3D.new()
				holder.scale = Vector3.ONE * 0.7
				holder.add_child(mi)
				n.add_child(holder)
			pickups.append({"kind": kind, "node": n, "t": 0.0, "base": n.position.y})


# ------------------------------------------------------------------ queries used by fighters
func spawn_point() -> Vector3:
	for i in 12:
		var p := Vector3(randf_range(-SIZE + 8.0, SIZE - 8.0), 0.1, randf_range(-SIZE + 8.0, SIZE - 8.0))
		if absf(p.x) < 9.0 and absf(p.z) < 8.0:
			continue
		if not blocked(p + Vector3(0, 0.6, 0), Vector3.RIGHT, 1.0) and (not player or p.distance_to(player.global_position) > 14.0):
			return p
	return Vector3(-SIZE + 10.0, 0.1, -SIZE + 10.0)


func random_point() -> Vector3:
	return Vector3(randf_range(-SIZE + 8.0, SIZE - 8.0), 0.0, randf_range(-SIZE + 8.0, SIZE - 8.0))


func _ray(from: Vector3, to: Vector3, mask: int, exclude := []) -> Dictionary:
	var q := PhysicsRayQueryParameters3D.create(from, to, mask)
	q.exclude = exclude
	return get_world_3d().direct_space_state.intersect_ray(q)


func blocked(from: Vector3, dir: Vector3, dist: float) -> bool:
	return not _ray(from, from + dir * dist, 1).is_empty()


func has_los(from: Vector3, to: Vector3, who: Node) -> bool:
	return _ray(from, to, 1).is_empty()


func nearest_enemy(me: Fighter) -> Node3D:
	var best: Node3D = null
	var bd := 45.0
	var cands: Array = fighters.duplicate()
	cands.append(player)
	for c in cands:
		if c == me:
			continue
		if (c is Fighter and not (c as Fighter).alive) or (c is Player and not (c as Player).alive):
			continue
		var d := me.global_position.distance_to(c.global_position)
		if d < bd and has_los(me.head_pos(), c.global_position + Vector3(0, 1.3, 0), me):
			bd = d
			best = c
	return best


func _add_bot(nm: String, ch: int, weapon: String) -> void:
	var b := Fighter.new()
	add_child(b)
	b.setup(self, true, nm, ch, weapon)
	b.global_position = spawn_point()
	fighters.append(b)
	scores[nm] = {"k": 0, "d": 0, "pts": 0}


func bot_fire(bot: Fighter, target: Node3D, w: Dictionary, err: float) -> void:
	if not started or ended:
		return
	var from := bot.head_pos()
	var aim := target.global_position + Vector3(0, 1.2, 0) + Vector3(randf_range(-err, err), randf_range(-err, err), randf_range(-err, err)) * target.global_position.distance_to(from) * 0.6
	var dir := (aim - from).normalized()
	var d := bot.global_position.distance_to(player.global_position)
	if d < 40.0:
		Sfx.play(w["snd"], -8.0 - d * 0.3, randf_range(0.9, 1.1))
	var res := _ray(from, from + dir * 70.0, 1 | 2 | 4, [bot.get_rid()])
	var end := from + dir * 70.0
	if not res.is_empty():
		end = res["position"]
		var col: Object = res["collider"]
		if col is Player:
			(col as Player).take_damage(float(w["dmg"]) * 0.55 * maxf(1, int(w["pellets"]) * 0.5), bot.fname, false)
		elif col is Fighter:
			(col as Fighter).take_hit(float(w["dmg"]) * 0.5, false, bot.fname)
	_tracer(from + dir * 0.8, end)


# ------------------------------------------------------------------ player shooting
func player_fire(p: Player, w: Dictionary, wid: String, ads: bool, spread: float) -> void:
	var o := p.cam.global_position
	var b := p.cam.global_transform.basis
	Sfx.play(w["snd"], 0.0, randf_range(0.97, 1.03))
	var mpos := p.muzzle_pos()
	for i in int(w["pellets"]):
		var dir := (-b.z + b.x * randf_range(-spread, spread) + b.y * randf_range(-spread, spread)).normalized()
		var res := _ray(o, o + dir * 160.0, 1 | 2, [p.get_rid()])
		var end := o + dir * 160.0
		if not res.is_empty():
			end = res["position"]
			var col: Object = res["collider"]
			if col is Fighter:
				var f := col as Fighter
				var dist := o.distance_to(end)
				var hs: bool = end.y > f.global_position.y + 1.5
				var dmg := float(w["dmg"]) * (2.2 if hs else 1.0)
				if int(w["pellets"]) > 1:
					dmg *= clampf(1.0 - dist / 28.0, 0.25, 1.0)
				hud.hit_marker(hs)
				Sfx.play("headshot" if hs else "hitmarker", -4.0)
				_last_hit_ctx = {"dist": dist, "air": p.airborne, "noscope": (wid in ["sniper", "dmr"]) and not ads, "hs": hs}
				if f.is_bot:
					f.take_hit(dmg, hs, Game.player_name)
				else:
					Net.send({"t": "hit", "to": f.fid, "d": dmg, "hs": int(hs), "n": Game.player_name, "w": wid})
			else:
				_impact(end, res["normal"])
		_tracer(mpos, end)


func _tracer(a: Vector3, b: Vector3) -> void:
	var len := a.distance_to(b)
	if len < 0.5:
		return
	var mi := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = 0.008
	cm.bottom_radius = 0.008
	cm.height = len
	cm.radial_segments = 4
	cm.rings = 1
	mi.mesh = cm
	var m := StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.albedo_color = Color(1.0, 0.85, 0.5)
	mi.material_override = m
	add_child(mi)
	mi.global_position = (a + b) * 0.5
	mi.look_at(b, Vector3.UP if absf((b - a).normalized().y) < 0.99 else Vector3.RIGHT)
	mi.rotate_object_local(Vector3.RIGHT, PI * 0.5)
	var tw := create_tween()
	tw.tween_property(m, "albedo_color:a", 0.0, 0.08)
	tw.tween_callback(mi.queue_free)
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA


func _impact(pos: Vector3, normal: Vector3) -> void:
	var p: CPUParticles3D
	if _pool.size() < 8:
		p = CPUParticles3D.new()
		p.one_shot = true
		p.amount = 8
		p.lifetime = 0.35
		p.explosiveness = 1.0
		p.spread = 60.0
		p.initial_velocity_min = 2.0
		p.initial_velocity_max = 4.0
		p.gravity = Vector3(0, -9, 0)
		var q := QuadMesh.new()
		q.size = Vector2(0.06, 0.06)
		p.mesh = q
		var m := StandardMaterial3D.new()
		m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		m.albedo_color = Color(1.0, 0.8, 0.5)
		m.billboard_mode = BaseMaterial3D.BILLBOARD_ENABLED
		p.material_override = m
		add_child(p)
		_pool.append(p)
	else:
		p = _pool[randi() % _pool.size()]
	p.global_position = pos + normal * 0.05
	p.direction = normal
	p.restart()
	p.emitting = true


# ------------------------------------------------------------------ pickups
func try_pickup(p: Player) -> void:
	for t in tables:
		if t["t"] <= 0.0 and p.global_position.distance_to(t["pos"]) < 2.6:
			p.give_weapon(t["id"])
			t["t"] = 25.0
			(t["node"] as Node3D).visible = false
			Sfx.voice(Game.CHARS[Game.character]["id"], "pickup", 1, 6.0)
			return


func nearest_table(p: Player) -> Dictionary:
	for t in tables:
		if t["t"] <= 0.0 and p.global_position.distance_to(t["pos"]) < 2.6:
			return t
	return {}


func _process(delta: float) -> void:
	_time += delta
	for t in tables:
		if t["t"] > 0.0:
			t["t"] -= delta
			if t["t"] <= 0.0:
				(t["node"] as Node3D).visible = true
		else:
			(t["node"] as Node3D).rotation.y += delta * 0.6
	for pk in pickups:
		var n: Node3D = pk["node"]
		if pk["t"] > 0.0:
			pk["t"] -= delta
			n.visible = pk["t"] <= 0.0
			continue
		n.rotation.y += delta * 1.8
		n.position.y = pk["base"] + sin(_time * 2.5) * 0.1
		if player.alive and player.global_position.distance_to(n.global_position - Vector3(0, 1.0, 0)) < 1.3:
			if pk["kind"] == "health" and player.hp < 100.0:
				player.hp = minf(100.0, player.hp + 40.0)
				Sfx.play("pickup_health")
				pk["t"] = 20.0
			elif pk["kind"] == "armor" and player.armor < 100.0:
				player.armor = minf(100.0, player.armor + 50.0)
				Sfx.play("pickup_armor")
				pk["t"] = 20.0
			if pk["t"] > 0.0:
				n.visible = false
	if Net.room != "" and started and not ended:
		_net_t -= delta
		if _net_t <= 0.0:
			_net_t = 0.08
			_send_state(false)


# ------------------------------------------------------------------ match flow
func _countdown() -> void:
	player.frozen = true
	if Game.mode == "friend" and Net.peer_count() == 0:
		hud.banner("WAITING FOR YOUR FRIEND\nROOM CODE:  %s" % Game.room_code)
		while Net.peer_count() == 0 and is_inside_tree():
			await get_tree().create_timer(0.5).timeout
	hud.banner("")
	if Game.mode == "bots" or Game.mode == "friend" or Net.peer_count() == 0:
		for n in ["3", "2", "1"]:
			hud.announce(n, Color(1, 1, 1))
			Sfx.play("countdown")
			await get_tree().create_timer(0.8).timeout
	Sfx.announce("fight")
	Sfx.voice(Game.CHARS[Game.character]["id"], "start", 1, 0.0)
	hud.announce("FIGHT!", Color(1.0, 0.3, 0.2))
	player.frozen = false
	started = true
	_send_state(true)


func on_kill(killer: String, victim: String, hs: bool, wid: String) -> void:
	if ended:
		return
	if scores.has(victim):
		scores[victim]["d"] += 1
	var pts := 1
	var bonus := ""
	if scores.has(killer):
		if killer == Game.player_name and not _last_hit_ctx.is_empty():
			var extra := 0
			if _last_hit_ctx["hs"]: extra += 1; bonus += "HEADSHOT "
			if _last_hit_ctx["dist"] > 28.0: extra += 1; bonus += "LONG SHOT "
			if _last_hit_ctx["air"]: extra += 1; bonus += "AIR SHOT "
			if _last_hit_ctx["noscope"]: extra += 1; bonus += "NO SCOPE "
			pts += extra * int(Game.CHARS[Game.character]["bonus"])
		scores[killer]["k"] += 1
		scores[killer]["pts"] += pts
	hud.killfeed("%s  [%s]  %s%s" % [killer, Game.WEAPONS[wid]["name"].split(" ")[0] if Game.WEAPONS.has(wid) else "", victim, "  (HS)" if hs else ""])
	Sfx.announce("strikeout")
	if killer == Game.player_name:
		hud.announce("STRIKEOUT!", Color(1.0, 0.25, 0.25), "+%d  %s" % [pts, bonus.strip_edges()])
		Sfx.voice(Game.CHARS[Game.character]["id"], "kill", 3, 1.0)
		Sfx.play("hitmarker")
	if scores.has(killer) and scores[killer]["pts"] >= Game.TARGET_KILLS:
		_end(killer)


func player_died(by: String, hs: bool) -> void:
	_last_attacker = by
	Net.send({"t": "dead", "n": Game.player_name, "by": by, "hs": int(hs), "w": "rifle"})
	on_kill(by, Game.player_name, hs, "rifle")
	Sfx.play("death")
	player.frozen = true
	hud.announce("ELIMINATED", Color(0.9, 0.9, 0.9), "by %s" % by)
	await get_tree().create_timer(3.0).timeout
	if ended:
		return
	player.reset_loadout()
	player.global_position = spawn_point()
	player.velocity = Vector3.ZERO
	player.frozen = false


func _end(winner: String) -> void:
	ended = true
	player.frozen = true
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	var win := winner == Game.player_name
	Sfx.announce("victory" if win else "defeat")
	Sfx.voice(Game.CHARS[Game.character]["id"], "win" if win else "lose", 1, 0.0)
	hud.show_end(win, winner)


# ------------------------------------------------------------------ networking (client-authoritative, casual)
func _send_state(_hello: bool) -> void:
	if Net.room == "":
		return
	var p := player.global_position
	Net.send({"t": "st", "n": Game.player_name, "c": Game.character, "p": [snappedf(p.x, 0.01), snappedf(p.y, 0.01), snappedf(p.z, 0.01)],
		"y": snappedf(player.yaw, 0.01), "w": player.cur_id(), "a": int(player.alive)})


func _on_net(d: Dictionary) -> void:
	var f := String(d.get("f", ""))
	if f == "" or f == Net.self_id:
		return
	tid_map[String(d.get("tid", ""))] = f
	match String(d.get("t", "")):
		"st":
			var r: Fighter = remotes.get(f)
			if r == null:
				r = Fighter.new()
				add_child(r)
				r.setup(self, false, String(d["n"]), int(d["c"]), String(d["w"]))
				r.fid = f
				var pp: Array = d["p"]
				r.global_position = Vector3(pp[0], pp[1], pp[2])
				remotes[f] = r
				fighters.append(r)
				scores[r.fname] = {"k": 0, "d": 0, "pts": 0}
				hud.killfeed("%s joined" % r.fname)
				_send_state(true)
			var q: Array = d["p"]
			r.net_pos = Vector3(q[0], q[1], q[2])
			r.net_yaw = float(d["y"])
			r.alive = int(d["a"]) == 1
			r.model.visible = r.alive
			r.label.visible = r.alive
			r.collision_layer = 2 if r.alive else 0
			if r.weapon_id != String(d["w"]):
				r.weapon_id = String(d["w"])
				r._attach_gun()
		"hit":
			if String(d.get("to", "")) == Net.self_id:
				player.take_damage(float(d["d"]), String(d["n"]), int(d["hs"]) == 1)
		"dead":
			if String(d.get("n", "")) != Game.player_name:
				on_kill(String(d["by"]), String(d["n"]), int(d["hs"]) == 1, String(d.get("w", "rifle")))


func _on_peer_left(tid: String) -> void:
	var f: String = tid_map.get(tid, "")
	if f != "" and remotes.has(f):
		var r: Fighter = remotes[f]
		hud.killfeed("%s left" % r.fname)
		fighters.erase(r)
		remotes.erase(f)
		r.queue_free()
