class_name Fighter
extends CharacterBody3D
## A non-local combatant: AI bot or a remote (peer-to-peer) player puppet.

var arena
var is_bot := true
var fname := "BOT"
var fid := ""               # network id (remote players)
var char_idx := 0
var hp := 100.0
var armor := 0.0
var alive := true
var kills := 0
var deaths := 0
var weapon_id := "rifle"
var anim: AnimationPlayer
var amap := {}
var model: Node3D
var label: Label3D
var gun: Node3D

# bot brain
var target: Node3D
var _think := 0.0
var _fire_cd := 0.0
var _burst := 0
var _strafe := 1.0
var _wander := Vector3.ZERO
var _wander_t := 0.0
var _respawn := 0.0
var _acc := 0.05
# remote
var net_pos := Vector3.ZERO
var net_yaw := 0.0
var _last_pos := Vector3.ZERO


func setup(a, bot: bool, nm: String, ch: int, weapon: String) -> void:
	arena = a
	is_bot = bot
	fname = nm
	char_idx = ch
	weapon_id = weapon
	collision_layer = 2
	collision_mask = 1
	var cs := CollisionShape3D.new()
	var cap := CapsuleShape3D.new()
	cap.radius = 0.36
	cap.height = 1.8
	cs.shape = cap
	cs.position.y = 0.9
	add_child(cs)
	var m := Game.make_model(ch)
	model = m["root"]
	anim = m["anim"]
	amap = m["map"]
	add_child(model)
	label = Label3D.new()
	label.text = nm
	label.font_size = 40
	label.pixel_size = 0.005
	label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	label.no_depth_test = true
	label.modulate = Color(1.0, 0.35, 0.35)
	label.outline_size = 8
	label.position.y = 2.15
	add_child(label)
	_attach_gun()
	_acc = 0.045 + randf() * 0.03
	_pick_wander()


func _attach_gun() -> void:
	if gun:
		gun.queue_free()
	gun = GunModel.build(weapon_id, 1.0)
	var sk := model.find_children("*", "Skeleton3D", true, false)
	if sk.size() > 0:
		var skel := sk[0] as Skeleton3D
		var bi := skel.find_bone("hand.R")
		if bi >= 0:
			var att := BoneAttachment3D.new()
			att.bone_name = "hand.R"
			skel.add_child(att)
			att.add_child(gun)
			var sc := att.global_transform.basis.get_scale()
			gun.scale = Vector3(1.0 / maxf(sc.x, 0.0001), 1.0 / maxf(sc.y, 0.0001), 1.0 / maxf(sc.z, 0.0001))
			gun.rotation = Vector3(0, PI * 0.5, 0)
			return
	model.add_child(gun)
	gun.position = Vector3(0.25, 1.2, -0.3)


func head_pos() -> Vector3:
	return global_position + Vector3(0, 1.55, 0)


func chest_pos() -> Vector3:
	return global_position + Vector3(0, 1.1, 0)


## Damage applied locally (bots). Remote players are damaged by their own client (arena sends a message).
func take_hit(dmg: float, headshot: bool, attacker: String) -> void:
	if not alive or not is_bot:
		return
	var absorbed := minf(armor, dmg * 0.6)
	armor -= absorbed
	hp -= dmg - absorbed
	if hp <= 0.0:
		die(attacker, headshot)


func die(attacker: String, headshot: bool) -> void:
	alive = false
	deaths += 1
	collision_layer = 0
	Game.play_anim(anim, "idle", amap)
	var tw := create_tween()
	tw.tween_property(model, "rotation:x", -PI * 0.5, 0.45)
	tw.parallel().tween_property(label, "modulate:a", 0.0, 0.3)
	_respawn = 4.0
	arena.on_kill(attacker, fname, headshot, weapon_id)


func respawn_at(p: Vector3) -> void:
	hp = 100.0
	armor = 0.0
	alive = true
	collision_layer = 2
	global_position = p
	model.rotation.x = 0.0
	label.modulate.a = 1.0
	var ids := ["pistol", "rifle", "shotgun", "sniper"]
	weapon_id = ids[randi() % ids.size()]
	_attach_gun()
	target = null


func _pick_wander() -> void:
	_wander = arena.random_point()
	_wander_t = 5.0 + randf() * 4.0


func _physics_process(delta: float) -> void:
	if not alive:
		if is_bot:
			_respawn -= delta
			if _respawn <= 0.0:
				respawn_at(arena.spawn_point())
		return
	if is_bot:
		_bot(delta)
	else:
		global_position = global_position.lerp(net_pos, clampf(12.0 * delta, 0.0, 1.0))
		rotation.y = lerp_angle(rotation.y, net_yaw, clampf(14.0 * delta, 0.0, 1.0))
	if is_bot and arena.player:
		var far: bool = global_position.distance_to(arena.player.global_position) > 60.0
		model.visible = not far
		label.visible = not far
	var spd := (global_position - _last_pos).length() / maxf(delta, 0.001)
	_last_pos = global_position
	Game.play_anim(anim, "run" if spd > 4.0 else ("walk" if spd > 0.5 else "idle"), amap)


func _bot(delta: float) -> void:
	_think -= delta
	_fire_cd -= delta
	_wander_t -= delta
	if _think <= 0.0:
		_think = 0.35
		target = arena.nearest_enemy(self)
		_strafe = 1.0 if randf() > 0.5 else -1.0
	var move := Vector3.ZERO
	var speed := 4.2
	var los := false
	if target and is_instance_valid(target):
		var to: Vector3 = target.global_position - global_position
		to.y = 0.0
		var dist := to.length()
		los = arena.has_los(head_pos(), target.global_position + Vector3(0, 1.3, 0), self)
		var want_yaw := atan2(-to.x, -to.z)
		rotation.y = lerp_angle(rotation.y, want_yaw, clampf(7.0 * delta, 0.0, 1.0))
		var fwd := Vector3(-sin(rotation.y), 0, -cos(rotation.y))
		var side := fwd.cross(Vector3.UP)
		if los:
			if dist > 16.0:
				move = fwd
			elif dist < 6.0:
				move = -fwd * 0.6 + side * _strafe
			else:
				move = side * _strafe * 0.8
			_shoot_logic(dist)
		else:
			move = fwd
	else:
		var to2 := _wander - global_position
		to2.y = 0.0
		if to2.length() < 1.5 or _wander_t <= 0.0:
			_pick_wander()
		else:
			rotation.y = lerp_angle(rotation.y, atan2(-to2.x, -to2.z), clampf(5.0 * delta, 0.0, 1.0))
			move = Vector3(-sin(rotation.y), 0, -cos(rotation.y))
	# wall avoidance
	if move.length() > 0.1 and arena.blocked(global_position + Vector3(0, 0.5, 0), move.normalized(), 1.6):
		var side2 := move.normalized().cross(Vector3.UP)
		move = side2 * _strafe
		if target == null:
			_pick_wander()
	velocity.x = move.x * speed
	velocity.z = move.z * speed
	velocity.y = velocity.y - 22.0 * delta if not is_on_floor() else -0.5
	move_and_slide()


func _shoot_logic(dist: float) -> void:
	var w: Dictionary = Game.WEAPONS[weapon_id]
	if _fire_cd > 0.0:
		return
	_burst += 1
	var interval := 1.0 / float(w["rate"])
	if _burst >= (3 + randi() % 4):
		_burst = 0
		_fire_cd = 0.5 + randf() * 0.5
	else:
		_fire_cd = interval * (1.0 if w["auto"] else 1.6)
	arena.bot_fire(self, target, w, _acc + dist * 0.0025)
