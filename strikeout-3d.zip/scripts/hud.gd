extends CanvasLayer
## HUD: health + armor bars, ammo, crosshair, hit markers, scope, kill feed, announcer, scoreboard, multi-touch controls.

const NONE := -99
var arena
var player: Player
var ctl: Control
var _feed: Array = []
var _hit_t := 0.0
var _hit_hs := false
var _flash := 0.0
var _show_score := false
var _fps_t := 0.0
var _roles := {}
var _stick_id := NONE
var _stick_o := Vector2.ZERO
var _stick_p := Vector2.ZERO
var _lbl := {}
var _sb_bg: StyleBoxFlat
var _sb_fill: StyleBoxFlat
var _pick_available := false
var _end_panel: Control


func setup(a, p: Player) -> void:
	arena = a
	player = p
	layer = 10
	ctl = Control.new()
	ctl.set_anchors_preset(Control.PRESET_FULL_RECT)
	ctl.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ctl.draw.connect(_paint)
	add_child(ctl)
	_sb_bg = StyleBoxFlat.new()
	_sb_bg.bg_color = Color(0, 0, 0, 0.55)
	_sb_bg.set_corner_radius_all(8)
	_sb_fill = StyleBoxFlat.new()
	_sb_fill.set_corner_radius_all(8)
	_make_label("ammo", 54, Color.WHITE)
	_make_label("weapon", 22, Color(1, 1, 1, 0.8))
	_make_label("hp", 20, Color.WHITE)
	_make_label("score", 22, Color.WHITE)
	_make_label("announce", 96, Color(1, 0.25, 0.25))
	_make_label("sub", 30, Color(1, 0.9, 0.4))
	_make_label("banner", 40, Color.WHITE)
	_make_label("prompt", 26, Color(1, 0.9, 0.4))
	_make_label("fps", 16, Color(1, 1, 1, 0.5))
	for k in ["announce", "sub", "banner", "prompt"]:
		_lbl[k].horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		_lbl[k].set_anchors_preset(Control.PRESET_CENTER_TOP)
		_lbl[k].size = Vector2(1200, 100)
	_lbl["announce"].modulate.a = 0.0
	_lbl["sub"].modulate.a = 0.0


func _make_label(key: String, size_px: int, color: Color) -> void:
	var l := Label.new()
	l.add_theme_font_size_override("font_size", size_px)
	l.add_theme_color_override("font_color", color)
	l.add_theme_constant_override("outline_size", maxi(4, size_px / 7))
	l.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.9))
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ctl.add_child(l)
	_lbl[key] = l


# ---------------- API used by the arena ----------------
func hit_marker(hs: bool) -> void:
	_hit_t = 0.18
	_hit_hs = hs


func killfeed(t: String) -> void:
	_feed.append({"t": t, "ttl": 5.0})
	if _feed.size() > 5:
		_feed.pop_front()


func announce(text: String, color: Color, sub := "") -> void:
	var l: Label = _lbl["announce"]
	l.text = text
	l.add_theme_color_override("font_color", color)
	l.position = Vector2((ctl.size.x - 1200.0) * 0.5, ctl.size.y * 0.2)
	l.pivot_offset = Vector2(600, 50)
	l.scale = Vector2(1.6, 1.6)
	l.modulate.a = 1.0
	var tw := create_tween()
	tw.tween_property(l, "scale", Vector2.ONE, 0.18)
	tw.tween_interval(0.7)
	tw.tween_property(l, "modulate:a", 0.0, 0.35)
	var s: Label = _lbl["sub"]
	s.text = sub
	s.position = Vector2((ctl.size.x - 1200.0) * 0.5, ctl.size.y * 0.2 + 105.0)
	s.modulate.a = 1.0 if sub != "" else 0.0
	create_tween().tween_property(s, "modulate:a", 0.0, 1.4).set_delay(0.6)


func damage_flash() -> void:
	_flash = 0.55


func banner(t: String) -> void:
	_lbl["banner"].text = t
	_lbl["banner"].position = Vector2((ctl.size.x - 1200.0) * 0.5, ctl.size.y * 0.3)


func show_end(win: bool, winner: String) -> void:
	_end_panel = Control.new()
	_end_panel.set_anchors_preset(Control.PRESET_FULL_RECT)
	ctl.add_child(_end_panel)
	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, 0.7)
	dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	_end_panel.add_child(dim)
	var t := Label.new()
	t.text = "VICTORY" if win else "DEFEAT"
	t.add_theme_font_size_override("font_size", 120)
	t.add_theme_color_override("font_color", Color(0.2, 1.0, 0.5) if win else Color(1.0, 0.3, 0.3))
	t.add_theme_constant_override("outline_size", 16)
	t.position = Vector2(ctl.size.x * 0.5 - 330.0, 120.0)
	_end_panel.add_child(t)
	var w := Label.new()
	w.text = "%s WINS" % winner
	w.add_theme_font_size_override("font_size", 34)
	w.position = Vector2(ctl.size.x * 0.5 - 100.0, 270.0)
	_end_panel.add_child(w)
	_btn("PLAY AGAIN", Vector2(ctl.size.x * 0.5 - 330.0, 420.0), func(): get_tree().reload_current_scene())
	_btn("MAIN MENU", Vector2(ctl.size.x * 0.5 + 20.0, 420.0), func(): _to_menu())


func _btn(text: String, pos: Vector2, cb: Callable) -> void:
	var b := Button.new()
	b.text = text
	b.position = pos
	b.size = Vector2(310, 84)
	b.add_theme_font_size_override("font_size", 34)
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(1.0, 0.23, 0.3)
	sb.set_corner_radius_all(14)
	b.add_theme_stylebox_override("normal", sb)
	b.add_theme_stylebox_override("hover", sb)
	b.add_theme_stylebox_override("pressed", sb)
	b.pressed.connect(cb)
	_end_panel.add_child(b)


func _to_menu() -> void:
	Net.leave()
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	get_tree().change_scene_to_file("res://scenes/menu.tscn")


# ---------------- layout ----------------
func _fire_c() -> Vector2: return Vector2(ctl.size.x - 175.0, ctl.size.y - 190.0)
func _jump_c() -> Vector2: return Vector2(ctl.size.x - 350.0, ctl.size.y - 105.0)
func _aim_c() -> Vector2: return Vector2(ctl.size.x - 95.0, ctl.size.y - 375.0)
func _reload_c() -> Vector2: return Vector2(ctl.size.x - 310.0, ctl.size.y - 285.0)
func _swap_c() -> Vector2: return Vector2(ctl.size.x - 470.0, ctl.size.y - 215.0)
func _pick_c() -> Vector2: return Vector2(ctl.size.x * 0.5, ctl.size.y - 150.0)
func _menu_c() -> Vector2: return Vector2(ctl.size.x - 48.0, 48.0)
func _stick_c() -> Vector2: return Vector2(175.0, ctl.size.y - 170.0)


func _input(event: InputEvent) -> void:
	if _end_panel:
		return
	if event is InputEventScreenTouch:
		if event.pressed:
			_down(event.index, event.position)
		else:
			_up(event.index)
	elif event is InputEventScreenDrag:
		_drag(event.index, event.position, event.relative)
	elif event is InputEventKey and event.keycode == KEY_TAB:
		_show_score = event.pressed
	elif event is InputEventKey and event.pressed and event.keycode == KEY_ESCAPE:
		Input.mouse_mode = Input.MOUSE_MODE_VISIBLE


func _down(id: int, pos: Vector2) -> void:
	if pos.distance_to(_menu_c()) < 40.0:
		_to_menu()
		return
	if pos.y < 90.0 and absf(pos.x - ctl.size.x * 0.5) < 220.0:
		_show_score = not _show_score
		return
	if pos.distance_to(_fire_c()) < 100.0:
		_roles[id] = "fire"
		player.fire_held = true
	elif pos.distance_to(_jump_c()) < 66.0:
		_roles[id] = "jump"
		player.jump_req = true
	elif pos.distance_to(_aim_c()) < 62.0:
		_roles[id] = "aim"
		player.ads_req = not player.ads_req
	elif pos.distance_to(_reload_c()) < 58.0:
		_roles[id] = "reload"
		player.reload_req = true
	elif pos.distance_to(_swap_c()) < 56.0:
		_roles[id] = "swap"
		player.swap_req = true
	elif _pick_available and pos.distance_to(_pick_c()) < 80.0:
		_roles[id] = "pick"
		player.pick_req = true
	elif pos.x < ctl.size.x * 0.42 and _stick_id == NONE:
		_stick_id = id
		_stick_o = pos
		_stick_p = pos
		_roles[id] = "stick"
	else:
		_roles[id] = "look"


func _up(id: int) -> void:
	var r: String = _roles.get(id, "")
	if r == "fire":
		player.fire_held = false
	elif r == "stick":
		_stick_id = NONE
		player.move_vec = Vector2.ZERO
	_roles.erase(id)


func _drag(id: int, pos: Vector2, rel: Vector2) -> void:
	var r: String = _roles.get(id, "")
	if r == "stick":
		var d := pos - _stick_o
		if d.length() > 90.0:
			d = d.normalized() * 90.0
			_stick_o = pos - d
		_stick_p = _stick_o + d
		var v := d / 90.0
		player.move_vec = Vector2.ZERO if v.length() < 0.12 else v
	elif r == "look" or r == "fire" or r == "aim":
		player.look_delta += rel * 1.1


# ---------------- per frame ----------------
func _process(delta: float) -> void:
	_hit_t = maxf(0.0, _hit_t - delta)
	_flash = maxf(0.0, _flash - delta * 1.6)
	for f in _feed:
		f["ttl"] -= delta
	_feed = _feed.filter(func(f): return f["ttl"] > 0.0)
	_fps_t += delta
	var s: Dictionary = player.slots[player.cur]
	var w: Dictionary = player.cur_w()
	_lbl["ammo"].text = "%d / %d" % [s["mag"], s["reserve"]]
	_lbl["weapon"].text = String(w["name"])
	_lbl["hp"].text = "%d" % int(player.hp)
	var me: Dictionary = arena.scores.get(Game.player_name, {"pts": 0, "k": 0})
	var best := 0
	for k in arena.scores:
		best = maxi(best, int(arena.scores[k]["pts"]))
	_lbl["score"].text = "SCORE %d   |   FIRST TO %d   |   BEST %d" % [me["pts"], Game.TARGET_KILLS, best]
	_lbl["fps"].text = "%d FPS" % Engine.get_frames_per_second()
	_lbl["fps"].visible = not Game.minimal_hud
	var sz := ctl.size
	_lbl["ammo"].position = Vector2(sz.x - 520.0, sz.y - 120.0)
	_lbl["weapon"].position = Vector2(sz.x - 520.0, sz.y - 148.0)
	_lbl["hp"].position = Vector2(sz.x * 0.5 + 196.0, sz.y - 70.0)
	_lbl["score"].position = Vector2(sz.x * 0.5 - 250.0, 64.0)
	_lbl["fps"].position = Vector2(sz.x - 150.0, sz.y - 30.0)
	var near: Dictionary = arena.nearest_table(player)
	_pick_available = not near.is_empty() and player.alive
	_lbl["prompt"].text = ("PICK UP  %s   [E]" % Game.WEAPONS[near["id"]]["name"]) if _pick_available else ""
	_lbl["prompt"].position = Vector2((sz.x - 1200.0) * 0.5, sz.y - 235.0)
	ctl.queue_redraw()


func _paint() -> void:
	var sz := ctl.size
	var c := sz * 0.5
	# damage vignette
	if _flash > 0.0:
		ctl.draw_rect(Rect2(Vector2.ZERO, sz), Color(1, 0, 0, _flash * 0.35))
	var w: Dictionary = player.cur_w()
	var zoom: float = float(w["zoom"])
	var scoped := player.ads and zoom > 0.0 and player.cam.fov < zoom + 14.0
	if scoped:
		var r := sz.y * 0.42
		var wd := sz.length()
		ctl.draw_arc(c, r + wd * 0.5, 0.0, TAU, 96, Color(0, 0, 0, 1), wd)
		ctl.draw_arc(c, r, 0.0, TAU, 96, Color(0, 0, 0, 1), 4.0)
		ctl.draw_line(c - Vector2(r, 0), c + Vector2(r, 0), Color(0, 0, 0, 0.85), 2.0)
		ctl.draw_line(c - Vector2(0, r), c + Vector2(0, r), Color(0, 0, 0, 0.85), 2.0)
		ctl.draw_circle(c, 3.0, Color(1, 0.2, 0.2))
	else:
		var gap := 8.0 + player.spread_now() * 700.0
		var col := Color(1, 1, 1, 0.9)
		for d in [Vector2.UP, Vector2.DOWN, Vector2.LEFT, Vector2.RIGHT]:
			ctl.draw_line(c + d * gap, c + d * (gap + 11.0), col, 3.0)
		ctl.draw_circle(c, 2.0, col)
	if _hit_t > 0.0:
		var hc := Color(1.0, 0.2, 0.2) if _hit_hs else Color(1, 1, 1)
		var k := 14.0 + (1.0 - _hit_t / 0.18) * 6.0
		for d in [Vector2(1, 1), Vector2(-1, 1), Vector2(1, -1), Vector2(-1, -1)]:
			ctl.draw_line(c + d * 8.0, c + d * k, hc, 4.0)
	# health + armor
	var hc := Color(1.0, 0.3, 0.3) if player.hp < 35.0 else Color(1, 1, 1)
	_seg_bar(sz.x * 0.5 - 190.0, sz.y - 52.0, 380.0, 12.0, player.hp / 100.0, hc)
	_seg_bar(sz.x * 0.5 - 190.0, sz.y - 68.0, 380.0, 7.0, player.armor / 100.0, Color(0.3, 0.7, 1.0))
	_compass(sz.x * 0.5, 26.0)
	# kills box (top left, PUBG style)
	var me2: Dictionary = arena.scores.get(Game.player_name, {"k": 0})
	ctl.draw_style_box(_sb_bg, Rect2(26, 26, 150, 40))
	ctl.draw_string(ThemeDB.fallback_font, Vector2(38, 54), "KILLS  %d" % int(me2["k"]), HORIZONTAL_ALIGNMENT_LEFT, -1, 24, Color(1, 0.85, 0.3))
	# kill feed
	if not Game.minimal_hud:
		var y := 70.0
		for f in _feed:
			var t: String = f["t"]
			var tw := ThemeDB.fallback_font.get_string_size(t, HORIZONTAL_ALIGNMENT_LEFT, -1, 20).x + 24.0
			ctl.draw_style_box(_sb_bg, Rect2(sz.x - tw - 90.0, y, tw, 30))
			ctl.draw_string(ThemeDB.fallback_font, Vector2(sz.x - tw - 78.0, y + 22.0), t, HORIZONTAL_ALIGNMENT_LEFT, -1, 20, Color(1, 1, 1))
			y += 36.0
	# menu button
	ctl.draw_circle(_menu_c(), 26.0, Color(0, 0, 0, 0.45))
	ctl.draw_line(_menu_c() + Vector2(-9, -7), _menu_c() + Vector2(9, -7), Color.WHITE, 3.0)
	ctl.draw_line(_menu_c() + Vector2(-9, 0), _menu_c() + Vector2(9, 0), Color.WHITE, 3.0)
	ctl.draw_line(_menu_c() + Vector2(-9, 7), _menu_c() + Vector2(9, 7), Color.WHITE, 3.0)
	# touch controls (large, translucent, minimal)
	if DisplayServer.is_touchscreen_available() or true:
		var sc := _stick_o if _stick_id != NONE else _stick_c()
		var sp := _stick_p if _stick_id != NONE else sc
		ctl.draw_circle(sc, 90.0, Color(1, 1, 1, 0.08))
		ctl.draw_arc(sc, 90.0, 0.0, TAU, 40, Color(1, 1, 1, 0.35), 3.0)
		ctl.draw_circle(sp, 38.0, Color(1, 1, 1, 0.3))
		_icon_btn(_fire_c(), 88.0, "fire", Color(1.0, 0.25, 0.25), player.fire_held)
		_icon_btn(_jump_c(), 52.0, "jump", Color(1, 1, 1), false)
		_icon_btn(_aim_c(), 50.0, "aim", Color(0.3, 0.8, 1.0), player.ads_req)
		_icon_btn(_reload_c(), 46.0, "reload", Color(1, 1, 1), false)
		_icon_btn(_swap_c(), 44.0, "swap", Color(1, 1, 1), false)
		if _pick_available:
			_icon_btn(_pick_c(), 58.0, "pick", Color(1.0, 0.8, 0.2), true, "PICK UP")
	# scoreboard
	if _show_score:
		var rows: Array = arena.scores.keys()
		rows.sort_custom(func(a, b): return arena.scores[a]["pts"] > arena.scores[b]["pts"])
		var h := 60.0 + rows.size() * 34.0
		var r := Rect2(sz.x * 0.5 - 260.0, 110.0, 520.0, h)
		ctl.draw_style_box(_sb_bg, r)
		ctl.draw_string(ThemeDB.fallback_font, r.position + Vector2(24, 38), "SCOREBOARD            PTS    K    D", HORIZONTAL_ALIGNMENT_LEFT, -1, 22, Color(1, 0.8, 0.3))
		var yy := 76.0
		for n in rows:
			var sc2: Dictionary = arena.scores[n]
			var mine: bool = n == Game.player_name
			ctl.draw_string(ThemeDB.fallback_font, r.position + Vector2(24, yy), "%-14s" % n, HORIZONTAL_ALIGNMENT_LEFT, -1, 22, Color(0.4, 1, 0.6) if mine else Color.WHITE)
			ctl.draw_string(ThemeDB.fallback_font, r.position + Vector2(300, yy), "%d" % sc2["pts"], HORIZONTAL_ALIGNMENT_LEFT, -1, 22, Color.WHITE)
			ctl.draw_string(ThemeDB.fallback_font, r.position + Vector2(380, yy), "%d" % sc2["k"], HORIZONTAL_ALIGNMENT_LEFT, -1, 22, Color.WHITE)
			ctl.draw_string(ThemeDB.fallback_font, r.position + Vector2(445, yy), "%d" % sc2["d"], HORIZONTAL_ALIGNMENT_LEFT, -1, 22, Color.WHITE)
			yy += 34.0


func _bar(r: Rect2, ratio: float, col: Color) -> void:
	ctl.draw_style_box(_sb_bg, r)
	if ratio > 0.01:
		_sb_fill.bg_color = col
		ctl.draw_style_box(_sb_fill, Rect2(r.position + Vector2(2, 2), Vector2((r.size.x - 4.0) * clampf(ratio, 0.0, 1.0), r.size.y - 4.0)))


func _icon_btn(c: Vector2, r: float, kind: String, col: Color, active: bool, label := "") -> void:
	# soft shadow, dark glass fill, bright ring, glossy highlight
	ctl.draw_circle(c + Vector2(0, 5), r + 3.0, Color(0, 0, 0, 0.28))
	ctl.draw_circle(c, r, Color(0.04, 0.05, 0.08, 0.55 if not active else 0.8))
	if active:
		ctl.draw_circle(c, r * 0.92, Color(col.r, col.g, col.b, 0.35))
	ctl.draw_arc(c, r, 0.0, TAU, 56, Color(1, 1, 1, 0.9 if active else 0.7), 3.5, true)
	ctl.draw_arc(c, r - 7.0, PI * 1.1, PI * 1.9, 24, Color(1, 1, 1, 0.22), 3.0, true)
	var w := Color(1, 1, 1, 0.97)
	var k := r * 0.46
	match kind:
		"fire":
			for i in 3:
				var x := (i - 1) * k * 0.62
				var tilt := (i - 1) * 0.12
				var bx := c + Vector2(x, 0)
				var rot := Transform2D(tilt, bx)
				var body := PackedVector2Array([Vector2(-k * 0.2, k * 0.55), Vector2(-k * 0.2, -k * 0.25), Vector2(0, -k * 0.7), Vector2(k * 0.2, -k * 0.25), Vector2(k * 0.2, k * 0.55)])
				var pts := PackedVector2Array()
				for v in body:
					pts.append(rot * v)
				ctl.draw_colored_polygon(pts, w if i == 1 else Color(1, 1, 1, 0.75))
			ctl.draw_arc(c, r * 0.78, 0.0, TAU, 40, Color(col.r, col.g, col.b, 0.9), 3.0, true)
		"jump":
			ctl.draw_polyline(PackedVector2Array([c + Vector2(-k, k * 0.35), c + Vector2(0, -k * 0.55), c + Vector2(k, k * 0.35)]), w, 6.0, true)
			ctl.draw_line(c + Vector2(-k * 0.7, k * 0.85), c + Vector2(k * 0.7, k * 0.85), Color(1, 1, 1, 0.7), 5.0, true)
		"reload":
			ctl.draw_arc(c, k * 0.95, -PI * 0.15, PI * 1.55, 32, w, 5.0, true)
			var tip := c + Vector2(cos(-PI * 0.15), sin(-PI * 0.15)) * k * 0.95
			ctl.draw_colored_polygon(PackedVector2Array([tip + Vector2(-k * 0.05, -k * 0.55), tip + Vector2(k * 0.5, k * 0.15), tip + Vector2(-k * 0.5, k * 0.2)]), w)
		"aim":
			ctl.draw_arc(c, k * 0.9, 0.0, TAU, 32, w, 4.0, true)
			for d in [Vector2.UP, Vector2.DOWN, Vector2.LEFT, Vector2.RIGHT]:
				ctl.draw_line(c + d * k * 0.55, c + d * k * 1.35, w, 4.0, true)
			ctl.draw_circle(c, 3.5, Color(col.r, col.g, col.b, 1.0))
		"swap":
			ctl.draw_line(c + Vector2(-k, -k * 0.35), c + Vector2(k, -k * 0.35), w, 5.0, true)
			ctl.draw_colored_polygon(PackedVector2Array([c + Vector2(k * 1.1, -k * 0.35), c + Vector2(k * 0.55, -k * 0.8), c + Vector2(k * 0.55, k * 0.1)]), w)
			ctl.draw_line(c + Vector2(k, k * 0.45), c + Vector2(-k, k * 0.45), w, 5.0, true)
			ctl.draw_colored_polygon(PackedVector2Array([c + Vector2(-k * 1.1, k * 0.45), c + Vector2(-k * 0.55, k * 0.0), c + Vector2(-k * 0.55, k * 0.9)]), w)
		"pick":
			ctl.draw_line(c + Vector2(0, -k * 0.9), c + Vector2(0, k * 0.3), w, 6.0, true)
			ctl.draw_colored_polygon(PackedVector2Array([c + Vector2(-k * 0.6, k * 0.0), c + Vector2(k * 0.6, k * 0.0), c + Vector2(0, k * 0.65)]), w)
			ctl.draw_polyline(PackedVector2Array([c + Vector2(-k, k * 0.45), c + Vector2(-k, k * 0.95), c + Vector2(k, k * 0.95), c + Vector2(k, k * 0.45)]), w, 4.0, true)
	if label != "":
		var f := ThemeDB.fallback_font
		var fs := 15
		var ts := f.get_string_size(label, HORIZONTAL_ALIGNMENT_LEFT, -1, fs)
		ctl.draw_string(f, c + Vector2(-ts.x * 0.5, r + 20.0), label, HORIZONTAL_ALIGNMENT_LEFT, -1, fs, Color(1, 1, 1, 0.85))


func _seg_bar(x: float, y: float, w: float, h: float, ratio: float, col: Color, segs := 20) -> void:
	var gap := 3.0
	var sw := (w - gap * (segs - 1)) / segs
	for i in segs:
		var on := (float(i) + 0.5) / segs <= ratio
		var rc := Rect2(x + i * (sw + gap), y, sw, h)
		ctl.draw_style_box(_sb_bg, rc)
		if on:
			_sb_fill.bg_color = col
			_sb_fill.set_corner_radius_all(3)
			ctl.draw_style_box(_sb_fill, rc.grow(-1.0))


func _compass(cx: float, y: float) -> void:
	var heading := fposmod(-rad_to_deg(player.yaw), 360.0)
	var wpx := 560.0
	var f := ThemeDB.fallback_font
	ctl.draw_rect(Rect2(cx - wpx * 0.5, y - 4.0, wpx, 36.0), Color(0, 0, 0, 0.35))
	for d in range(-45, 46, 5):
		var deg := fposmod(heading + d, 360.0)
		var snap := roundi(deg / 5.0) * 5
		if snap % 5 != 0 or absf(deg - snap) > 0.01 and false:
			continue
	for step in range(0, 360, 15):
		var rel := fposmod(float(step) - heading + 180.0, 360.0) - 180.0
		if absf(rel) > 45.0:
			continue
		var x := cx + rel / 45.0 * (wpx * 0.5)
		var major := step % 45 == 0
		ctl.draw_line(Vector2(x, y + 2.0), Vector2(x, y + (14.0 if major else 8.0)), Color(1, 1, 1, 0.85 if major else 0.5), 2.0)
		if major:
			var names := {0: "N", 45: "NE", 90: "E", 135: "SE", 180: "S", 225: "SW", 270: "W", 315: "NW"}
			var t: String = names[step]
			ctl.draw_string(f, Vector2(x - f.get_string_size(t, HORIZONTAL_ALIGNMENT_LEFT, -1, 16).x * 0.5, y + 30.0), t, HORIZONTAL_ALIGNMENT_LEFT, -1, 16, Color(1, 0.85, 0.3) if t == "N" else Color.WHITE)
	ctl.draw_colored_polygon(PackedVector2Array([Vector2(cx - 7, y - 8), Vector2(cx + 7, y - 8), Vector2(cx, y + 2)]), Color(1, 0.3, 0.3))
	ctl.draw_string(f, Vector2(cx - 14.0, y - 12.0), "%d" % int(heading), HORIZONTAL_ALIGNMENT_LEFT, -1, 15, Color(1, 1, 1, 0.9))
