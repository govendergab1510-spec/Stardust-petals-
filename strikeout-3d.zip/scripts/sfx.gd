extends Node
## ElevenLabs audio player (autoload "Sfx"). Silent (no crash) if a clip is missing.
const DIR := "res://assets/audio/"
var _pool: Array[AudioStreamPlayer] = []
var _voice: AudioStreamPlayer
var _ann: AudioStreamPlayer
var _cache := {}
var _last_voice := 0.0


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	for i in 10:
		var p := AudioStreamPlayer.new()
		add_child(p)
		_pool.append(p)
	_voice = AudioStreamPlayer.new()
	_voice.volume_db = 3.0
	add_child(_voice)
	_ann = AudioStreamPlayer.new()
	_ann.volume_db = 4.0
	add_child(_ann)


func _stream(id: String) -> AudioStream:
	if _cache.has(id):
		return _cache[id]
	var p := DIR + id + ".mp3"
	var s: AudioStream = load(p) as AudioStream if ResourceLoader.exists(p) else null
	_cache[id] = s
	return s


func play(id: String, vol := 0.0, pitch := 1.0) -> void:
	var s: AudioStream = _stream(id)
	if s == null:
		return
	for p in _pool:
		if not p.playing:
			p.stream = s
			p.volume_db = vol
			p.pitch_scale = pitch
			p.play()
			return


## Character voice line: id like "rush_kill" picks rush_kill1..N randomly (N = variants in data/audio.json).
func voice(char_id: String, key: String, variants := 1, cooldown := 1.5) -> void:
	if not Game.CHARACTER_VOICES:
		return
	var now := Time.get_ticks_msec() / 1000.0
	if now - _last_voice < cooldown:
		return
	var id := "%s_%s%d" % [char_id, key, randi_range(1, variants)] if variants > 1 else "%s_%s" % [char_id, key]
	var s: AudioStream = _stream(id)
	if s == null:
		return
	_last_voice = now
	_voice.stream = s
	_voice.play()


func announce(key: String) -> void:
	var s: AudioStream = _stream("ann_" + key)
	if s == null:
		return
	_ann.stream = s
	_ann.play()
