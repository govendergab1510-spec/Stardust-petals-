extends Node
## Peer-to-peer layer (autoload "Net"). Talks to window.StrikeNet (Trystero, loaded by index.html). No game server.
signal peer_msg(d: Dictionary)
signal peer_joined(tid: String)
signal peer_left(tid: String)

var available := false
var self_id := ""
var room := ""
var _b


func _ready() -> void:
	if OS.has_feature("web"):
		_b = JavaScriptBridge.get_interface("StrikeNet")
		available = _b != null
		if available:
			self_id = str(_b.selfId)
	if self_id == "":
		self_id = str(randi() % 900000 + 100000)


func join(r: String) -> void:
	room = r
	if available:
		_b.join(r)


func leave() -> void:
	if available and room != "":
		_b.leave()
	room = ""


func peer_count() -> int:
	return int(_b.peerCount()) if (available and room != "") else 0


func send(d: Dictionary) -> void:
	if not available or room == "":
		return
	d["f"] = self_id
	_b.send(JSON.stringify(d))


func _process(_delta: float) -> void:
	if not available or room == "":
		return
	var s := str(_b.poll())
	if s == "":
		return
	var arr = JSON.parse_string(s)
	if not (arr is Array):
		return
	for ev in arr:
		match String(ev.get("t", "")):
			"msg":
				var d = JSON.parse_string(str(ev.get("d", "")))
				if d is Dictionary:
					d["tid"] = str(ev.get("id", ""))
					peer_msg.emit(d)
			"join":
				peer_joined.emit(str(ev.get("id", "")))
			"leave":
				peer_left.emit(str(ev.get("id", "")))
