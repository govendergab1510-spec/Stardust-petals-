// STRIKEOUT 3D - peer-to-peer layer (Trystero, WebRTC, no game server). Godot polls the event queue every frame.
import { joinRoom } from 'trystero';
const selfId = Math.random().toString(36).slice(2, 10);

const APP_ID = 'strikeout3d-github-pages-v1';
let room = null, sendFn = null, queue = [];

window.StrikeNet = {
  ready: true,
  selfId,
  join(roomId) {
    this.leave();
    queue = [];
    room = joinRoom({ appId: APP_ID }, String(roomId));
    const [send, get] = room.makeAction('s');
    sendFn = send;
    get((data, peerId) => queue.push({ t: 'msg', id: peerId, d: data }));
    room.onPeerJoin((id) => queue.push({ t: 'join', id }));
    room.onPeerLeave((id) => queue.push({ t: 'leave', id }));
  },
  send(json) { if (sendFn) { try { sendFn(String(json)); } catch (e) {} } },
  poll() {
    if (!queue.length) return '';
    const out = JSON.stringify(queue);
    queue = [];
    return out;
  },
  peerCount() { return room ? Object.keys(room.getPeers()).length : 0; },
  leave() {
    if (room) { try { room.leave(); } catch (e) {} }
    room = null; sendFn = null;
  },
};
