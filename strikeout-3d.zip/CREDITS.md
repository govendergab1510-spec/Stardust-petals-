# Credits

- **Characters (Player robot = RUSH, Red robot = ACE), sci-fi props and structure pieces**: Godot "Third Person Shooter" demo assets,
  licensed **CC-BY 3.0** (credit: the Godot Engine contributors / demo artists). https://github.com/godotengine/tps-demo
- **Textures (containers, crates, asphalt, metal tiles, robot skins)**: same Godot TPS demo, CC-BY 3.0.
- **Weapons (pistol, AK-47, shotgun, sniper)**: "Free Low Poly Weapons Pack" by **amaraha**, colour palette by Imphenzia, via
  https://github.com/Jeh3no/Godot-Simple-FPS-Weapon-System-Asset (check the pack's licence before commercial release).
- **Networking**: Trystero (MIT) https://github.com/dmotz/trystero
- Sound effects + announcer: generated with ElevenLabs by the repo owner.
- Everything is downloaded at build time by `tools/fetch_assets.py`; no models are stored in the repo.
