# Credits

- **Shino** (3D character): "Sendagaya Shino" VRoid Studio sample model by pixiv Inc. - **CC0 1.0** (public domain).
  Downloaded at build time from github.com/madjin/vrm-samples (pinned commit). Credit is not required but given here with thanks.
- Voices and sound effects: generated with the ElevenLabs API by the repo owner.
- Everything else (code, shaders, story, NPCs, city) is original to this project.
