class_name Baker
extends RefCounted
## Merges many primitive meshes into ONE ArrayMesh with vertex colours.
## 40 separate boxes/spheres = 40 draw calls on a phone; baked = 1.

var _verts := PackedVector3Array()
var _norms := PackedVector3Array()
var _cols := PackedColorArray()
var _idx := PackedInt32Array()


func add(mesh: Mesh, xf: Transform3D, color: Color) -> void:
	var arr := mesh.surface_get_arrays(0)
	var v: PackedVector3Array = arr[Mesh.ARRAY_VERTEX]
	var n: PackedVector3Array = arr[Mesh.ARRAY_NORMAL]
	var ix: PackedInt32Array = arr[Mesh.ARRAY_INDEX]
	var base := _verts.size()
	var lin := color.srgb_to_linear()
	var nb := xf.basis.inverse().transposed()
	for i in v.size():
		_verts.append(xf * v[i])
		_norms.append((nb * n[i]).normalized())
		_cols.append(lin)
	for i in ix.size():
		_idx.append(ix[i] + base)


func is_empty() -> bool:
	return _verts.is_empty()


func build() -> ArrayMesh:
	var arrays := []
	arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX] = _verts
	arrays[Mesh.ARRAY_NORMAL] = _norms
	arrays[Mesh.ARRAY_COLOR] = _cols
	arrays[Mesh.ARRAY_INDEX] = _idx
	var m := ArrayMesh.new()
	m.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
	return m


# --- primitive factories (low-poly on purpose)
static func box(size: Vector3) -> BoxMesh:
	var m := BoxMesh.new()
	m.size = size
	return m


static func sphere(r: float, segs := 10) -> SphereMesh:
	var m := SphereMesh.new()
	m.radius = r
	m.height = r * 2.0
	m.radial_segments = segs
	m.rings = maxi(segs / 2, 3)
	return m


static func cyl(r_top: float, r_bottom: float, h: float, segs := 12) -> CylinderMesh:
	var m := CylinderMesh.new()
	m.top_radius = r_top
	m.bottom_radius = r_bottom
	m.height = h
	m.radial_segments = segs
	m.rings = 1
	return m


static func capsule(r: float, h: float, segs := 10) -> CapsuleMesh:
	var m := CapsuleMesh.new()
	m.radius = r
	m.height = h
	m.radial_segments = segs
	m.rings = 3
	return m
