extends CanvasLayer
## Visual-novel style dialogue: name plate, typewriter text, voice playback, tap to continue.
## Narrator lines are shown centred over a dim overlay and auto-advance after the voice ends.

signal _advance
signal line_started(line: Dictionary)

var speaking := false  ## true while the current line is being voiced / typed (drives mouth animation)

var _root: Control
var _dim: ColorRect
var _panel: Panel
var _plate: Panel
var _plate_label: Label
var _text: Label
var _center: Label
var _arrow: Label
var _typing := false
var _active := false
var _serial := 0
var _tw: Tween


func _ready() -> void:
	layer = 20
	_root = Control.new()
	_root.set_anchors_preset(Control.PRESET_FULL_RECT)
	_root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_root.visible = false
	add_child(_root)

	_dim = ColorRect.new()
	_dim.color = Color(0, 0, 0, 0.55)
	_dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	_dim.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_root.add_child(_dim)

	_center = Label.new()
	_center.set_anchors_preset(Control.PRESET_FULL_RECT)
	_center.offset_left = 140
	_center.offset_right = -140
	_center.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_center.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	_center.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_center.add_theme_font_size_override("font_size", 34)
	_center.add_theme_color_override("font_color", Color("#dfe6ff"))
	_center.add_theme_constant_override("outline_size", 8)
	_center.add_theme_color_override("font_outline_color", Color(0.02, 0.01, 0.08))
	_center.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_root.add_child(_center)

	_panel = Panel.new()
	_panel.anchor_left = 0.04
	_panel.anchor_right = 0.96
	_panel.anchor_top = 1.0
	_panel.anchor_bottom = 1.0
	_panel.offset_top = -176
	_panel.offset_bottom = -22
	_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_root.add_child(_panel)

	_plate = Panel.new()
	_plate.position = Vector2(34, -26)
	_plate.size = Vector2(190, 44)
	_plate.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_panel.add_child(_plate)
	_plate_label = Label.new()
	_plate_label.set_anchors_preset(Control.PRESET_FULL_RECT)
	_plate_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_plate_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	_plate_label.add_theme_font_size_override("font_size", 26)
	_plate_label.add_theme_color_override("font_color", Color(0.06, 0.03, 0.14))
	_plate.add_child(_plate_label)

	_text = Label.new()
	_text.set_anchors_preset(Control.PRESET_FULL_RECT)
	_text.offset_left = 34
	_text.offset_right = -34
	_text.offset_top = 28
	_text.offset_bottom = -14
	_text.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_text.add_theme_font_size_override("font_size", 28)
	_text.add_theme_color_override("font_color", Color(0.97, 0.97, 1.0))
	_text.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_panel.add_child(_text)

	_arrow = Label.new()
	_arrow.text = "v"
	_arrow.add_theme_font_size_override("font_size", 26)
	_arrow.add_theme_color_override("font_color", Color(1, 1, 1, 0.9))
	_arrow.anchor_left = 1.0
	_arrow.anchor_right = 1.0
	_arrow.anchor_top = 1.0
	_arrow.anchor_bottom = 1.0
	_arrow.offset_left = -50
	_arrow.offset_top = -44
	_panel.add_child(_arrow)
	var bt := create_tween().set_loops()
	bt.tween_property(_arrow, "modulate:a", 0.2, 0.5)
	bt.tween_property(_arrow, "modulate:a", 1.0, 0.5)


func _style_panel(accent: Color) -> void:
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.04, 0.03, 0.13, 0.86)
	sb.set_corner_radius_all(16)
	sb.border_width_top = 4
	sb.border_width_bottom = 1
	sb.border_width_left = 1
	sb.border_width_right = 1
	sb.border_color = accent
	sb.shadow_color = Color(0, 0, 0, 0.45)
	sb.shadow_size = 10
	_panel.add_theme_stylebox_override("panel", sb)
	var pb := StyleBoxFlat.new()
	pb.bg_color = accent
	pb.set_corner_radius_all(12)
	_plate.add_theme_stylebox_override("panel", pb)


func run(lines: Array) -> void:
	Game.input_locked = true
	Game.move_vec = Vector2.ZERO
	_active = true
	_root.visible = true
	for line in lines:
		await _play_line(line)
	_active = false
	speaking = false
	_root.visible = false
	Sfx.stop_voice()
	Game.input_locked = false


func _play_line(line: Dictionary) -> void:
	_serial += 1
	var my := _serial
	var who := String(line.get("who", "narrator"))
	var text := String(line.get("text", ""))
	var info := Game.voice_info(who)
	var narrator := who == "narrator"
	_dim.visible = narrator
	_panel.visible = not narrator
	_center.visible = narrator
	var lbl := _center if narrator else _text
	if not narrator:
		_style_panel(Color(String(info.get("color", "#ffffff"))))
		_plate_label.text = String(info.get("name", ""))
	lbl.text = text
	lbl.visible_ratio = 0.0
	_arrow.visible = false

	var vlen := Sfx.say(String(line.get("id", "")))
	line_started.emit(line)
	var d := clampf(text.length() * 0.03, 0.5, 6.0)
	if vlen > 0.0:
		d = clampf(vlen * 0.92, 0.5, 14.0)

	_typing = true
	if _tw:
		_tw.kill()
	_tw = create_tween()
	_tw.tween_property(lbl, "visible_ratio", 1.0, d)
	_tw.finished.connect(_on_typed)
	if narrator and vlen > 0.0:
		get_tree().create_timer(vlen + 0.9).timeout.connect(func():
			if my == _serial and _active:
				_advance.emit())
	await _advance


func _process(_delta: float) -> void:
	speaking = _active and (_typing or Sfx.is_voice_playing())


func _on_typed() -> void:
	_typing = false
	_arrow.visible = not _center.visible


func _input(event: InputEvent) -> void:
	if not _active or not Game.is_tap(event):
		return
	get_viewport().set_input_as_handled()
	if _typing:
		if _tw:
			_tw.kill()
		(_center if _center.visible else _text).visible_ratio = 1.0
		_typing = false
		_arrow.visible = not _center.visible
	else:
		_advance.emit()
