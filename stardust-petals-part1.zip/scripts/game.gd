extends Node
## Global game state + shared touch-input state (autoload "Game").

const DELIVERY_TOTAL := 5
## Set to false if the game runs below 30 FPS on a very weak phone: removes the character outlines
## (about 40% fewer triangles). Everything else stays the same.
const OUTLINES := true
const STORY_PATH := "res://data/story.json"

signal delivered_changed(count: int)

var story: Dictionary = {}
var delivered := 0
var input_locked := false

# Shared input state written by the HUD, read by the player.
var move_vec := Vector2.ZERO
var look_delta := Vector2.ZERO
var jump_req := false
var talk_req := false
var can_talk := false


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	Engine.max_fps = 60
	var res = load(STORY_PATH)
	if res is JSON:
		story = res.data
	else:
		push_error("story.json missing or unreadable")


func scene_lines(key: String) -> Array:
	return story.get("scenes", {}).get(key, [])


func voice_info(who: String) -> Dictionary:
	return story.get("voices", {}).get(who, {"name": who, "color": "#ffffff"})


func reset_run() -> void:
	delivered = 0
	input_locked = false
	move_vec = Vector2.ZERO
	look_delta = Vector2.ZERO
	jump_req = false
	talk_req = false
	can_talk = false


func add_delivery() -> int:
	delivered += 1
	delivered_changed.emit(delivered)
	return delivered


## True when the event is a "tap" (touch, click, or Space/Enter/E on desktop).
static func is_tap(event: InputEvent) -> bool:
	if event is InputEventScreenTouch:
		return event.pressed
	if event is InputEventMouseButton:
		return event.pressed and event.button_index == MOUSE_BUTTON_LEFT
	if event is InputEventKey:
		return event.pressed and not event.echo and (event.keycode == KEY_SPACE or event.keycode == KEY_ENTER or event.keycode == KEY_E)
	return false
