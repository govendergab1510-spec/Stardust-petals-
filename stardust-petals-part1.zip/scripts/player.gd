class_name Player
extends CharacterBody3D
## Third-person controller for Shino: stick-relative movement, jump, orbit camera and a cinematic
## "close-up" camera used during dialogue. Animation is procedural (see girl.gd).

const SPEED_RUN := 5.4
const GRAVITY := 24.0
const JUMP_V := 7.8
const ARENA_R := 27.0

var girl: Girl
var model_root: Node3D
var rig: Node3D
var pitch_node: Node3D
var cam: Camera3D
var yaw := 0.0
var pitch := -0.18
var cam_dist := 4.6
var frozen := false
var closeup := false
var closeup_side := 0.5
var talking := false

var _step_t := 0.0


func build() -> void:
	floor_snap_length = 0.35
	var col := CollisionShape3D.new()
	var cap := CapsuleShape3D.new()
	cap.radius = 0.32
	cap.height = 1.5
	col.shape = cap
	col.position.y = 0.75
	add_child(col)

	model_root = Node3D.new()
	add_child(model_root)
	girl = Girl.new()
	model_root.add_child(girl)
	if not girl.load_model():
		push_warning("Shino model missing - run tools/fetch_assets.py. Using a fallback capsule.")
		var body := MeshInstance3D.new()
		var cm := CapsuleMesh.new()
		cm.radius = 0.3
		cm.height = 1.5
		body.mesh = cm
		body.position.y = 0.8
		model_root.add_child(body)

	rig = Node3D.new()
	rig.position.y = 1.3
	add_child(rig)
	pitch_node = Node3D.new()
	rig.add_child(pitch_node)
	cam = Camera3D.new()
	cam.fov = 62.0
	cam.near = 0.08
	cam.far = 420.0
	cam.position.z = cam_dist
	pitch_node.add_child(cam)
	cam.current = true


func face_point(p: Vector3) -> void:
	var d := p - global_position
	model_root.rotation.y = atan2(d.x, d.z)


func _kbd() -> Vector2:
	var v := Vector2.ZERO
	if Input.is_physical_key_pressed(KEY_D) or Input.is_physical_key_pressed(KEY_RIGHT): v.x += 1.0
	if Input.is_physical_key_pressed(KEY_A) or Input.is_physical_key_pressed(KEY_LEFT): v.x -= 1.0
	if Input.is_physical_key_pressed(KEY_S) or Input.is_physical_key_pressed(KEY_DOWN): v.y += 1.0
	if Input.is_physical_key_pressed(KEY_W) or Input.is_physical_key_pressed(KEY_UP): v.y -= 1.0
	return v


func _physics_process(delta: float) -> void:
	var locked := frozen or Game.input_locked
	var mv := Vector2.ZERO
	if not locked:
		mv = Game.move_vec + _kbd()
		if mv.length() > 1.0:
			mv = mv.normalized()

	# ---- camera: free orbit, or a face close-up during dialogue
	if closeup:
		yaw = lerp_angle(yaw, model_root.rotation.y + closeup_side, clampf(5.0 * delta, 0.0, 1.0))
		pitch = lerpf(pitch, -0.02, clampf(5.0 * delta, 0.0, 1.0))
		cam.position.z = lerpf(cam.position.z, 1.25, clampf(5.0 * delta, 0.0, 1.0))
		rig.position.y = lerpf(rig.position.y, 1.47, clampf(5.0 * delta, 0.0, 1.0))
		cam.fov = lerpf(cam.fov, 34.0, clampf(5.0 * delta, 0.0, 1.0))
	else:
		yaw -= Game.look_delta.x * 0.0055
		pitch = clampf(pitch - Game.look_delta.y * 0.0045, -1.0, 0.25)
		cam.position.z = lerpf(cam.position.z, cam_dist, clampf(5.0 * delta, 0.0, 1.0))
		rig.position.y = lerpf(rig.position.y, 1.3, clampf(5.0 * delta, 0.0, 1.0))
		cam.fov = lerpf(cam.fov, 62.0, clampf(5.0 * delta, 0.0, 1.0))
	Game.look_delta = Vector2.ZERO
	rig.rotation.y = yaw
	pitch_node.rotation.x = pitch

	# ---- movement relative to camera
	var fwd := Vector3(-sin(yaw), 0.0, -cos(yaw))
	var right := Vector3(cos(yaw), 0.0, -sin(yaw))
	var dir := right * mv.x + fwd * -mv.y
	var hv := Vector3(velocity.x, 0.0, velocity.z)
	hv = hv.move_toward(dir * SPEED_RUN, (32.0 if mv.length() > 0.01 else 40.0) * delta)
	velocity.x = hv.x
	velocity.z = hv.z

	if is_on_floor():
		if not locked and (Game.jump_req or Input.is_physical_key_pressed(KEY_SPACE)):
			velocity.y = JUMP_V
			Sfx.play("jump", -2.0)
	else:
		velocity.y -= GRAVITY * delta
	Game.jump_req = false

	if dir.length() > 0.1:
		model_root.rotation.y = lerp_angle(model_root.rotation.y, atan2(dir.x, dir.z), clampf(14.0 * delta, 0.0, 1.0))

	move_and_slide()

	var flat := Vector2(global_position.x, global_position.z)
	if flat.length() > ARENA_R:
		flat = flat.normalized() * ARENA_R
		global_position.x = flat.x
		global_position.z = flat.y

	var hs := hv.length()
	girl.speed = hs
	girl.airborne = not is_on_floor()
	girl.talking = talking
	if is_on_floor() and hs > 0.6 and not locked:
		_step_t -= delta
		if _step_t <= 0.0:
			Sfx.play("step", -9.0, randf_range(0.92, 1.1))
			_step_t = 0.55 - clampf(hs / SPEED_RUN, 0.0, 1.0) * 0.24
