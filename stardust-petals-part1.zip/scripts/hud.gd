extends Control
## Multi-touch HUD: floating stick (left), camera drag (right), JUMP / TALK buttons, shard counter,
## compass arrow, FPS counter. Custom-drawn: no Button nodes, so multi-touch never conflicts.

const STICK_R := 78.0
const JUMP_R := 62.0
const TALK_R := 52.0
const NONE := -99

var player: Player
var target_pos := Vector3.INF
var objective := ""

var _stick_id := NONE
var _look_id := NONE
var _jump_id := NONE
var _talk_id := NONE
var _stick_origin := Vector2.ZERO
var _stick_pos := Vector2.ZERO
var _shard_label: Label
var _obj_label: Label
var _fps_label: Label
var _dist_label: Label
var _fps_t := 0.0


func _ready() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	_shard_label = _mk_label(Vector2(70, 16), 30, Color(1.0, 0.8, 0.95))
	_obj_label = _mk_label(Vector2(24, 58), 22, Color(0.85, 0.95, 1.0))
	_obj_label.size.x = 520
	_obj_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_fps_label = _mk_label(Vector2(0, 8), 18, Color(1, 1, 1, 0.7))
	_fps_label.set_anchors_preset(Control.PRESET_TOP_RIGHT)
	_fps_label.offset_left = -150
	_fps_label.offset_right = -14
	_fps_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	_dist_label = _mk_label(Vector2(0, 96), 18, Color(1, 1, 1, 0.85))
	_dist_label.set_anchors_preset(Control.PRESET_CENTER_TOP)
	_dist_label.offset_left = -60
	_dist_label.offset_right = 60
	_dist_label.offset_top = 92
	_dist_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	Game.delivered_changed.connect(func(_c): _refresh())
	_refresh()


func _mk_label(pos: Vector2, size_px: int, color: Color) -> Label:
	var l := Label.new()
	l.position = pos
	l.add_theme_font_size_override("font_size", size_px)
	l.add_theme_color_override("font_color", color)
	l.add_theme_constant_override("outline_size", 6)
	l.add_theme_color_override("font_outline_color", Color(0.04, 0.02, 0.12, 0.95))
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(l)
	return l


func set_objective(text: String) -> void:
	objective = text
	_refresh()


func _refresh() -> void:
	_shard_label.text = "BOUQUETS  %d / %d" % [Game.delivered, Game.DELIVERY_TOTAL]
	_obj_label.text = objective
	queue_redraw()


func _jump_c() -> Vector2:
	return Vector2(size.x - 130.0, size.y - 120.0)


func _talk_c() -> Vector2:
	return Vector2(size.x - 262.0, size.y - 196.0)


func _idle_stick_c() -> Vector2:
	return Vector2(160.0, size.y - 130.0)


# ---------- input ----------
func _input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		if event.pressed:
			_down(event.index, event.position)
		else:
			_up(event.index)
	elif event is InputEventScreenDrag:
		_drag(event.index, event.position, event.relative)
	elif not DisplayServer.is_touchscreen_available():
		# desktop testing with the mouse
		if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
			if event.pressed:
				_down(-1, event.position)
			else:
				_up(-1)
		elif event is InputEventMouseMotion and (_stick_id == -1 or _look_id == -1):
			_drag(-1, event.position, event.relative)
	if event is InputEventKey and event.pressed and not event.echo and event.keycode == KEY_E and Game.can_talk and not Game.input_locked:
		Game.talk_req = true


func _down(id: int, pos: Vector2) -> void:
	if Game.input_locked:
		return
	if pos.distance_to(_jump_c()) < JUMP_R * 1.2 and _jump_id == NONE:
		_jump_id = id
		Game.jump_req = true
	elif Game.can_talk and pos.distance_to(_talk_c()) < TALK_R * 1.25 and _talk_id == NONE:
		_talk_id = id
		Game.talk_req = true
	elif pos.x < size.x * 0.45 and _stick_id == NONE:
		_stick_id = id
		_stick_origin = pos
		_stick_pos = pos
	elif pos.x >= size.x * 0.3 and _look_id == NONE:
		_look_id = id
	queue_redraw()


func _up(id: int) -> void:
	if id == _stick_id:
		_stick_id = NONE
		Game.move_vec = Vector2.ZERO
	if id == _look_id:
		_look_id = NONE
	if id == _jump_id:
		_jump_id = NONE
	if id == _talk_id:
		_talk_id = NONE
	queue_redraw()


func _drag(id: int, pos: Vector2, rel: Vector2) -> void:
	if id == _stick_id:
		var d := pos - _stick_origin
		if d.length() > STICK_R:
			d = d.normalized() * STICK_R
			_stick_origin = pos - d  # floating stick follows the thumb
		_stick_pos = _stick_origin + d
		var v := d / STICK_R
		Game.move_vec = Vector2.ZERO if v.length() < 0.12 else v
		queue_redraw()
	elif id == _look_id:
		Game.look_delta += rel


# ---------- drawing ----------
func _process(delta: float) -> void:
	if Game.input_locked and (_stick_id != NONE or _look_id != NONE):
		_stick_id = NONE
		_look_id = NONE
		Game.move_vec = Vector2.ZERO
	_fps_t += delta
	if _fps_t > 0.5:
		_fps_t = 0.0
		_fps_label.text = "%d FPS" % Engine.get_frames_per_second()
	_dist_label.visible = target_pos != Vector3.INF and not Game.input_locked
	if _dist_label.visible and player:
		_dist_label.text = "%d m" % int(player.global_position.distance_to(target_pos))
	visible = true
	queue_redraw()


func _draw() -> void:
	if Game.input_locked:
		return
	var a_base := 0.22
	var c := _stick_origin if _stick_id != NONE else _idle_stick_c()
	var k := _stick_pos if _stick_id != NONE else c
	draw_circle(c, STICK_R, Color(1, 1, 1, a_base * 0.6))
	draw_arc(c, STICK_R, 0.0, TAU, 40, Color(1, 1, 1, 0.45), 3.0)
	draw_circle(k, 34.0, Color(1.0, 0.7, 0.9, 0.55))
	draw_arc(k, 34.0, 0.0, TAU, 28, Color(1, 1, 1, 0.8), 2.5)

	var jc := _jump_c()
	var jp := _jump_id != NONE
	draw_circle(jc, JUMP_R, Color(0.4, 0.9, 1.0, 0.45 if jp else 0.25))
	draw_arc(jc, JUMP_R, 0.0, TAU, 40, Color(1, 1, 1, 0.7), 3.0)
	var font := ThemeDB.fallback_font
	draw_string(font, jc + Vector2(-34, 9), "JUMP", HORIZONTAL_ALIGNMENT_CENTER, 68, 24, Color(1, 1, 1, 0.95))

	if Game.can_talk:
		var tc := _talk_c()
		draw_circle(tc, TALK_R, Color(1.0, 0.7, 0.35, 0.55))
		draw_arc(tc, TALK_R, 0.0, TAU, 32, Color(1, 1, 1, 0.9), 3.0)
		draw_string(font, tc + Vector2(-32, 9), "TALK", HORIZONTAL_ALIGNMENT_CENTER, 64, 24, Color(1, 1, 1, 1))

	# flower icon
	var ic := Vector2(40, 36)
	for pi_ in 5:
		var pa := TAU * float(pi_) / 5.0 - PI * 0.5
		draw_circle(ic + Vector2(cos(pa), sin(pa)) * 9.0, 7.5, Color(1.0, 0.62, 0.8))
	draw_circle(ic, 6.0, Color(1.0, 0.9, 0.4))

	# compass
	if target_pos != Vector3.INF and player:
		var to := target_pos - player.global_position
		var f := Vector2(-sin(player.yaw), -cos(player.yaw))
		var r := Vector2(cos(player.yaw), -sin(player.yaw))
		var t := Vector2(to.x, to.z)
		var ang := atan2(t.dot(r), t.dot(f))
		var cc := Vector2(size.x * 0.5, 58.0)
		draw_circle(cc, 32.0, Color(0.03, 0.02, 0.12, 0.5))
		draw_arc(cc, 32.0, 0.0, TAU, 32, Color(1, 1, 1, 0.5), 2.0)
		draw_set_transform(cc, ang)
		draw_colored_polygon(PackedVector2Array([Vector2(0, -24), Vector2(15, 15), Vector2(0, 7), Vector2(-15, 15)]), Color(1.0, 0.75, 0.9))
		draw_set_transform(Vector2.ZERO, 0.0)
