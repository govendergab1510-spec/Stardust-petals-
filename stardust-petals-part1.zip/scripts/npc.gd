class_name Npc
extends Node3D
## Cute low-poly townsfolk baked from primitives: 3 meshes (body, head, mouth) = ~5 draw calls with outline.
## Mouth opens with their voice line, head bobs, an "!" marker shows when they can be talked to.

const TOON := preload("res://shaders/toon.gdshader")
const OUTLINE := preload("res://shaders/outline.gdshader")

var head: Node3D
var mouth: MeshInstance3D
var marker: Label3D
var mouth_open := 0.0
var head_y := 1.6
var sitting := false
var _t := randf() * 10.0
var _scale := 1.0
var _mat: ShaderMaterial


func _make_mat(color: Color, vcol: bool) -> ShaderMaterial:
	var sm := ShaderMaterial.new()
	sm.shader = TOON
	sm.set_shader_parameter("albedo", color)
	sm.set_shader_parameter("use_vcol", 1.0 if vcol else 0.0)
	sm.set_shader_parameter("rim_strength", 0.25)
	sm.set_shader_parameter("shade_color", Color(0.62, 0.55, 0.8))
	return sm


func build(cfg: Dictionary) -> void:
	_scale = float(cfg.get("scale", 1.0))
	sitting = bool(cfg.get("sit", false))
	var skin: Color = cfg.get("skin", Color(1.0, 0.82, 0.72))
	var outfit: Color = cfg.get("outfit", Color(0.5, 0.6, 0.9))
	var hair: Color = cfg.get("hair", Color(0.2, 0.15, 0.15))
	var legs := Color(0.25, 0.22, 0.35)

	var body_root := Node3D.new()
	body_root.scale = Vector3.ONE * _scale
	if sitting:
		body_root.position.y = 0.3
	add_child(body_root)

	# ---------------- body mesh (static) ----------------
	var bb := Baker.new()
	bb.add(Baker.capsule(0.27, 1.1), Transform3D(Basis.IDENTITY, Vector3(0, 0.75, 0)), outfit)
	if not sitting:
		bb.add(Baker.cyl(0.085, 0.085, 0.3), Transform3D(Basis.IDENTITY, Vector3(-0.11, 0.15, 0)), legs)
		bb.add(Baker.cyl(0.085, 0.085, 0.3), Transform3D(Basis.IDENTITY, Vector3(0.11, 0.15, 0)), legs)
	for sx in [-1.0, 1.0]:
		bb.add(Baker.capsule(0.075, 0.55, 8), Transform3D(Basis(Vector3.BACK, -0.18 * sx), Vector3(0.33 * sx, 0.9, 0)), outfit)
		bb.add(Baker.sphere(0.08, 8), Transform3D(Basis.IDENTITY, Vector3(0.38 * sx, 0.6, 0)), skin)
	if cfg.has("apron"):
		bb.add(Baker.box(Vector3(0.42, 0.62, 0.05)), Transform3D(Basis.IDENTITY, Vector3(0, 0.78, 0.25)), cfg["apron"])
	match String(cfg.get("prop", "none")):
		"guitar":
			bb.add(Baker.box(Vector3(0.34, 0.42, 0.1)), Transform3D(Basis(Vector3.BACK, 0.5), Vector3(-0.05, 0.62, 0.3)), Color(0.8, 0.5, 0.25))
			bb.add(Baker.box(Vector3(0.07, 0.7, 0.05)), Transform3D(Basis(Vector3.BACK, -0.9), Vector3(0.3, 0.95, 0.3)), Color(0.35, 0.22, 0.15))
		"balloon":
			bb.add(Baker.cyl(0.008, 0.008, 1.3, 4), Transform3D(Basis.IDENTITY, Vector3(0.45, 1.45, 0.05)), Color(1, 1, 1))
			bb.add(Baker.sphere(0.27, 10), Transform3D(Basis.IDENTITY, Vector3(0.45, 2.3, 0.05)), Color(1.0, 0.4, 0.55))
		"flowers":
			bb.add(Baker.sphere(0.09, 8), Transform3D(Basis.IDENTITY, Vector3(-0.4, 0.62, 0.12)), Color(1.0, 0.7, 0.85))
	var body_mi := MeshInstance3D.new()
	body_mi.mesh = bb.build()
	body_mi.material_override = _outlined(_make_mat(Color.WHITE, true))
	body_mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	body_root.add_child(body_mi)

	# ---------------- head mesh (bobs) ----------------
	head = Node3D.new()
	head.position = Vector3(0, 1.55, 0)
	body_root.add_child(head)
	head_y = 1.55 * _scale + (0.3 if sitting else 0.0)
	var hb := Baker.new()
	hb.add(Baker.sphere(0.27, 12), Transform3D.IDENTITY, skin)
	hb.add(Baker.sphere(0.295, 12), Transform3D(Basis.from_scale(Vector3(1.0, 0.88, 1.0)), Vector3(0, 0.06, -0.035)), hair)
	for sx in [-1.0, 1.0]:
		hb.add(Baker.sphere(0.034, 6), Transform3D(Basis.IDENTITY, Vector3(0.1 * sx, 0.0, 0.245)), Color(0.08, 0.05, 0.1))
		hb.add(Baker.sphere(0.045, 6), Transform3D(Basis.from_scale(Vector3(1.0, 0.6, 0.4)), Vector3(0.17 * sx, -0.06, 0.2)), Color(1.0, 0.6, 0.65))
	match String(cfg.get("hat", "none")):
		"chef":
			hb.add(Baker.cyl(0.2, 0.2, 0.34), Transform3D(Basis.IDENTITY, Vector3(0, 0.42, 0)), Color.WHITE)
			hb.add(Baker.sphere(0.24, 10), Transform3D(Basis.IDENTITY, Vector3(0, 0.6, 0)), Color.WHITE)
		"beanie":
			hb.add(Baker.sphere(0.3, 12), Transform3D(Basis.from_scale(Vector3(1.0, 0.8, 1.0)), Vector3(0, 0.1, -0.02)), cfg.get("hat_color", Color(0.9, 0.35, 0.4)))
		"bun":
			hb.add(Baker.sphere(0.13, 8), Transform3D(Basis.IDENTITY, Vector3(0, 0.34, -0.12)), hair)
		"cap":
			hb.add(Baker.sphere(0.3, 12), Transform3D(Basis.from_scale(Vector3(1.0, 0.7, 1.0)), Vector3(0, 0.1, -0.02)), cfg.get("hat_color", Color(0.3, 0.5, 0.9)))
			hb.add(Baker.box(Vector3(0.34, 0.04, 0.22)), Transform3D(Basis.IDENTITY, Vector3(0, 0.07, 0.3)), cfg.get("hat_color", Color(0.3, 0.5, 0.9)))
		"glasses":
			for sx in [-1.0, 1.0]:
				hb.add(Baker.sphere(0.07, 8), Transform3D(Basis.from_scale(Vector3(1.0, 1.0, 0.25)), Vector3(0.1 * sx, 0.0, 0.25)), Color(0.15, 0.1, 0.25))
	var head_mi := MeshInstance3D.new()
	head_mi.mesh = hb.build()
	head_mi.material_override = _outlined(_make_mat(Color.WHITE, true))
	head_mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	head.add_child(head_mi)

	mouth = MeshInstance3D.new()
	mouth.mesh = Baker.sphere(0.05, 8)
	mouth.material_override = _make_mat(Color(0.55, 0.12, 0.2), false)
	mouth.position = Vector3(0, -0.1, 0.255)
	mouth.scale = Vector3(1.4, 0.5, 0.5)
	mouth.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	head.add_child(mouth)

	marker = Label3D.new()
	marker.text = "!"
	marker.font_size = 96
	marker.pixel_size = 0.012
	marker.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	marker.no_depth_test = true
	marker.modulate = Color(1.0, 0.85, 0.3)
	marker.outline_modulate = Color(0.35, 0.1, 0.25)
	marker.outline_size = 14
	marker.position = Vector3(0, head_y + 0.75 * _scale, 0)
	add_child(marker)

	var sb := StaticBody3D.new()
	var cs := CollisionShape3D.new()
	var sh := CylinderShape3D.new()
	sh.radius = 0.4
	sh.height = 1.6
	cs.shape = sh
	cs.position.y = 0.8
	sb.add_child(cs)
	add_child(sb)


func _outlined(m: ShaderMaterial) -> ShaderMaterial:
	if not Game.OUTLINES:
		return m
	var om := ShaderMaterial.new()
	om.shader = OUTLINE
	om.set_shader_parameter("thickness", 0.012)
	m.next_pass = om
	return m


func face_point(p: Vector3, amount := 0.25) -> void:
	var d := p - global_position
	rotation.y = lerp_angle(rotation.y, atan2(d.x, d.z), amount)


func _process(delta: float) -> void:
	_t += delta
	mouth.scale = Vector3(1.4 - 0.35 * mouth_open, 0.45 + 2.2 * mouth_open, 0.5)
	head.position.y = 1.55 + sin(_t * 2.0) * 0.012 + mouth_open * 0.02
	head.rotation.z = sin(_t * 1.1) * 0.04 + mouth_open * sin(_t * 6.0) * 0.05
	if marker.visible:
		marker.position.y = head_y + 0.75 * _scale + sin(_t * 3.0) * 0.1
