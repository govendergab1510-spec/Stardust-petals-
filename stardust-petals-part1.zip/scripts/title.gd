extends Control
## Title screen. Everything is built in code so the .tscn stays trivial.

var _started := false
var _tap_label: Label


func _ready() -> void:
	Game.reset_run()
	var bg := ColorRect.new()
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	var mat := ShaderMaterial.new()
	mat.shader = load("res://shaders/title_bg.gdshader")
	bg.material = mat
	add_child(bg)

	# falling sakura petals (cheap 2D particles)
	var petals := CPUParticles2D.new()
	petals.position = Vector2(640, -20)
	petals.amount = 40
	petals.lifetime = 9.0
	petals.preprocess = 9.0
	petals.emission_shape = CPUParticles2D.EMISSION_SHAPE_RECTANGLE
	petals.emission_rect_extents = Vector2(760, 10)
	petals.direction = Vector2(-0.3, 1.0)
	petals.spread = 12.0
	petals.gravity = Vector2(-4, 14)
	petals.initial_velocity_min = 40.0
	petals.initial_velocity_max = 90.0
	petals.angular_velocity_min = -120.0
	petals.angular_velocity_max = 120.0
	petals.scale_amount_min = 3.0
	petals.scale_amount_max = 6.5
	petals.color = Color(1.0, 0.72, 0.86, 0.9)
	add_child(petals)

	var title := _label(String(Game.story.get("title", "STARDUST PETALS")), 96, Vector2(0, 150), Color(1, 0.96, 0.98))
	title.add_theme_color_override("font_outline_color", Color(0.85, 0.25, 0.55))
	title.add_theme_constant_override("outline_size", 14)
	title.add_theme_color_override("font_shadow_color", Color(0.1, 0.9, 1.0, 0.8))
	title.add_theme_constant_override("shadow_offset_x", 6)
	title.add_theme_constant_override("shadow_offset_y", 5)

	var sub := _label(String(Game.story.get("chapter", "Chapter 1")), 30, Vector2(0, 272), Color(0.75, 0.9, 1.0))
	sub.add_theme_constant_override("outline_size", 6)
	sub.add_theme_color_override("font_outline_color", Color(0.05, 0.02, 0.15))

	_tap_label = _label("TAP TO START", 36, Vector2(0, 470), Color(1, 1, 1))
	_tap_label.add_theme_constant_override("outline_size", 8)
	_tap_label.add_theme_color_override("font_outline_color", Color(0.05, 0.02, 0.15))

	var ver := _label("Part 1 of 10  -  build test", 18, Vector2(0, 540), Color(1, 1, 1, 0.65))
	ver.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER

	var tw := create_tween().set_loops()
	tw.tween_property(_tap_label, "modulate:a", 0.25, 0.8)
	tw.tween_property(_tap_label, "modulate:a", 1.0, 0.8)

	modulate.a = 0.0
	create_tween().tween_property(self, "modulate:a", 1.0, 0.8)
	Sfx.ambient("ambient_city")


func _label(text: String, size: int, pos: Vector2, color: Color) -> Label:
	var l := Label.new()
	l.text = text
	l.position = pos
	l.size = Vector2(1280, size + 20)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(l)
	return l


func _input(event: InputEvent) -> void:
	if _started or not Game.is_tap(event):
		return
	_started = true
	Sfx.play("ui_start")
	var tw := create_tween()
	tw.tween_property(self, "modulate:a", 0.0, 0.6)
	await tw.finished
	Sfx.stop_ambient()
	get_tree().change_scene_to_file("res://scenes/world.tscn")
