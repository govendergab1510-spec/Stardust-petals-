class_name Girl
extends Node3D
## Shino (CC0 VRoid model). Handles everything the VRM file does not ship with:
##  - mobile-friendly materials (wrap diffuse, rim light, inverted-hull outline, no specular)
##  - merges the 48 hair surfaces / duplicate skin surfaces into a few draw calls
##  - procedural idle / walk / run / jump / talking-gesture animation (no animation files needed)
##  - blendshape lip sync (A I U E O), blinking and facial expressions

const MODEL_PATH := "res://assets/models/Shino.glb"
const SHAPES_PATH := "res://data/shino_blendshapes.json"
const NO_OUTLINE := ["EyeWhite", "EyeIris", "EyeHighlight", "EyeExtra", "FaceMouth", "Eyeline", "Eyelash", "FaceBrow"]
const BONE_NAMES := {
	"hips": "J_Bip_C_Hips", "spine": "J_Bip_C_Spine", "chest": "J_Bip_C_Chest", "uchest": "J_Bip_C_UpperChest",
	"neck": "J_Bip_C_Neck", "head": "J_Bip_C_Head",
	"l_arm": "J_Bip_L_UpperArm", "l_fore": "J_Bip_L_LowerArm", "l_hand": "J_Bip_L_Hand",
	"r_arm": "J_Bip_R_UpperArm", "r_fore": "J_Bip_R_LowerArm", "r_hand": "J_Bip_R_Hand",
	"l_leg": "J_Bip_L_UpperLeg", "l_shin": "J_Bip_L_LowerLeg", "l_foot": "J_Bip_L_Foot",
	"r_leg": "J_Bip_R_UpperLeg", "r_shin": "J_Bip_R_LowerLeg", "r_foot": "J_Bip_R_Foot",
}

static var merge_enabled := true
var loaded := false
var skeleton: Skeleton3D
var meshes := {}
var shapes := {}
var bone := {}

# --- inputs set by the game
var speed := 0.0
var airborne := false
var talking := false
var mouth_open := 0.0
var emotion := "neutral"
var carrying := false

var _abs := {}
var _rest_hips := Vector3.ZERO
var _phase := 0.0
var _t := 0.0
var _move := 0.0
var _air := 0.0
var _talk := 0.0
var _carry := 0.0
var _blink_t := 2.0
var _blink := 0.0
var _vis := {"a": 0.0, "i": 0.0, "u": 0.0, "e": 0.0, "o": 0.0}
var _vis_target := "a"
var _vis_timer := 0.0
var _emo := {"joy": 0.0, "fun": 0.0, "sorrow": 0.0, "angry": 0.0, "surprised": 0.0}
var _shape_cache := {}
var _bouquet: Node3D
var _curl_now := 0.32


static func rx(a: float) -> Quaternion:
	return Quaternion(Vector3.RIGHT, a)


static func ry(a: float) -> Quaternion:
	return Quaternion(Vector3.UP, a)


static func rz(a: float) -> Quaternion:
	return Quaternion(Vector3.BACK, a)


func load_model() -> bool:
	if not ResourceLoader.exists(MODEL_PATH):
		return false
	var ps := load(MODEL_PATH) as PackedScene
	if ps == null:
		return false
	var m := ps.instantiate() as Node3D
	m.rotation.y = PI  # VRM0 models face -Z; the game faces +Z
	add_child(m)
	var sks := m.find_children("*", "Skeleton3D", true, false)
	if sks.is_empty():
		return false
	skeleton = sks[0] as Skeleton3D
	for n in m.find_children("*", "MeshInstance3D", true, false):
		var mi := n as MeshInstance3D
		meshes[String(mi.name)] = mi
		mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		if merge_enabled:
			_merge_same_material(mi)
		_style(mi)
	var res = load(SHAPES_PATH)
	if res is JSON:
		shapes = res.data
	for k in BONE_NAMES:
		bone[k] = skeleton.find_bone(BONE_NAMES[k])
		if int(bone[k]) < 0:
			push_warning("bone missing: " + String(BONE_NAMES[k]))
			return false
	_rest_hips = skeleton.get_bone_rest(int(bone["hips"])).origin
	_curl_fingers(0.32)
	_make_bouquet()
	loaded = true
	return true


# ------------------------------------------------------------------ mesh / material prep
func _merge_same_material(mi: MeshInstance3D) -> void:
	var src := mi.mesh as ArrayMesh
	if src == null or src.get_blend_shape_count() > 0:
		return
	var order: Array = []
	var groups := {}
	for i in src.get_surface_count():
		var mat := src.surface_get_material(i)
		var key: String = mat.resource_name if mat else "none%d" % i
		if not groups.has(key):
			groups[key] = {"mat": mat, "list": []}
			order.append(key)
		groups[key]["list"].append(src.surface_get_arrays(i))
	if order.size() == src.get_surface_count():
		return
	var out := ArrayMesh.new()
	for key in order:
		var g: Dictionary = groups[key]
		var merged := _concat(g["list"])
		var flags := 0
		var verts: PackedVector3Array = merged[Mesh.ARRAY_VERTEX]
		var bones_arr = merged[Mesh.ARRAY_BONES]
		if bones_arr != null and (bones_arr as PackedInt32Array).size() == verts.size() * 8:
			flags = Mesh.ARRAY_FLAG_USE_8_BONE_WEIGHTS
		out.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, merged, [], {}, flags)
		out.surface_set_material(out.get_surface_count() - 1, g["mat"])
	mi.mesh = out


func _concat(list: Array) -> Array:
	var res := []
	res.resize(Mesh.ARRAY_MAX)
	var offset := 0
	for arrays in list:
		for k in Mesh.ARRAY_MAX:
			var a = arrays[k]
			if a == null:
				continue
			if k == Mesh.ARRAY_INDEX:
				var idxs: PackedInt32Array = a
				var shifted := PackedInt32Array()
				shifted.resize(idxs.size())
				for j in idxs.size():
					shifted[j] = idxs[j] + offset
				if res[k] == null:
					res[k] = shifted
				else:
					var cur: PackedInt32Array = res[k]
					cur.append_array(shifted)
					res[k] = cur
			else:
				if res[k] == null:
					res[k] = a.duplicate()
				else:
					res[k].append_array(a)
		offset += (arrays[Mesh.ARRAY_VERTEX] as PackedVector3Array).size()
	return res


func _style(mi: MeshInstance3D) -> void:
	var mesh := mi.mesh
	if mesh == null:
		return
	for i in mesh.get_surface_count():
		var mat := mesh.surface_get_material(i) as BaseMaterial3D
		if mat == null:
			continue
		var nm := String(mat.resource_name)
		var feature := false
		for s in NO_OUTLINE:
			if nm.contains(s):
				feature = true
		mat.specular_mode = BaseMaterial3D.SPECULAR_DISABLED
		mat.metallic = 0.0
		mat.roughness = 1.0
		if feature:
			mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
			continue
		mat.diffuse_mode = BaseMaterial3D.DIFFUSE_LAMBERT_WRAP
		mat.rim_enabled = true
		mat.rim = 0.3
		mat.rim_tint = 0.4
		var blended := mat.transparency == BaseMaterial3D.TRANSPARENCY_ALPHA or mat.transparency == BaseMaterial3D.TRANSPARENCY_ALPHA_DEPTH_PRE_PASS
		if Game.OUTLINES and not blended and mat.next_pass == null:
			var o := StandardMaterial3D.new()
			o.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
			o.cull_mode = BaseMaterial3D.CULL_FRONT
			o.grow = true
			o.grow_amount = 0.0032
			o.albedo_color = Color(0.2, 0.1, 0.16)
			if mat.transparency == BaseMaterial3D.TRANSPARENCY_ALPHA_SCISSOR:
				o.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA_SCISSOR
				o.alpha_scissor_threshold = mat.alpha_scissor_threshold
				o.albedo_texture = mat.albedo_texture
			mat.next_pass = o


func _curl_fingers(amount: float) -> void:
	for side in ["L", "R"]:
		var sign_ := 1.0 if side == "L" else -1.0
		for f in ["Index", "Middle", "Ring", "Little"]:
			for k in [1, 2, 3]:
				var i := skeleton.find_bone("J_Bip_%s_%s%d" % [side, f, k])
				if i >= 0:
					skeleton.set_bone_pose_rotation(i, rz(sign_ * amount * (0.8 if k == 1 else 1.1)))


func _make_bouquet() -> void:
	var att := BoneAttachment3D.new()
	att.bone_name = BONE_NAMES["l_hand"]
	skeleton.add_child(att)
	var holder := Node3D.new()
	holder.position = Vector3(-0.055, -0.012, 0.0)  # palm centre, in the hand's own frame
	att.add_child(holder)
	_bouquet = Node3D.new()
	holder.add_child(_bouquet)

	var bk := Baker.new()
	var paper := Color(1.0, 0.9, 0.93)
	var green := Color(0.35, 0.75, 0.45)
	bk.add(Baker.cyl(0.095, 0.014, 0.27, 10), Transform3D(Basis.IDENTITY, Vector3(0, 0.135, 0)), paper)
	bk.add(Baker.cyl(0.07, 0.012, 0.2, 10), Transform3D(Basis.IDENTITY, Vector3(0, 0.1, 0.0)), Color(1.0, 0.72, 0.8))
	bk.add(Baker.cyl(0.05, 0.045, 0.03, 10), Transform3D(Basis.IDENTITY, Vector3(0, 0.07, 0)), Color(0.95, 0.3, 0.45))
	for i in 3:
		var a := TAU * float(i) / 3.0
		bk.add(Baker.box(Vector3(0.05, 0.02, 0.02)), Transform3D(Basis(Vector3.UP, a) * Basis(Vector3.BACK, 0.5), Vector3(cos(a) * 0.045, 0.065, sin(a) * 0.045)), Color(0.95, 0.3, 0.45))
	# leaves
	for i in 6:
		var a := TAU * float(i) / 6.0 + 0.3
		bk.add(Baker.sphere(0.06, 6), Transform3D(Basis(Vector3.UP, a) * Basis(Vector3.BACK, 0.9) * Basis.from_scale(Vector3(1.0, 0.25, 0.55)), Vector3(cos(a) * 0.09, 0.27, sin(a) * 0.09)), green)
	# flower heads: centre + ring + low ring, each with a yellow centre
	var cols := [Color(1.0, 0.45, 0.62), Color(1.0, 0.9, 0.4), Color(0.97, 0.97, 1.0), Color(0.78, 0.6, 1.0), Color(1.0, 0.62, 0.38), Color(1.0, 0.55, 0.75)]
	var heads: Array = [[Vector3(0, 0.37, 0), 0]]
	for i in 6:
		var a := TAU * float(i) / 6.0
		heads.append([Vector3(cos(a) * 0.075, 0.33, sin(a) * 0.075), i + 1])
	for i in 4:
		var a := TAU * float(i) / 4.0 + 0.7
		heads.append([Vector3(cos(a) * 0.12, 0.28, sin(a) * 0.12), i + 3])
	for h in heads:
		var hp: Vector3 = h[0]
		bk.add(Baker.sphere(0.048, 8), Transform3D(Basis.from_scale(Vector3(1.0, 0.7, 1.0)), hp), cols[int(h[1]) % cols.size()])
		bk.add(Baker.sphere(0.016, 5), Transform3D(Basis.IDENTITY, hp + Vector3(0, 0.026, 0)), Color(1.0, 0.85, 0.3))
	var mi := MeshInstance3D.new()
	mi.mesh = bk.build()
	var bm := StandardMaterial3D.new()
	bm.vertex_color_use_as_albedo = true
	bm.diffuse_mode = BaseMaterial3D.DIFFUSE_LAMBERT_WRAP
	bm.specular_mode = BaseMaterial3D.SPECULAR_DISABLED
	bm.roughness = 1.0
	mi.material_override = bm
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	_bouquet.add_child(mi)
	holder.visible = true
	_bouquet.visible = false


# ------------------------------------------------------------------ per frame
func _process(delta: float) -> void:
	if not loaded:
		return
	_t += delta
	_move = lerpf(_move, clampf(speed / 5.6, 0.0, 1.15), clampf(10.0 * delta, 0.0, 1.0))
	_air = move_toward(_air, 1.0 if airborne else 0.0, 7.0 * delta)
	_talk = move_toward(_talk, 1.0 if talking else 0.0, 3.0 * delta)
	_carry = move_toward(_carry, 1.0 if carrying else 0.0, 4.0 * delta)
	if _move > 0.04:
		_phase += delta * (2.0 * maxf(speed, 1.2))
	_bouquet.visible = _carry > 0.5
	if _bouquet.visible:
		_bouquet.global_basis = Basis(Vector3.UP, global_rotation.y)
	var curl := lerpf(0.32, 1.1, _carry)
	if absf(curl - _curl_now) > 0.02:
		_curl_now = curl
		_curl_fingers(curl)
	_pose()
	_update_face(delta)


func _set_abs(key: String, q: Quaternion) -> void:
	var i: int = bone[key]
	var pq := _abs_of(skeleton.get_bone_parent(i))
	skeleton.set_bone_pose_rotation(i, pq.inverse() * q)
	_abs[i] = q


func _abs_of(i: int) -> Quaternion:
	if i < 0:
		return Quaternion.IDENTITY
	if _abs.has(i):
		return _abs[i]
	return _abs_of(skeleton.get_bone_parent(i))


func _pose() -> void:
	_abs.clear()
	var m := minf(_move, 1.0)
	var run := clampf((_move - 0.55) / 0.45, 0.0, 1.0)
	var ph := _phase
	var grounded := 1.0 - _air
	var leg_amp := lerpf(0.5, 0.85, run) * m * grounded
	var arm_amp := lerpf(0.5, 0.85, run) * m * grounded
	var sl := sin(ph)
	var sr := sin(ph + PI)
	var breathe := sin(_t * 1.7)
	var idle := 1.0 - m

	var lean := lerpf(0.04, 0.2, run) * m
	var twist := sl * 0.12 * m
	var sway := sin(_t * 0.7) * 0.018 * idle + sl * 0.035 * m
	var hips_q := rz(sway) * ry(twist) * rx(-lean * 0.5)
	var bob := cos(2.0 * ph) * 0.016 * m - 0.03 * run * m
	skeleton.set_bone_pose_position(int(bone["hips"]), _rest_hips + Vector3(0, bob - 0.04 * _air, 0))
	_set_abs("hips", hips_q)
	var spine_q := hips_q * rx(-lean * 0.4 + breathe * 0.006) * ry(-twist * 0.8)
	_set_abs("spine", spine_q)
	var chest_q := spine_q * rx(-lean * 0.3 + breathe * 0.01) * ry(-twist * 0.5)
	_set_abs("chest", chest_q)
	_set_abs("uchest", chest_q * rx(breathe * 0.008))
	var look := sin(_t * 0.45) * 0.1 * idle
	var nod := sin(_t * 5.2) * 0.035 * _talk + sin(_t * 1.3) * 0.015
	_set_abs("neck", ry(look * 0.5) * rx(0.03))
	_set_abs("head", ry(look) * rx(nod + 0.02 + lean * 0.3))

	# ---- legs (model frame: forward is -Z, +X rotation swings forward)
	var kl := maxf(0.0, cos(ph)) * 0.95 * leg_amp
	var kr := maxf(0.0, cos(ph + PI)) * 0.95 * leg_amp
	var l_sw := sl * leg_amp * 1.0 + _air * 0.75
	var r_sw := sr * leg_amp * 1.0 - _air * 0.3
	_set_abs("l_leg", rx(l_sw))
	_set_abs("l_shin", rx(l_sw - kl - _air * 1.0))
	_set_abs("l_foot", (rx(l_sw - kl - _air * 1.0)).slerp(Quaternion.IDENTITY, 0.75 * grounded) * rx(-0.25 * _air))
	_set_abs("r_leg", rx(r_sw))
	_set_abs("r_shin", rx(r_sw - kr - _air * 0.7))
	_set_abs("r_foot", (rx(r_sw - kr - _air * 0.7)).slerp(Quaternion.IDENTITY, 0.75 * grounded) * rx(-0.25 * _air))

	# ---- arms
	var a0 := 1.2 - _air * 0.55
	var elbow := 0.22 + run * 0.9 * m + _air * 0.5
	var l_sw_a := -sl * arm_amp + _air * 0.5
	var r_sw_a := -sr * arm_amp + _air * 0.5
	var gest := _talk * idle * (1.0 - _carry * 0.0)
	var wob := sin(_t * 3.1) * 0.22 + sin(_t * 7.3) * 0.08
	# talking gesture on the right arm: raise the forearm
	var r_up := rx(r_sw_a + 0.45 * gest) * rz(-(a0 - 0.2 * gest))
	var r_low := rx(r_sw_a + elbow + gest * (1.15 + wob * 0.5)) * rz(-(a0 - 0.2 * gest))
	_set_abs("r_arm", r_up)
	_set_abs("r_fore", r_low)
	# left arm: holds the bouquet in front when carrying
	var c := _carry * idle * (1.0 - 0.6 * _talk)  # lower the bouquet while talking so it never covers her face
	var l_up := rx(l_sw_a + 0.5 * c) * rz(a0 + 0.22 * c)
	var l_low := rx(l_sw_a + elbow + 0.95 * c + 0.12 * gest * sin(_t * 2.1)) * rz(a0 + 0.3 * c)
	_set_abs("l_arm", l_up)
	_set_abs("l_fore", l_low)


func _update_face(delta: float) -> void:
	# --- expression
	var targets := {"joy": 0.0, "fun": 0.0, "sorrow": 0.0, "angry": 0.0, "surprised": 0.0}
	match emotion:
		"joy": targets["joy"] = 0.75
		"fun": targets["fun"] = 0.8
		"sorrow": targets["sorrow"] = 0.7
		"angry": targets["angry"] = 0.7
		"surprised": targets["surprised"] = 0.8
		"relaxed": targets["fun"] = 0.3
	var speak := clampf(mouth_open, 0.0, 1.0)
	for k in _emo:
		_emo[k] = move_toward(_emo[k], targets[k], 2.6 * delta)
		_set_shape(k, _emo[k] * (1.0 - 0.45 * _talk))
	# --- blink
	_blink_t -= delta
	if _blink_t <= 0.0:
		_blink = 1.0
		_blink_t = randf_range(2.2, 5.0)
	_blink = move_toward(_blink, 0.0, 7.5 * delta)
	var eyes_closed: bool = float(_emo["joy"]) > 0.5 or float(_emo["fun"]) > 0.5
	_set_shape("blink", 0.0 if eyes_closed else _blink)
	# --- lip sync: pick a new vowel every ~0.1 s and scale by the loudness
	_vis_timer -= delta
	if _vis_timer <= 0.0:
		_vis_timer = randf_range(0.07, 0.15)
		var r := randf()
		_vis_target = "a" if r < 0.42 else ("o" if r < 0.62 else ("e" if r < 0.8 else ("i" if r < 0.92 else "u")))
	for k in _vis:
		var tgt: float = speak * (0.95 if k == _vis_target else 0.0)
		_vis[k] = lerpf(_vis[k], tgt, clampf(22.0 * delta, 0.0, 1.0))
		_set_shape(k, _vis[k])


func _set_shape(shape: String, w: float) -> void:
	w = clampf(w, 0.0, 1.0)
	if absf(float(_shape_cache.get(shape, -1.0)) - w) < 0.004:
		return
	_shape_cache[shape] = w
	for b in shapes.get(shape, []):
		var mi: MeshInstance3D = meshes.get(b["mesh"])
		if mi:
			mi.set_blend_shape_value(int(b["index"]), w * float(b["weight"]))


## Head position in the girl's local space (for the dialogue camera).
func head_height() -> float:
	return 1.48
