extends Node3D
## Chapter 1 - "An Ordinary Day". Hoshigaoka shopping street, built from code.
## Tuned for Adreno 610-class phones: Compatibility (GLES3) renderer, one directional light, no shadows,
## no post-process, unshaded procedural skyline in one MultiMesh draw call, additive billboards for glow,
## 1280x576 render size, ~10 draw calls per NPC, merged hair/skin surfaces on the heroine.

const TOON := preload("res://shaders/toon.gdshader")
const SKY := preload("res://shaders/sky.gdshader")
const BUILDING := preload("res://shaders/building.gdshader")
const GROUND := preload("res://shaders/ground.gdshader")
const GLOW := preload("res://shaders/glow.gdshader")
const HUD_SCRIPT := preload("res://scripts/hud.gd")
const DIALOGUE_SCRIPT := preload("res://scripts/dialogue_box.gd")

const FLORIST_POS := Vector3(-17.5, 0.0, 22.5)
const BAKERY_POS := Vector3(19.0, 0.0, 21.0)
const LANTERN_POS := Vector3(0.0, 0.0, -15.0)
const TALK_RANGE := 3.8

# Time of day: key 0 = morning, 1 = golden sunset, 2 = night (t = 0 .. 0.5 .. 1)
const PAL := [
	{
		"top": Color(0.30, 0.58, 0.95), "mid": Color(0.62, 0.82, 1.0), "hor": Color(1.0, 0.92, 0.84),
		"body": Vector3(0.45, 0.62, -0.55), "body_col": Color(1.0, 0.97, 0.85), "body_size": 0.0016,
		"stars": 0.0, "cloud": 0.55, "cloud_col": Color(1, 1, 1), "cloud_shade": Color(0.78, 0.84, 0.98),
		"fog": Color(0.80, 0.88, 1.0), "fog_d": 0.0032, "amb": Color(0.68, 0.74, 0.92), "amb_e": 0.95,
		"sun": Color(1.0, 0.96, 0.88), "sun_e": 1.1,
		"wall_lo": Color(0.86, 0.80, 0.76), "wall_hi": Color(0.95, 0.90, 0.92),
		"ground": Color(0.60, 0.59, 0.64), "lines": Color(0.45, 0.50, 0.60), "win": 0.0,
	},
	{
		"top": Color(0.30, 0.27, 0.58), "mid": Color(0.90, 0.48, 0.58), "hor": Color(1.0, 0.74, 0.38),
		"body": Vector3(0.55, 0.12, -0.82), "body_col": Color(1.0, 0.78, 0.5), "body_size": 0.0042,
		"stars": 0.0, "cloud": 0.5, "cloud_col": Color(1.0, 0.85, 0.8), "cloud_shade": Color(0.75, 0.45, 0.6),
		"fog": Color(0.95, 0.62, 0.55), "fog_d": 0.0042, "amb": Color(0.62, 0.48, 0.66), "amb_e": 0.95,
		"sun": Color(1.0, 0.7, 0.45), "sun_e": 1.2,
		"wall_lo": Color(0.70, 0.50, 0.52), "wall_hi": Color(0.85, 0.62, 0.65),
		"ground": Color(0.52, 0.44, 0.50), "lines": Color(0.55, 0.40, 0.50), "win": 0.35,
	},
	{
		"top": Color(0.02, 0.02, 0.12), "mid": Color(0.14, 0.08, 0.34), "hor": Color(0.55, 0.26, 0.52),
		"body": Vector3(-0.35, 0.42, -0.84), "body_col": Color(1.0, 0.96, 0.88), "body_size": 0.0016,
		"stars": 1.0, "cloud": 0.35, "cloud_col": Color(0.45, 0.35, 0.7), "cloud_shade": Color(0.15, 0.1, 0.3),
		"fog": Color(0.22, 0.12, 0.38), "fog_d": 0.0055, "amb": Color(0.38, 0.38, 0.68), "amb_e": 0.9,
		"sun": Color(0.72, 0.8, 1.0), "sun_e": 1.0,
		"wall_lo": Color(0.10, 0.09, 0.22), "wall_hi": Color(0.18, 0.12, 0.32),
		"ground": Color(0.14, 0.13, 0.24), "lines": Color(0.30, 0.35, 0.60), "win": 1.0,
	},
]

signal _tapped

var player: Player
var npcs := {}
var hud
var hud_layer: CanvasLayer
var dialogue
var overlay: ColorRect
var cine: Camera3D
var env: Environment
var sun: DirectionalLight3D
var sky: MeshInstance3D
var sky_mat: ShaderMaterial
var ground_mat: ShaderMaterial
var bld_mat: ShaderMaterial
var lantern_mat: StandardMaterial3D
var big_lantern_mat: ShaderMaterial
var big_lantern_glow: MeshInstance3D
var light_petals: CPUParticles3D
var cat_tail: Node3D

var stage := "opening"
var talk_target := ""
var delivered := {}
var _time := 0.0
var _time_tw: Tween
var _night_items: Array = []
var _glow_mats := {}
var _glow_groups := {}
var _bakers := {}
var _partner: Npc
var _speaker := ""
var _busy := false
var _orbit := false
var _awaiting_tap := false
var _t := 0.0
var _syl := 0.0


func _ready() -> void:
	Game.reset_run()
	_build_environment()
	_build_sky()
	_build_ground()
	_build_skyline()
	_build_plaza()
	_build_shops()
	_build_shrine()
	_build_npcs()
	_build_player()
	_build_fx()
	_build_ui()
	_flush_baked()
	_apply_time(0.0)
	_start()


# ------------------------------------------------------------------ helpers
## Props are baked into a few big meshes (vertex colours) - ~300 boxes become a handful of draw calls.
## Returns just the colour; the shared prop material does the toon shading.
func _toon_mat(color: Color, _emission := Color(0, 0, 0, 1), _rim := 0.3, _shade := Color(0.62, 0.55, 0.8)) -> Color:
	return color


## A toon material whose emission fades in at night (windows, lanterns). Gets its own baked mesh.
func _night_toon(color: Color, day_emit: Color, night_emit: Color) -> ShaderMaterial:
	var m := ShaderMaterial.new()
	m.shader = TOON
	m.set_shader_parameter("albedo", color)
	m.set_shader_parameter("rim_strength", 0.0)
	m.set_shader_parameter("emission_color", day_emit)
	_night_items.append({"mat": m, "param": "emission_color", "a": day_emit, "b": night_emit})
	return m


func _xf(parent: Node, pos: Vector3, rot := Vector3.ZERO, scl := Vector3.ONE) -> Transform3D:
	var base := Transform3D.IDENTITY
	if parent is Node3D:
		base = (parent as Node3D).global_transform
	return base * Transform3D(Basis.from_euler(rot) * Basis.from_scale(scl), pos)


func _bake_add(mat: Variant, mesh: Mesh, xf: Transform3D) -> void:
	var color := Color.WHITE
	var key: Variant = "prop"
	if mat is Color:
		color = mat
	else:
		key = mat
	if not _bakers.has(key):
		_bakers[key] = Baker.new()
	(_bakers[key] as Baker).add(mesh, xf, color)


func _collider(parent: Node, shape: Shape3D, pos: Vector3, rot := Vector3.ZERO) -> void:
	var sb := StaticBody3D.new()
	sb.position = pos
	sb.rotation = rot
	var cs := CollisionShape3D.new()
	cs.shape = shape
	sb.add_child(cs)
	parent.add_child(sb)


func _box(parent: Node, pos: Vector3, size: Vector3, mat: Variant, collide := false, rot := Vector3.ZERO) -> void:
	_bake_add(mat, Baker.box(size), _xf(parent, pos, rot))
	if collide:
		var bs := BoxShape3D.new()
		bs.size = size
		_collider(parent, bs, pos, rot)


func _cyl(parent: Node, pos: Vector3, radius: float, height: float, mat: Variant, collide := false, segs := 18) -> void:
	_bake_add(mat, Baker.cyl(radius, radius, height, segs), _xf(parent, pos))
	if collide:
		var sh := CylinderShape3D.new()
		sh.radius = radius
		sh.height = height
		_collider(parent, sh, pos)


func _sphere(parent: Node, pos: Vector3, radius: float, mat: Variant, segs := 12, scl := Vector3.ONE) -> void:
	_bake_add(mat, Baker.sphere(radius, segs), _xf(parent, pos, Vector3.ZERO, scl))


## Additive billboard glow (fake bloom). Night glows are batched into one MultiMesh per colour.
func _glow(parent: Node, pos: Vector3, size: float, color: Color, intensity := 1.0, pulse := 0.0, night_driven := true) -> MeshInstance3D:
	var key := "%s|%s|%s" % [color, intensity, pulse]
	if night_driven:
		var m: ShaderMaterial
		if _glow_mats.has(key):
			m = _glow_mats[key]
		else:
			m = ShaderMaterial.new()
			m.shader = GLOW
			m.set_shader_parameter("glow_color", color)
			m.set_shader_parameter("intensity", 0.0)
			m.set_shader_parameter("pulse_speed", pulse)
			_glow_mats[key] = m
			_night_items.append({"mat": m, "param": "intensity", "a": 0.0, "b": intensity})
			_glow_groups[m] = []
		(_glow_groups[m] as Array).append(_xf(parent, pos, Vector3.ZERO, Vector3(size, size, 1.0)))
		return null
	var dm := ShaderMaterial.new()
	dm.shader = GLOW
	dm.set_shader_parameter("glow_color", color)
	dm.set_shader_parameter("intensity", 0.0)
	dm.set_shader_parameter("pulse_speed", pulse)
	var mi := MeshInstance3D.new()
	var q := QuadMesh.new()
	q.size = Vector2(size, size)
	mi.mesh = q
	mi.material_override = dm
	mi.position = pos
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	parent.add_child(mi)
	return mi


func _flush_baked() -> void:
	var prop_mat := ShaderMaterial.new()
	prop_mat.shader = TOON
	prop_mat.set_shader_parameter("use_vcol", 1.0)
	prop_mat.set_shader_parameter("rim_strength", 0.3)
	prop_mat.set_shader_parameter("shade_color", Color(0.62, 0.55, 0.8))
	for key in _bakers:
		var bk: Baker = _bakers[key]
		var mi := MeshInstance3D.new()
		mi.mesh = bk.build()
		mi.material_override = prop_mat if key is String else (key as Material)
		mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		add_child(mi)
	_bakers.clear()
	for m in _glow_groups:
		var xfs: Array = _glow_groups[m]
		var mm := MultiMesh.new()
		mm.transform_format = MultiMesh.TRANSFORM_3D
		var q := QuadMesh.new()
		q.size = Vector2(1, 1)
		mm.mesh = q
		mm.instance_count = xfs.size()
		for i in xfs.size():
			mm.set_instance_transform(i, xfs[i])
		var mmi := MultiMeshInstance3D.new()
		mmi.multimesh = mm
		mmi.material_override = m
		mmi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		add_child(mmi)
	_glow_groups.clear()


func _front(p: Vector3, dist: float, side := 0.0) -> Vector3:
	var dir := Vector3(-p.x, 0.0, -p.z).normalized()
	var perp := dir.cross(Vector3.UP)
	return p + dir * dist + perp * side


func _face_center_y(p: Vector3) -> float:
	var dir := Vector3(-p.x, 0.0, -p.z).normalized()
	return atan2(dir.x, dir.z)


# ------------------------------------------------------------------ world
func _build_environment() -> void:
	var we := WorldEnvironment.new()
	env = Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = Color(0.6, 0.75, 0.95)
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.fog_enabled = true
	we.environment = env
	add_child(we)
	sun = DirectionalLight3D.new()
	sun.shadow_enabled = false
	add_child(sun)


func _build_sky() -> void:
	var sm := SphereMesh.new()
	sm.radius = 300.0
	sm.height = 600.0
	sm.radial_segments = 24
	sm.rings = 12
	sky_mat = ShaderMaterial.new()
	sky_mat.shader = SKY
	sky_mat.render_priority = -100
	sky = MeshInstance3D.new()
	sky.mesh = sm
	sky.material_override = sky_mat
	sky.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	sky.extra_cull_margin = 16384.0
	add_child(sky)


func _build_ground() -> void:
	var pm := PlaneMesh.new()
	pm.size = Vector2(500, 500)
	var mi := MeshInstance3D.new()
	mi.mesh = pm
	ground_mat = ShaderMaterial.new()
	ground_mat.shader = GROUND
	mi.material_override = ground_mat
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(mi)
	var body := StaticBody3D.new()
	var cs := CollisionShape3D.new()
	var bs := BoxShape3D.new()
	bs.size = Vector3(120, 2, 120)
	cs.shape = bs
	cs.position.y = -1.0
	body.add_child(cs)
	add_child(body)


func _build_skyline() -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = 11
	var xforms: Array[Transform3D] = []
	var datas: Array[Color] = []
	for ring in 2:
		var count := 34 if ring == 0 else 52
		for i in count:
			var ang := TAU * (float(i) + rng.randf_range(-0.25, 0.25)) / float(count)
			var r := rng.randf_range(56.0, 68.0) if ring == 0 else rng.randf_range(105.0, 150.0)
			var h := rng.randf_range(6.0, 15.0) if ring == 0 else rng.randf_range(16.0, 52.0)
			var w := rng.randf_range(9.0, 15.0) * (1.0 if ring == 0 else 1.4)
			var d := rng.randf_range(9.0, 15.0) * (1.0 if ring == 0 else 1.4)
			var b := Basis(Vector3.UP, rng.randf() * TAU) * Basis.from_scale(Vector3(w, h, d))
			xforms.append(Transform3D(b, Vector3(sin(ang) * r, h * 0.5, -cos(ang) * r)))
			datas.append(Color(rng.randf(), rng.randf(), rng.randf(), 1.0))
	var mm := MultiMesh.new()
	mm.transform_format = MultiMesh.TRANSFORM_3D
	mm.use_custom_data = true
	var bm := BoxMesh.new()
	bm.size = Vector3.ONE
	mm.mesh = bm
	mm.instance_count = xforms.size()
	for i in xforms.size():
		mm.set_instance_transform(i, xforms[i])
		mm.set_instance_custom_data(i, datas[i])
	var mmi := MultiMeshInstance3D.new()
	mmi.multimesh = mm
	bld_mat = ShaderMaterial.new()
	bld_mat.shader = BUILDING
	mmi.material_override = bld_mat
	mmi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(mmi)


func _build_plaza() -> void:
	var stone := _toon_mat(Color(0.80, 0.76, 0.82))
	var dark := _toon_mat(Color(0.30, 0.26, 0.40), Color(0, 0, 0, 1), 0.2)
	var wood := _toon_mat(Color(0.60, 0.40, 0.30))

	# --- fountain
	_cyl(self, Vector3(0, 0.3, 0), 3.4, 0.6, stone, true)
	_cyl(self, Vector3(0, 0.4, 0), 2.8, 0.5, _toon_mat(Color(0.45, 0.78, 0.95), Color(0.12, 0.3, 0.4), 0.5))
	_cyl(self, Vector3(0, 1.4, 0), 0.4, 2.0, stone)
	_sphere(self, Vector3(0, 2.6, 0), 0.5, _toon_mat(Color(0.7, 0.9, 1.0), Color(0.1, 0.25, 0.35), 0.6))
	_glow(self, Vector3(0, 2.6, 0), 5.0, Color(0.5, 0.85, 1.0), 0.8, 1.5)

	# --- lamp posts + string lanterns
	var posts: Array[Vector3] = []
	for i in 12:
		var a := TAU * float(i) / 12.0 + 0.13
		posts.append(Vector3(sin(a) * 23.0, 0.0, -cos(a) * 23.0))
	for i in posts.size():
		var p := posts[i]
		_box(self, p + Vector3(0, 2.2, 0), Vector3(0.18, 4.4, 0.18), dark)
		var c := Color(1.0, 0.75, 0.45)
		_box(self, p + Vector3(0, 4.45, 0), Vector3(0.45, 0.45, 0.45), _night_toon(Color(1.0, 0.95, 0.85), Color(0.2, 0.18, 0.12), c))
		_glow(self, p + Vector3(0, 4.45, 0), 4.2, c, 1.0, 1.4)
	var lan := MultiMesh.new()
	lan.transform_format = MultiMesh.TRANSFORM_3D
	lan.use_colors = true
	var lm := SphereMesh.new()
	lm.radius = 0.22
	lm.height = 0.36
	lm.radial_segments = 8
	lm.rings = 4
	lan.mesh = lm
	var cols := [Color(1.0, 0.35, 0.35), Color(1.0, 0.7, 0.3), Color(1.0, 0.5, 0.6), Color(1.0, 0.9, 0.5)]
	lan.instance_count = posts.size() * 6
	var k := 0
	for i in posts.size():
		var a := posts[i] + Vector3(0, 4.3, 0)
		var b := posts[(i + 1) % posts.size()] + Vector3(0, 4.3, 0)
		for j in 6:
			var u := (float(j) + 0.5) / 6.0
			var pos := a.lerp(b, u) - Vector3(0, 0.9 * sin(PI * u), 0)
			lan.set_instance_transform(k, Transform3D(Basis.IDENTITY, pos))
			lan.set_instance_color(k, cols[(i + j) % cols.size()])
			k += 1
	var lmi := MultiMeshInstance3D.new()
	lmi.multimesh = lan
	lantern_mat = StandardMaterial3D.new()
	lantern_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	lantern_mat.vertex_color_use_as_albedo = true
	lmi.material_override = lantern_mat
	lmi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(lmi)

	# --- bench with the cat (Mr. Kuroda's spot)
	var bench := Node3D.new()
	bench.position = Vector3(-22.4, 0, -3.0)
	bench.rotation.y = PI * 0.5
	add_child(bench)
	_box(bench, Vector3(0, 0.5, 0), Vector3(2.4, 0.12, 0.7), wood, true)
	_box(bench, Vector3(0, 0.95, -0.3), Vector3(2.4, 0.6, 0.1), wood)
	for sx in [-1.0, 1.0]:
		_box(bench, Vector3(1.05 * sx, 0.25, 0), Vector3(0.12, 0.5, 0.6), dark)
	cat_tail = _make_cat(Vector3(-22.35, 0.56, -1.7))

	# --- sakura trees
	var trunk := _toon_mat(Color(0.38, 0.26, 0.28))
	var bloom := _toon_mat(Color(1.0, 0.72, 0.84), Color(0.12, 0.04, 0.06), 0.5, Color(0.85, 0.5, 0.72))
	for t in [Vector2(-9, -8), Vector2(11, 8), Vector2(-20, 6), Vector2(19, -9), Vector2(2, 16), Vector2(-5, -13), Vector2(17, -17)]:
		var holder := Node3D.new()
		holder.position = Vector3(t.x, 0, t.y)
		add_child(holder)
		_cyl(holder, Vector3(0, 1.5, 0), 0.28, 3.0, trunk, false, 8)
		for j in 3:
			_sphere(holder, Vector3(sin(j * 2.1) * 1.1, 3.6 + j * 0.5, cos(j * 2.1) * 1.1), 1.9 - j * 0.3, bloom, 10, Vector3(1.0, 0.85, 1.0))
		var sb := StaticBody3D.new()
		var cs := CollisionShape3D.new()
		var sh := CylinderShape3D.new()
		sh.radius = 0.35
		sh.height = 3.0
		cs.shape = sh
		cs.position.y = 1.5
		sb.add_child(cs)
		holder.add_child(sb)

	# --- a few crates / planters for jumping about
	var crate := _toon_mat(Color(0.72, 0.55, 0.4))
	for c in [Vector3(7, 0.4, 5.5), Vector3(8.2, 0.4, 5.7), Vector3(7.6, 1.2, 5.6), Vector3(-7, 0.4, -4), Vector3(14, 0.4, -4)]:
		_box(self, c, Vector3(1.2, 0.8, 1.2), crate, true)


func _make_cat(pos: Vector3) -> Node3D:
	var cat := Node3D.new()
	cat.position = pos
	add_child(cat)
	var orange := Color(1.0, 0.65, 0.3)
	var bk := Baker.new()
	bk.add(Baker.sphere(0.22, 10), Transform3D(Basis.from_scale(Vector3(1.0, 0.8, 1.4)), Vector3(0, 0.18, 0)), orange)
	bk.add(Baker.sphere(0.16, 10), Transform3D(Basis.IDENTITY, Vector3(0, 0.38, 0.28)), orange)
	for sx in [-1.0, 1.0]:
		bk.add(Baker.box(Vector3(0.07, 0.1, 0.04)), Transform3D(Basis(Vector3.BACK, -0.3 * sx), Vector3(0.09 * sx, 0.54, 0.28)), orange)
		bk.add(Baker.sphere(0.022, 6), Transform3D(Basis.IDENTITY, Vector3(0.06 * sx, 0.4, 0.42)), Color(0.05, 0.05, 0.1))
	var mi := MeshInstance3D.new()
	mi.mesh = bk.build()
	mi.material_override = _vcol_toon()
	cat.add_child(mi)
	var tail := Node3D.new()
	tail.position = Vector3(0, 0.22, -0.28)
	cat.add_child(tail)
	var tb := Baker.new()
	tb.add(Baker.box(Vector3(0.06, 0.34, 0.06)), Transform3D(Basis(Vector3.RIGHT, 0.4), Vector3(0, 0.14, -0.04)), orange)
	var tmi := MeshInstance3D.new()
	tmi.mesh = tb.build()
	tmi.material_override = _vcol_toon()
	tail.add_child(tmi)
	return tail


func _vcol_toon() -> ShaderMaterial:
	var m := ShaderMaterial.new()
	m.shader = TOON
	m.set_shader_parameter("use_vcol", 1.0)
	m.set_shader_parameter("rim_strength", 0.2)
	return m


func _shop(p: Vector3, wall: Color, awning: Color, text: String, flowers: bool) -> void:
	var holder := Node3D.new()
	holder.position = p
	holder.rotation.y = _face_center_y(p)
	add_child(holder)
	var wall_m := _toon_mat(wall)
	var roof_m := _toon_mat(wall * 0.62)
	var white := _toon_mat(Color(1, 1, 1))
	_box(holder, Vector3(0, 3.2, 0), Vector3(10.0, 6.4, 7.5), wall_m, true)
	_box(holder, Vector3(0, 6.55, 0), Vector3(10.6, 0.5, 8.1), roof_m)
	_box(holder, Vector3(0, 1.35, 3.78), Vector3(1.5, 2.7, 0.12), _toon_mat(Color(0.45, 0.28, 0.22)))
	var win := _night_toon(Color(0.7, 0.85, 1.0), Color(0.12, 0.18, 0.26), Color(1.0, 0.8, 0.5))
	for sx in [-1.0, 1.0]:
		_box(holder, Vector3(3.1 * sx, 1.9, 3.78), Vector3(2.6, 1.7, 0.1), win)
	var aw := Node3D.new()
	aw.position = Vector3(0, 3.55, 4.9)
	aw.rotation.x = 0.3
	holder.add_child(aw)
	for i in 5:
		_box(aw, Vector3((float(i) - 2.0) * 2.08, 0, 0), Vector3(2.08, 0.14, 2.6), _toon_mat(awning) if i % 2 == 0 else white)
	_box(holder, Vector3(0, 5.2, 3.8), Vector3(6.2, 1.2, 0.18), _toon_mat(wall * 0.45 + Color(0.1, 0.05, 0.05)))
	var lbl := Label3D.new()
	lbl.text = text
	lbl.font_size = 72
	lbl.pixel_size = 0.0105
	lbl.outline_size = 12
	lbl.modulate = Color(1, 0.95, 0.9)
	lbl.outline_modulate = Color(0.25, 0.1, 0.18)
	lbl.position = Vector3(0, 5.2, 3.92)
	holder.add_child(lbl)
	if flowers:
		var pots := [Color(1.0, 0.45, 0.6), Color(1.0, 0.85, 0.35), Color(0.95, 0.95, 1.0), Color(0.75, 0.55, 1.0), Color(1.0, 0.6, 0.35), Color(1.0, 0.5, 0.7)]
		for i in 6:
			var x := -4.2 + float(i) * 1.7
			_cyl(holder, Vector3(x, 0.17, 5.9), 0.24, 0.34, _toon_mat(Color(0.75, 0.45, 0.35)), false, 8)
			_sphere(holder, Vector3(x, 0.52, 5.9), 0.26, _toon_mat(pots[i], Color(0, 0, 0, 1), 0.3), 8)


func _build_shops() -> void:
	_shop(FLORIST_POS, Color(0.98, 0.86, 0.88), Color(1.0, 0.5, 0.65), "TSUKISHIRO FLOWERS", true)
	_shop(BAKERY_POS, Color(0.99, 0.92, 0.78), Color(0.95, 0.6, 0.25), "HOSHIGAOKA BAKERY", false)
	# side shops to frame the plaza
	_shop(Vector3(-30.0, 0.0, 2.0), Color(0.82, 0.9, 0.98), Color(0.4, 0.65, 0.95), "TEA HOUSE", false)
	_shop(Vector3(30.0, 0.0, -6.0), Color(0.9, 0.85, 0.98), Color(0.65, 0.45, 0.9), "BOOKS", false)


func _build_shrine() -> void:
	var stone := _toon_mat(Color(0.78, 0.75, 0.8))
	var red := _toon_mat(Color(0.88, 0.2, 0.28), Color(0.1, 0.0, 0.02), 0.4, Color(0.5, 0.1, 0.25))
	var black := _toon_mat(Color(0.12, 0.1, 0.2))
	# steps
	_box(self, Vector3(0, 0.125, -20.6), Vector3(8.0, 0.25, 2.6), stone, true)
	_box(self, Vector3(0, 0.375, -22.2), Vector3(7.0, 0.25, 2.6), stone, true)
	# torii
	var z := -25.0
	_box(self, Vector3(-3.4, 3.6, z), Vector3(0.8, 7.2, 0.8), red, true)
	_box(self, Vector3(3.4, 3.6, z), Vector3(0.8, 7.2, 0.8), red, true)
	_box(self, Vector3(0, 7.5, z), Vector3(11.0, 0.7, 1.1), black)
	_box(self, Vector3(0, 7.95, z), Vector3(12.0, 0.3, 1.3), red)
	_box(self, Vector3(0, 6.1, z), Vector3(8.0, 0.45, 0.55), red)
	# stone lanterns
	for sx in [-1.0, 1.0]:
		var x: float = 5.6 * sx
		_box(self, Vector3(x, 0.3, -22.5), Vector3(0.9, 0.6, 0.9), stone, true)
		_box(self, Vector3(x, 1.2, -22.5), Vector3(0.35, 1.2, 0.35), stone)
		_box(self, Vector3(x, 2.0, -22.5), Vector3(0.9, 0.5, 0.9), _night_toon(Color(0.95, 0.9, 0.8), Color(0.15, 0.12, 0.08), Color(1.0, 0.75, 0.4)))
		_box(self, Vector3(x, 2.45, -22.5), Vector3(1.2, 0.2, 1.2), stone)
		_glow(self, Vector3(x, 2.0, -22.3), 3.4, Color(1.0, 0.72, 0.4), 0.9, 1.2)
	# the big festival lantern Shino lights at the end of the chapter
	_box(self, LANTERN_POS + Vector3(0, 1.9, 0), Vector3(0.22, 3.8, 0.22), black, true)
	_box(self, LANTERN_POS + Vector3(0, 3.7, 0), Vector3(1.1, 0.12, 1.1), black)
	big_lantern_mat = ShaderMaterial.new()
	big_lantern_mat.shader = TOON
	big_lantern_mat.set_shader_parameter("albedo", Color(1.0, 0.45, 0.35))
	big_lantern_mat.set_shader_parameter("emission_color", Color(0.18, 0.04, 0.03))
	big_lantern_mat.set_shader_parameter("rim_strength", 0.4)
	_sphere(self, LANTERN_POS + Vector3(0, 4.7, 0), 0.9, big_lantern_mat, 14, Vector3(1.0, 1.15, 1.0))
	_box(self, LANTERN_POS + Vector3(0, 5.85, 0), Vector3(0.7, 0.18, 0.7), black)
	# its glow is driven by the story (not by time of day)
	big_lantern_glow = _glow(self, LANTERN_POS + Vector3(0, 4.7, 0), 9.0, Color(1.0, 0.6, 0.35), 1.3, 0.0, false)


func _npc_cfg(id: String) -> Dictionary:
	match id:
		"sachi":
			return {"scale": 0.92, "outfit": Color(0.95, 0.65, 0.75), "hair": Color(0.92, 0.92, 0.95), "hat": "bun", "apron": Color(1.0, 0.96, 0.92), "prop": "flowers"}
		"tanaka":
			return {"scale": 1.08, "outfit": Color(0.95, 0.95, 1.0), "hair": Color(0.2, 0.15, 0.12), "hat": "chef", "apron": Color(0.95, 0.75, 0.45), "skin": Color(1.0, 0.78, 0.66)}
		"kuroda":
			return {"scale": 0.98, "outfit": Color(0.45, 0.5, 0.62), "hair": Color(0.85, 0.85, 0.88), "hat": "cap", "hat_color": Color(0.3, 0.35, 0.45), "sit": true}
		"rin":
			return {"scale": 1.02, "outfit": Color(0.9, 0.4, 0.45), "hair": Color(0.25, 0.18, 0.3), "hat": "beanie", "hat_color": Color(0.3, 0.7, 0.8), "prop": "guitar", "sit": true}
		"mimi":
			return {"scale": 0.66, "outfit": Color(1.0, 0.85, 0.4), "hair": Color(0.45, 0.3, 0.2), "hat": "none", "prop": "balloon"}
		"aoki":
			return {"scale": 0.98, "outfit": Color(0.62, 0.45, 0.85), "hair": Color(0.15, 0.12, 0.2), "hat": "glasses", "apron": Color(0.88, 0.25, 0.3)}
	return {}


func _build_npcs() -> void:
	var spots := {
		"sachi": [_front(FLORIST_POS, 6.6, -1.4), 0.0],
		"tanaka": [_front(BAKERY_POS, 6.6, 1.2), 0.0],
		"kuroda": [Vector3(-22.6, 0.0, -3.7), PI * 0.5],
		"rin": [Vector3(2.7, 0.08, 1.6), 0.0],
		"mimi": [Vector3(10.5, 0.0, -11.5), 0.0],
		"aoki": [Vector3(2.4, 0.5, -22.0), 0.0],
	}
	for id in spots:
		var n := Npc.new()
		n.position = spots[id][0]
		n.rotation.y = spots[id][1]
		add_child(n)
		n.build(_npc_cfg(id))
		npcs[id] = n


func _build_player() -> void:
	player = Player.new()
	add_child(player)
	player.build()
	var spawn := _front(FLORIST_POS, 8.6, 1.5)
	player.position = Vector3(spawn.x, 0.05, spawn.z)
	player.model_root.rotation.y = _face_center_y(FLORIST_POS) + 0.2
	player.yaw = player.model_root.rotation.y + player.closeup_side
	player.closeup = true
	player.girl.emotion = "joy"

	cine = Camera3D.new()
	cine.fov = 36.0
	cine.near = 0.08
	cine.far = 420.0
	add_child(cine)


func _build_fx() -> void:
	var p := CPUParticles3D.new()
	p.amount = 90
	p.lifetime = 6.5
	p.preprocess = 6.5
	p.local_coords = false
	p.emission_shape = CPUParticles3D.EMISSION_SHAPE_BOX
	p.emission_box_extents = Vector3(14.0, 0.3, 14.0)
	p.direction = Vector3(0.3, -1.0, 0.1)
	p.spread = 25.0
	p.initial_velocity_min = 0.6
	p.initial_velocity_max = 1.5
	p.gravity = Vector3(0.25, -0.6, 0.1)
	p.angle_min = 0.0
	p.angle_max = 360.0
	p.angular_velocity_min = -90.0
	p.angular_velocity_max = 90.0
	p.scale_amount_min = 0.7
	p.scale_amount_max = 1.3
	var qm := QuadMesh.new()
	qm.size = Vector2(0.14, 0.2)
	p.mesh = qm
	var pm := StandardMaterial3D.new()
	pm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	pm.albedo_color = Color(1.0, 0.72, 0.87)
	pm.billboard_mode = BaseMaterial3D.BILLBOARD_PARTICLES
	pm.cull_mode = BaseMaterial3D.CULL_DISABLED
	p.material_override = pm
	p.visibility_aabb = AABB(Vector3(-30, -14, -30), Vector3(60, 18, 60))
	p.position = Vector3(0, 7.0, 0)
	player.add_child(p)

	# glowing "star petals" that fall at the end of the chapter
	light_petals = CPUParticles3D.new()
	light_petals.amount = 130
	light_petals.lifetime = 8.0
	light_petals.local_coords = false
	light_petals.emitting = false
	light_petals.emission_shape = CPUParticles3D.EMISSION_SHAPE_BOX
	light_petals.emission_box_extents = Vector3(18.0, 0.5, 18.0)
	light_petals.direction = Vector3(0, -1, 0)
	light_petals.spread = 12.0
	light_petals.initial_velocity_min = 0.3
	light_petals.initial_velocity_max = 0.9
	light_petals.gravity = Vector3(0, -0.7, 0)
	light_petals.scale_amount_min = 0.8
	light_petals.scale_amount_max = 1.6
	var lq := QuadMesh.new()
	lq.size = Vector2(0.22, 0.22)
	light_petals.mesh = lq
	var lmat := StandardMaterial3D.new()
	lmat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	lmat.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
	lmat.albedo_color = Color(1.0, 0.72, 0.9)
	lmat.billboard_mode = BaseMaterial3D.BILLBOARD_PARTICLES
	light_petals.material_override = lmat
	light_petals.visibility_aabb = AABB(Vector3(-30, -20, -30), Vector3(60, 30, 60))
	light_petals.position = Vector3(0, 15.0, 0)
	add_child(light_petals)


func _build_ui() -> void:
	hud_layer = CanvasLayer.new()
	hud_layer.layer = 10
	add_child(hud_layer)
	hud = HUD_SCRIPT.new()
	hud.player = player
	hud_layer.add_child(hud)

	var ol := CanvasLayer.new()
	ol.layer = 15
	add_child(ol)
	overlay = ColorRect.new()
	overlay.color = Color(0, 0, 0, 1)
	overlay.set_anchors_preset(Control.PRESET_FULL_RECT)
	overlay.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ol.add_child(overlay)

	dialogue = DIALOGUE_SCRIPT.new()
	add_child(dialogue)
	dialogue.line_started.connect(_on_line)


# ------------------------------------------------------------------ time of day
func _mix(key: String, a: int, f: float) -> Variant:
	return lerp(PAL[a][key], PAL[a + 1][key], f)


func _apply_time(t: float) -> void:
	_time = t
	var a := 0 if t < 0.5 else 1
	var f := (t if a == 0 else t - 0.5) / 0.5
	var nf := clampf((t - 0.45) / 0.55, 0.0, 1.0)
	nf = nf * nf * (3.0 - 2.0 * nf)
	var body: Vector3 = (_mix("body", a, f) as Vector3).normalized()

	sky_mat.set_shader_parameter("top_color", _mix("top", a, f))
	sky_mat.set_shader_parameter("mid_color", _mix("mid", a, f))
	sky_mat.set_shader_parameter("horizon_color", _mix("hor", a, f))
	sky_mat.set_shader_parameter("body_dir", body)
	sky_mat.set_shader_parameter("body_color", _mix("body_col", a, f))
	sky_mat.set_shader_parameter("body_size", _mix("body_size", a, f))
	sky_mat.set_shader_parameter("stars", _mix("stars", a, f))
	sky_mat.set_shader_parameter("cloud_amount", _mix("cloud", a, f))
	sky_mat.set_shader_parameter("cloud_color", _mix("cloud_col", a, f))
	sky_mat.set_shader_parameter("cloud_shade", _mix("cloud_shade", a, f))

	env.fog_light_color = _mix("fog", a, f)
	env.fog_density = _mix("fog_d", a, f)
	env.ambient_light_color = _mix("amb", a, f)
	env.ambient_light_energy = _mix("amb_e", a, f)
	env.background_color = _mix("hor", a, f)
	sun.light_color = _mix("sun", a, f)
	sun.light_energy = _mix("sun_e", a, f)
	sun.basis = Basis.looking_at(-body)

	ground_mat.set_shader_parameter("base_color", _mix("ground", a, f))
	ground_mat.set_shader_parameter("line_color", _mix("lines", a, f))
	ground_mat.set_shader_parameter("night", nf)
	bld_mat.set_shader_parameter("wall_low", _mix("wall_lo", a, f))
	bld_mat.set_shader_parameter("wall_high", _mix("wall_hi", a, f))
	bld_mat.set_shader_parameter("window_lit", _mix("win", a, f))
	for it in _night_items:
		(it["mat"] as ShaderMaterial).set_shader_parameter(it["param"], lerp(it["a"], it["b"], nf))
	var lb := lerpf(0.62, 1.0, maxf(nf, clampf(t * 1.2, 0.0, 0.5)))
	lantern_mat.albedo_color = Color(lb, lb, lb, 1.0)


func _go_time(target: float, dur := 3.0) -> void:
	if _time_tw:
		_time_tw.kill()
	_time_tw = create_tween()
	_time_tw.tween_method(_apply_time, _time, target, dur)


# ------------------------------------------------------------------ story flow
func _start() -> void:
	hud_layer.visible = false
	player.frozen = true
	overlay.color.a = 1.0
	await get_tree().create_timer(0.5).timeout
	Sfx.ambient("ambient_city")
	var tw := create_tween()
	tw.tween_property(overlay, "color:a", 0.0, 1.4)
	await tw.finished
	if not OS.get_cmdline_user_args().has("--skip-intro"):
		await dialogue.run(Game.scene_lines("opening"))
	_end_shots()
	player.frozen = false
	stage = "grandma"
	hud_layer.visible = true
	hud.set_objective("Talk to Grandma at the flower shop.\nLeft thumb: move   Right side: look")


func _on_line(line: Dictionary) -> void:
	_speaker = String(line.get("who", ""))
	var emo := String(line.get("emotion", "neutral"))
	if String(line.get("id", "")) == "f_4":
		Sfx.play("hum", -2.0)
	if _speaker == "shino":
		player.girl.emotion = emo
		cine.current = false
		player.cam.current = true
		player.closeup = true
	else:
		var n: Npc = npcs.get(_speaker)
		if n:
			var head := n.global_position + Vector3(0, n.head_y, 0)
			var to_p := player.global_position - n.global_position
			to_p.y = 0.0
			to_p = to_p.normalized()
			var side := to_p.cross(Vector3.UP)
			cine.look_at_from_position(head + to_p * 1.75 * maxf(n.scale.x, 0.8) + side * 0.5 + Vector3(0, 0.05, 0), head)
			cine.current = true
			player.closeup = true


func _end_shots() -> void:
	player.closeup = false
	player.talking = false
	player.girl.emotion = "neutral"
	player.cam.current = true
	cine.current = false
	_partner = null
	_speaker = ""


func _available(id: String) -> bool:
	if _busy or stage == "opening":
		return false
	match id:
		"sachi":
			return stage == "grandma"
		"aoki":
			return stage == "deliver" and delivered.size() >= 4
		_:
			return stage == "deliver" and not delivered.has(id)


func _talk(id: String) -> void:
	if _busy:
		return
	_busy = true
	talk_target = ""
	var n: Npc = npcs.get(id)
	if n:
		player.face_point(n.global_position)
		_partner = n
	if id == "sachi":
		Sfx.play("door_bell", -6.0)
	await dialogue.run(Game.scene_lines(id))
	_end_shots()
	match id:
		"sachi":
			stage = "deliver"
			player.girl.carrying = true
			hud.set_objective("Deliver the bouquets (0/5).\nFollow the arrow.")
		"aoki":
			await _finale()
		_:
			delivered[id] = true
			Sfx.play("pickup")
			var count := Game.add_delivery()
			_go_time(float(count) * 0.14, 4.0)
			if count >= 4:
				hud.set_objective("Last one! Bring the final bouquet to\nMs. Aoki at the shrine steps.")
			else:
				hud.set_objective("Deliver the bouquets (%d/5).\nFollow the arrow." % count)
	_busy = false


func _finale() -> void:
	Game.add_delivery()
	Sfx.play("pickup")
	hud_layer.visible = false
	player.girl.carrying = false
	player.frozen = true
	player.velocity = Vector3.ZERO
	player.global_position = LANTERN_POS + Vector3(1.0, 0.05, 2.6)
	player.face_point(LANTERN_POS)
	player.cam_dist = 5.2
	player.pitch = -0.1
	player.yaw = player.model_root.rotation.y + PI + 0.5
	_orbit = true
	_go_time(1.0, 8.0)
	await get_tree().create_timer(6.5).timeout
	_orbit = false
	await dialogue.run(Game.scene_lines("lantern"))
	# light the lantern
	Sfx.play("lantern")
	var tw := create_tween().set_parallel(true)
	tw.tween_method(func(v: float): big_lantern_mat.set_shader_parameter("emission_color", Color(1.0, 0.55, 0.3) * v), 0.2, 1.4, 1.8)
	tw.tween_method(func(v: float): (big_lantern_glow.material_override as ShaderMaterial).set_shader_parameter("intensity", v), 0.0, 1.3, 1.8)
	await tw.finished
	await get_tree().create_timer(1.0).timeout
	light_petals.emitting = true
	Sfx.play("petals")
	await get_tree().create_timer(3.5).timeout
	await dialogue.run(Game.scene_lines("finale"))
	_end_shots()
	await _end_card()


func _end_card() -> void:
	var layer := CanvasLayer.new()
	layer.layer = 25
	add_child(layer)
	var bg := ColorRect.new()
	bg.color = Color(0.03, 0.01, 0.08, 0.0)
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	layer.add_child(bg)
	var box := VBoxContainer.new()
	box.set_anchors_preset(Control.PRESET_FULL_RECT)
	box.alignment = BoxContainer.ALIGNMENT_CENTER
	box.modulate.a = 0.0
	layer.add_child(box)
	for pair in [["TO BE CONTINUED", 72, Color(1.0, 0.88, 0.95)], ["Chapter 1: An Ordinary Day  -  Part 1 of 10", 26, Color(0.8, 0.95, 1.0)], ["", 20, Color.WHITE], ["tap to return to the title", 22, Color(1, 1, 1, 0.7)]]:
		var l := Label.new()
		l.text = pair[0]
		l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		l.add_theme_font_size_override("font_size", pair[1])
		l.add_theme_color_override("font_color", pair[2])
		l.add_theme_constant_override("outline_size", 10)
		l.add_theme_color_override("font_outline_color", Color(0.5, 0.1, 0.4))
		box.add_child(l)
	var tw := create_tween()
	tw.tween_property(bg, "color:a", 0.9, 1.6)
	tw.tween_property(box, "modulate:a", 1.0, 1.0)
	await tw.finished
	_awaiting_tap = true
	await _tapped
	Sfx.stop_ambient()
	get_tree().change_scene_to_file("res://scenes/title.tscn")


# ------------------------------------------------------------------ per frame
func _mouth_level() -> float:
	if not dialogue.speaking:
		return 0.0
	var l := Sfx.voice_level()
	if l >= 0.0:
		return l
	return clampf(absf(sin(_syl * 9.0)) * (0.55 + 0.45 * sin(_syl * 2.7)) + 0.12, 0.0, 1.0)


func _process(delta: float) -> void:
	_t += delta
	_syl += delta
	sky.global_position = player.cam.global_position if player.cam.current else cine.global_position
	if _orbit:
		player.yaw += delta * 0.14
	cat_tail.rotation.y = sin(_t * 2.2) * 0.5
	if _partner:
		_partner.face_point(player.global_position, clampf(6.0 * delta, 0.0, 1.0))

	# lip sync
	var lvl := _mouth_level()
	player.talking = dialogue.speaking and _speaker == "shino"
	player.girl.mouth_open = lvl if _speaker == "shino" else 0.0
	for id in npcs:
		(npcs[id] as Npc).mouth_open = lvl if _speaker == id else 0.0

	# who can be talked to right now
	var best := ""
	var best_d := TALK_RANGE
	var target_pos := Vector3.INF
	var target_d := 1e9
	for id in npcs:
		var n: Npc = npcs[id]
		var av := _available(id)
		n.marker.visible = av
		if av:
			var d := Vector2(player.global_position.x - n.global_position.x, player.global_position.z - n.global_position.z).length()
			if d < best_d:
				best_d = d
				best = id
			if d < target_d:
				target_d = d
				target_pos = n.global_position
	talk_target = best
	Game.can_talk = best != "" and not Game.input_locked and not player.frozen
	hud.target_pos = target_pos
	if Game.talk_req:
		Game.talk_req = false
		if Game.can_talk:
			_talk(talk_target)


func _input(event: InputEvent) -> void:
	if _awaiting_tap and Game.is_tap(event):
		_awaiting_tap = false
		_tapped.emit()
