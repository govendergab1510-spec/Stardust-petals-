extends Node
## Plays pre-generated ElevenLabs audio (autoload "Sfx").
## Every call is safe if a file is missing (no API key / not generated yet): the game stays silent instead of crashing.

const SFX_DIR := "res://assets/audio/sfx/"
const VOICE_DIR := "res://assets/audio/voice/"

var _pool: Array[AudioStreamPlayer] = []
var _voice: AudioStreamPlayer
var _ambient: AudioStreamPlayer
var _cache := {}
var _voice_bus := -1
var _voice_clock := 0.0
var _voice_peak_seen := -100.0


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	for i in 6:
		var p := AudioStreamPlayer.new()
		add_child(p)
		_pool.append(p)
	AudioServer.add_bus()
	_voice_bus = AudioServer.bus_count - 1
	AudioServer.set_bus_name(_voice_bus, "Voice")
	_voice = AudioStreamPlayer.new()
	_voice.bus = "Voice"
	_voice.volume_db = 2.0
	add_child(_voice)
	_ambient = AudioStreamPlayer.new()
	add_child(_ambient)


func _get_stream(path: String) -> AudioStream:
	if _cache.has(path):
		return _cache[path]
	var s: AudioStream = null
	if ResourceLoader.exists(path):
		s = load(path) as AudioStream
	_cache[path] = s
	return s


func play(id: String, volume_db := 0.0, pitch := 1.0) -> void:
	var s := _get_stream(SFX_DIR + id + ".mp3")
	if s == null:
		return
	for p in _pool:
		if not p.playing:
			p.stream = s
			p.volume_db = volume_db
			p.pitch_scale = pitch
			p.play()
			return


## Plays a voice line. Returns its length in seconds (0.0 if there is no audio file).
func say(id: String) -> float:
	_voice.stop()
	_voice_clock = 0.0
	_voice_peak_seen = -100.0
	var s := _get_stream(VOICE_DIR + id + ".mp3")
	if s == null:
		return 0.0
	_voice.stream = s
	_voice.play()
	return s.get_length()


func stop_voice() -> void:
	_voice.stop()


func is_voice_playing() -> bool:
	return _voice.playing


## Loudness of the current voice line, 0..1 (drives lip sync). Returns -1.0 when it cannot be measured.
func voice_level() -> float:
	if not _voice.playing:
		return -1.0
	var db := AudioServer.get_bus_peak_volume_left_db(_voice_bus, 0)
	_voice_peak_seen = maxf(_voice_peak_seen, db)
	if _voice_clock > 0.5 and _voice_peak_seen < -70.0:
		return -1.0  # audio driver gives no meter data: caller falls back to a synthetic mouth
	return clampf((db + 42.0) / 26.0, 0.0, 1.0)


func _process(delta: float) -> void:
	if _voice.playing:
		_voice_clock += delta


func ambient(id: String, volume_db := -9.0) -> void:
	var s := _get_stream(SFX_DIR + id + ".mp3")
	if s == null:
		return
	if s is AudioStreamMP3:
		s = s.duplicate()
		s.loop = true
	_ambient.stream = s
	_ambient.volume_db = volume_db
	_ambient.play()


func stop_ambient() -> void:
	_ambient.stop()
