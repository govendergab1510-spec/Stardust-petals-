shader_type spatial;
// Skyline blocks: windows that light up at dusk. Fully procedural, one draw call via MultiMesh.
render_mode unshaded, cull_back;

uniform vec3 wall_low : source_color = vec3(0.86, 0.80, 0.76);
uniform vec3 wall_high : source_color = vec3(0.95, 0.90, 0.92);
uniform vec3 glass : source_color = vec3(0.30, 0.45, 0.62);
uniform float window_lit : hint_range(0.0, 1.0) = 0.0;
uniform vec2 cell = vec2(1.7, 2.3);

varying vec3 wpos;
varying vec3 lpos;
varying vec3 lnrm;
varying vec4 seed;

float hash(vec2 p) {
	return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
}

void vertex() {
	wpos = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz;
	vec3 sc = vec3(length(MODEL_MATRIX[0].xyz), length(MODEL_MATRIX[1].xyz), length(MODEL_MATRIX[2].xyz));
	lpos = VERTEX * sc;
	lnrm = NORMAL;
	seed = INSTANCE_CUSTOM;
}

void fragment() {
	vec3 n = lnrm;
	float wall = step(abs(n.y), 0.5);
	float along = mix(lpos.x, lpos.z, step(0.5, abs(n.x))) + seed.x * 31.0;
	vec2 uv = vec2(along, wpos.y) / cell;
	vec2 id = floor(uv);
	vec2 f = fract(uv);
	float r = hash(id + seed.x * 53.0);
	float win = step(0.2, f.x) * step(f.x, 0.8) * step(0.25, f.y) * step(f.y, 0.78) * wall;
	float on = step(0.5, r) * window_lit;
	vec3 wc = r < 0.68 ? vec3(1.0, 0.78, 0.45) : (r < 0.84 ? vec3(0.55, 0.9, 1.0) : vec3(1.0, 0.55, 0.85));

	vec3 tint = mix(vec3(1.0), vec3(0.8 + seed.y * 0.3, 0.85 + seed.z * 0.2, 0.9 + seed.y * 0.15), 0.8);
	vec3 base = mix(wall_low, wall_high, clamp(wpos.y / 70.0, 0.0, 1.0)) * tint;
	base *= 0.78 + 0.3 * (n.x * 0.5 + 0.5) + 0.2 * n.y;
	vec3 col = mix(base, glass * (0.5 + 0.5 * wall_high), win * (1.0 - on));
	col = mix(col, wc * (0.8 + 0.3 * hash(id + 9.0)), win * on);
	ALBEDO = col;
}
