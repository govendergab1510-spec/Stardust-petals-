shader_type spatial;
// Shopping-street plaza: paving tiles, plaza ring, soft puddles. Unshaded = very cheap.
render_mode unshaded, cull_back;

uniform vec3 base_color : source_color = vec3(0.58, 0.57, 0.62);
uniform vec3 line_color : source_color = vec3(0.45, 0.5, 0.6);
uniform vec3 ring_color : source_color = vec3(1.0, 0.6, 0.75);
uniform float night : hint_range(0.0, 1.0) = 0.0;
uniform float tile = 3.0;

varying vec3 wpos;

float hash(vec2 p) {
	return fract(sin(dot(p, vec2(41.3, 289.1))) * 43758.5453);
}

void vertex() {
	wpos = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz;
}

void fragment() {
	vec2 p = wpos.xz;
	vec2 id = floor(p / tile);
	vec2 f = abs(fract(p / tile) - 0.5);
	float edge = smoothstep(0.47, 0.5, max(f.x, f.y));
	float r = length(p);

	vec3 col = base_color * (0.92 + 0.16 * hash(id));
	// checker brick accent
	col *= 1.0 - 0.06 * mod(id.x + id.y, 2.0);
	col = mix(col, line_color, edge * 0.5);

	// plaza ring + inner circle pattern around the fountain
	float ring1 = smoothstep(0.2, 0.0, abs(r - 7.5));
	float ring2 = smoothstep(0.12, 0.0, abs(r - 11.0));
	float disc = smoothstep(7.5, 7.3, r);
	col = mix(col, col * 0.85 + ring_color * 0.12, disc);
	col += ring_color * (ring1 * 0.5 + ring2 * 0.35) * (0.5 + 0.9 * night);

	// shrine path to the north
	float path = smoothstep(2.2, 1.9, abs(p.x)) * smoothstep(-8.0, -12.0, p.y) * smoothstep(-26.0, -22.0, p.y) ;
	col = mix(col, col * 0.8 + vec3(0.12, 0.1, 0.1), clamp(path, 0.0, 1.0) * 0.8);
	ALBEDO = col;
}
