shader_type spatial;
// Inverted-hull outline (used as next_pass on the characters only).
render_mode unshaded, cull_front;

uniform vec4 outline_color : source_color = vec4(0.07, 0.03, 0.14, 1.0);
uniform float thickness = 0.022; // in world units, independent of model scale

void vertex() {
	float s = max(length(MODEL_MATRIX[0].xyz), 0.0001);
	VERTEX += normalize(NORMAL) * (thickness / s);
}

void fragment() {
	ALBEDO = outline_color.rgb;
}
