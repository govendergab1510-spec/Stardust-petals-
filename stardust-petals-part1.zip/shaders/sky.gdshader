shader_type spatial;
// Anime sky dome that follows the camera: gradient, soft clouds, sun/moon, stars. One cheap pass.
render_mode unshaded, cull_front, depth_draw_never, fog_disabled;

uniform vec3 top_color : source_color = vec3(0.30, 0.58, 0.95);
uniform vec3 mid_color : source_color = vec3(0.62, 0.82, 1.0);
uniform vec3 horizon_color : source_color = vec3(1.0, 0.92, 0.84);
uniform vec3 body_dir = vec3(0.45, 0.62, -0.55);
uniform vec3 body_color : source_color = vec3(1.0, 0.97, 0.85);
uniform float body_size = 0.0016;
uniform float stars = 0.0;
uniform float cloud_amount = 0.55;
uniform vec3 cloud_color : source_color = vec3(1.0);
uniform vec3 cloud_shade : source_color = vec3(0.78, 0.84, 0.98);

varying vec3 dir;

float hash12(vec2 p) {
	vec3 p3 = fract(vec3(p.xyx) * 0.1031);
	p3 += dot(p3, p3.yzx + 33.33);
	return fract((p3.x + p3.y) * p3.z);
}
float hash13(vec3 p) {
	p = fract(p * 0.1031);
	p += dot(p, p.zyx + 31.32);
	return fract((p.x + p.y) * p.z);
}
float vnoise(vec2 p) {
	vec2 i = floor(p);
	vec2 f = fract(p);
	f = f * f * (3.0 - 2.0 * f);
	return mix(mix(hash12(i), hash12(i + vec2(1.0, 0.0)), f.x), mix(hash12(i + vec2(0.0, 1.0)), hash12(i + vec2(1.0, 1.0)), f.x), f.y);
}

void vertex() {
	dir = VERTEX;
}

void fragment() {
	vec3 d = normalize(dir);
	float h = d.y;
	float up = clamp(h, 0.0, 1.0);
	vec3 col = mix(horizon_color, mid_color, smoothstep(0.0, 0.3, up));
	col = mix(col, top_color, smoothstep(0.2, 0.9, up));
	col = mix(col, horizon_color * 0.6, smoothstep(0.0, -0.3, h));

	// stars (night only)
	vec3 g = floor(d * 110.0);
	float r = hash13(g);
	float tw = 0.65 + 0.35 * sin(TIME * (1.5 + r * 4.0) + r * 40.0);
	col += vec3(0.9, 0.95, 1.0) * step(0.9962, r) * tw * smoothstep(0.12, 0.45, h) * stars;

	// sun / moon
	float m = dot(d, normalize(body_dir));
	col += body_color * pow(max(m, 0.0), 24.0) * 0.35;
	col += body_color * pow(max(m, 0.0), 220.0) * 0.5;

	// soft anime clouds
	if (h > 0.0) {
		vec2 cp = d.xz / (h + 0.18) * 1.7 + vec2(TIME * 0.012, 0.0);
		float n = vnoise(cp) * 0.6 + vnoise(cp * 2.3 + 7.0) * 0.4;
		float c = smoothstep(1.0 - cloud_amount, 1.0 - cloud_amount + 0.18, n) * smoothstep(0.0, 0.22, h);
		vec3 cc = mix(cloud_shade, cloud_color, smoothstep(0.35, 0.8, n));
		col = mix(col, cc, c * 0.92);
	}

	float disc = smoothstep(1.0 - body_size, 1.0 - body_size * 0.8, m);
	col = mix(col, body_color, disc);
	ALBEDO = col;
}
