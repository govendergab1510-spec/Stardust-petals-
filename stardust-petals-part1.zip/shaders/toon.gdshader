shader_type spatial;
// Cheap two-tone anime shading: one hard light band, rim light, optional texture.
render_mode specular_disabled, cull_back;

uniform vec4 albedo : source_color = vec4(1.0);
uniform sampler2D albedo_tex : source_color, filter_linear_mipmap, repeat_enable;
uniform float use_tex : hint_range(0.0, 1.0) = 0.0;
uniform float use_vcol : hint_range(0.0, 1.0) = 0.0;
uniform vec4 shade_color : source_color = vec4(0.34, 0.28, 0.62, 1.0);
uniform float shade_edge : hint_range(0.01, 1.0) = 0.1;
uniform vec4 rim_color : source_color = vec4(0.55, 0.85, 1.0, 1.0);
uniform float rim_strength : hint_range(0.0, 2.0) = 0.6;
uniform float rim_power : hint_range(0.5, 8.0) = 3.0;
uniform vec4 emission_color : source_color = vec4(0.0, 0.0, 0.0, 1.0);

void fragment() {
	vec4 c = albedo;
	if (use_tex > 0.5) {
		c *= texture(albedo_tex, UV);
	}
	if (use_vcol > 0.5) {
		c.rgb *= COLOR.rgb;
	}
	ALBEDO = c.rgb;
	float fres = pow(1.0 - clamp(dot(normalize(NORMAL), normalize(VIEW)), 0.0, 1.0), rim_power);
	EMISSION = emission_color.rgb + rim_color.rgb * fres * rim_strength;
}

void light() {
	float ndl = dot(NORMAL, LIGHT);
	float band = smoothstep(0.0, shade_edge, ndl);
	vec3 lit = mix(shade_color.rgb, vec3(1.0), band);
	DIFFUSE_LIGHT += LIGHT_COLOR / PI * lit * ATTENUATION;
}
