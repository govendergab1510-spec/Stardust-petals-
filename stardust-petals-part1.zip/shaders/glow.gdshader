shader_type spatial;
// Additive billboard glow - fake bloom for lamps, shards, beacons. Replaces expensive post-process glow.
render_mode unshaded, blend_add, depth_draw_never, cull_disabled, fog_disabled;

uniform vec4 glow_color : source_color = vec4(1.0, 0.5, 0.8, 1.0);
uniform float intensity = 1.0;
uniform float pulse_speed = 0.0;

void vertex() {
	vec3 sc = vec3(length(MODEL_MATRIX[0].xyz), length(MODEL_MATRIX[1].xyz), length(MODEL_MATRIX[2].xyz));
	MODELVIEW_MATRIX = VIEW_MATRIX * mat4(INV_VIEW_MATRIX[0], INV_VIEW_MATRIX[1], INV_VIEW_MATRIX[2], MODEL_MATRIX[3]);
	MODELVIEW_MATRIX = MODELVIEW_MATRIX * mat4(vec4(sc.x, 0.0, 0.0, 0.0), vec4(0.0, sc.y, 0.0, 0.0), vec4(0.0, 0.0, sc.z, 0.0), vec4(0.0, 0.0, 0.0, 1.0));
}

void fragment() {
	vec2 p = UV * 2.0 - 1.0;
	float a = clamp(1.0 - dot(p, p), 0.0, 1.0);
	a = a * a * a;
	float pl = 1.0 + pulse_speed * 0.25 * sin(TIME * pulse_speed + NODE_POSITION_WORLD.x * 3.0);
	ALBEDO = glow_color.rgb * intensity * pl;
	ALPHA = a;
}
