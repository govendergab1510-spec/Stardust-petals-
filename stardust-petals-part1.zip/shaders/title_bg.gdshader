shader_type canvas_item;
// Title screen backdrop: sunset-neon sky, moon, two skyline layers. One full-screen quad.

uniform float aspect = 2.2222;

float hash(float n) {
	return fract(sin(n * 91.345) * 47453.5453);
}
float hash2(vec2 p) {
	return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
}

float skyline(float x, float seed, float freq, float base, float amp) {
	float cell = floor(x * freq);
	return base + amp * hash(cell + seed);
}

void fragment() {
	vec2 uv = UV;
	float y = 1.0 - uv.y;
	vec3 top = vec3(0.02, 0.012, 0.10);
	vec3 mid = vec3(0.32, 0.09, 0.45);
	vec3 hor = vec3(1.0, 0.42, 0.55);
	vec3 col = mix(hor, mid, smoothstep(0.0, 0.38, y));
	col = mix(col, top, smoothstep(0.30, 0.95, y));

	// stars
	vec2 sp = vec2(uv.x * aspect, uv.y) * 70.0;
	float sr = hash2(floor(sp));
	float tw = 0.6 + 0.4 * sin(TIME * 2.0 + sr * 50.0);
	col += vec3(1.0) * step(0.985, sr) * tw * smoothstep(0.35, 0.8, y) * 0.8;

	// moon
	vec2 mp = (uv - vec2(0.73, 0.30)) * vec2(aspect, 1.0);
	float md = length(mp);
	col += vec3(1.0, 0.6, 0.85) * smoothstep(0.42, 0.0, md) * 0.30;
	col = mix(col, vec3(1.0, 0.96, 0.9), smoothstep(0.125, 0.12, md));

	// far skyline
	float h1 = skyline(uv.x, 3.0, 22.0, 0.22, 0.28);
	if (y < h1) {
		vec3 c = vec3(0.16, 0.07, 0.30);
		vec2 wcell = vec2(uv.x * 220.0, y * 70.0);
		float w = step(0.6, hash2(floor(wcell))) * step(0.3, fract(wcell.x)) * step(fract(wcell.x), 0.8) * step(0.3, fract(wcell.y)) * step(fract(wcell.y), 0.8);
		col = c + vec3(1.0, 0.7, 0.5) * w * 0.35;
	}
	// near skyline
	float h2 = skyline(uv.x, 11.0, 13.0, 0.10, 0.26);
	if (y < h2) {
		vec3 c = vec3(0.04, 0.02, 0.10);
		vec2 wcell = vec2(uv.x * 140.0, y * 46.0);
		float w = step(0.55, hash2(floor(wcell) + 7.0)) * step(0.25, fract(wcell.x)) * step(fract(wcell.x), 0.75) * step(0.25, fract(wcell.y)) * step(fract(wcell.y), 0.75);
		float k = hash2(floor(wcell) + 3.0);
		vec3 wc = k < 0.6 ? vec3(1.0, 0.8, 0.5) : (k < 0.8 ? vec3(0.3, 0.95, 1.0) : vec3(1.0, 0.3, 0.8));
		col = c + wc * w * 0.9;
	}
	// ground haze
	col += vec3(1.0, 0.3, 0.6) * smoothstep(0.12, 0.0, y) * 0.4;
	COLOR = vec4(col, 1.0);
}
