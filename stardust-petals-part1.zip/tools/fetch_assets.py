#!/usr/bin/env python3
"""Downloads the 3D model listed in tools/assets.json (run on GitHub's servers by the workflow)
and regenerates data/shino_blendshapes.json (lip-sync / expression map) from the VRM metadata.

Skips files that already exist. Exits with code 1 if the required download fails, so the build
never silently ships without its model.
"""
import json
import os
import struct
import sys
import time
import urllib.request

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def download(url: str, dest: str, retries: int = 4) -> bool:
    for attempt in range(1, retries + 1):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "stardust-petals-build"})
            with urllib.request.urlopen(req, timeout=120) as r, open(dest + ".part", "wb") as f:
                while True:
                    chunk = r.read(1 << 16)
                    if not chunk:
                        break
                    f.write(chunk)
            os.replace(dest + ".part", dest)
            return True
        except Exception as e:  # noqa: BLE001
            print(f"  attempt {attempt}/{retries} failed: {e}")
            time.sleep(2 * attempt)
    return False


def write_blendshape_map(vrm_path: str) -> None:
    """VRM0 files keep the mouth/eye expressions in JSON metadata that Godot ignores; extract them."""
    with open(vrm_path, "rb") as f:
        b = f.read()
    clen, _ = struct.unpack("<I4s", b[12:20])
    j = json.loads(b[20:20 + clen])
    vrm = j.get("extensions", {}).get("VRM")
    if not vrm:
        print("  (no VRM0 metadata found, keeping existing blendshape map)")
        return
    out = {}
    for g in vrm["blendShapeMaster"]["blendShapeGroups"]:
        binds = [
            {"mesh": j["meshes"][bd["mesh"]]["name"].replace(".baked", ""), "index": bd["index"], "weight": bd["weight"] / 100.0}
            for bd in g["binds"]
        ]
        if binds:
            out[g["name"].lower()] = binds
    path = os.path.join(ROOT, "data", "shino_blendshapes.json")
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(out, f, indent=1)
    print(f"  wrote {path} ({len(out)} expressions)")


def main() -> int:
    with open(os.path.join(ROOT, "tools", "assets.json"), encoding="utf-8") as f:
        manifest = json.load(f)
    failed = 0
    for a in manifest["assets"]:
        dest = os.path.join(ROOT, a["dest"])
        os.makedirs(os.path.dirname(dest), exist_ok=True)
        if os.path.exists(dest) and os.path.getsize(dest) >= a.get("min_bytes", 1):
            print(f"[cached]   {a['name']} ({os.path.getsize(dest) // 1024} KB)")
        else:
            print(f"[download] {a['name']} <- {a['url']}")
            if download(a["url"], dest) and os.path.getsize(dest) >= a.get("min_bytes", 1):
                print(f"           ok, {os.path.getsize(dest) // 1024} KB  ({a['license']})")
            else:
                print(f"::error::could not download {a['name']}")
                failed += 1
                continue
        if dest.endswith("Shino.glb"):
            write_blendshape_map(dest)
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
