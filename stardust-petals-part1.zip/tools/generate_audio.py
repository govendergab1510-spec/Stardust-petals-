#!/usr/bin/env python3
"""Generates voice lines + sound effects with the ElevenLabs API - ONLY what is missing.

Everything lives in data/story.json. Each clip is cached in assets/audio/ together with a hash of the
text / voice / settings in assets/audio/cache_index.json. The GitHub workflow commits those files back to
your repo, so every later build re-uses them and spends ZERO API credits unless you change a line.

Environment:
  ELEVENLABS_API_KEY   required (store it as a GitHub Actions secret). Without it the script exits cleanly
                       and the game simply builds without sound.
  ELEVEN_MAX_NEW       safety cap of new clips per run (default 80)
  FORCE=1              regenerate everything
  ELEVEN_API_BASE      override the API host (used by tests)
"""
import hashlib
import json
import os
import sys
import time
import urllib.error
import urllib.request

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
AUDIO = os.path.join(ROOT, "assets", "audio")
INDEX = os.path.join(AUDIO, "cache_index.json")
BASE = os.environ.get("ELEVEN_API_BASE", "https://api.elevenlabs.io").rstrip("/")
KEY = os.environ.get("ELEVENLABS_API_KEY", "").strip()
MAX_NEW = int(os.environ.get("ELEVEN_MAX_NEW", "80"))
FORCE = os.environ.get("FORCE") == "1"


def set_output(name: str, value: str) -> None:
    path = os.environ.get("GITHUB_OUTPUT")
    if path:
        with open(path, "a", encoding="utf-8") as f:
            f.write(f"{name}={value}\n")


def sha(obj) -> str:
    return hashlib.sha1(json.dumps(obj, sort_keys=True).encode("utf-8")).hexdigest()[:16]


class QuotaExceeded(Exception):
    pass


def request(path: str, body=None, method="POST"):
    data = json.dumps(body).encode("utf-8") if body is not None else None
    headers = {"xi-api-key": KEY, "Accept": "audio/mpeg" if method == "POST" else "application/json"}
    if data:
        headers["Content-Type"] = "application/json"
    for attempt in range(1, 5):
        req = urllib.request.Request(BASE + path, data=data, headers=headers, method=method)
        try:
            with urllib.request.urlopen(req, timeout=120) as r:
                return r.read()
        except urllib.error.HTTPError as e:
            msg = e.read()[:300].decode("utf-8", "replace")
            if e.code == 429 or e.code >= 500:
                wait = 3 * attempt
                print(f"    HTTP {e.code}, retrying in {wait}s")
                time.sleep(wait)
                continue
            if e.code in (401, 402):
                raise QuotaExceeded(f"HTTP {e.code}: {msg}")
            raise RuntimeError(f"HTTP {e.code}: {msg}")
        except urllib.error.URLError as e:
            print(f"    network error: {e}; retrying")
            time.sleep(3 * attempt)
    raise RuntimeError("giving up after retries")


_fallback_voices = {}


def fallback_voice(gender: str) -> str:
    """If a configured voice id no longer exists, pick the first available voice with the same gender."""
    if gender in _fallback_voices:
        return _fallback_voices[gender]
    voices = json.loads(request("/v1/voices", method="GET")).get("voices", [])
    pick = next((v for v in voices if v.get("labels", {}).get("gender") == gender), voices[0] if voices else None)
    if not pick:
        raise RuntimeError("no voices available on this account")
    _fallback_voices[gender] = pick["voice_id"]
    print(f"    using fallback voice {pick.get('name')} ({gender})")
    return pick["voice_id"]


def make_voice(job) -> bytes:
    body = {"text": job["text"], "model_id": job["model"], "voice_settings": job["settings"]}
    vid = job["voice_id"]
    try:
        return request(f"/v1/text-to-speech/{vid}?output_format=mp3_22050_32", body)
    except RuntimeError as e:
        if any(code in str(e) for code in ("HTTP 400", "HTTP 404", "HTTP 422")):
            vid = fallback_voice(job["gender"])
            return request(f"/v1/text-to-speech/{vid}?output_format=mp3_22050_32", body)
        raise


def make_sfx(job) -> bytes:
    body = {"text": job["text"], "duration_seconds": job["duration"], "prompt_influence": 0.5}
    return request("/v1/sound-generation?output_format=mp3_44100_64", body)


def main() -> int:
    with open(os.path.join(ROOT, "data", "story.json"), encoding="utf-8") as f:
        story = json.load(f)
    model = story.get("tts_model", "eleven_turbo_v2_5")
    jobs = []
    for scene in story["scenes"].values():
        for line in scene:
            v = story["voices"][line["who"]]
            jobs.append({
                "kind": "voice", "id": line["id"], "path": f"voice/{line['id']}.mp3", "text": line["text"],
                "voice_id": v["voice_id"], "gender": v.get("gender", "female"), "settings": v["settings"], "model": model,
            })
    for sid, s in story["sfx"].items():
        jobs.append({"kind": "sfx", "id": sid, "path": f"sfx/{sid}.mp3", "text": s["prompt"], "duration": s["duration"]})

    os.makedirs(os.path.join(AUDIO, "voice"), exist_ok=True)
    os.makedirs(os.path.join(AUDIO, "sfx"), exist_ok=True)
    index = {}
    if os.path.exists(INDEX):
        with open(INDEX, encoding="utf-8") as f:
            index = json.load(f)

    todo = []
    for j in jobs:
        fp = {k: j[k] for k in ("kind", "text", "voice_id", "settings", "model", "duration") if k in j}
        j["hash"] = sha(fp)
        have = os.path.exists(os.path.join(AUDIO, j["path"])) and os.path.getsize(os.path.join(AUDIO, j["path"])) > 500
        if FORCE or not have or index.get(j["id"]) != j["hash"]:
            todo.append(j)
    chars = sum(len(j["text"]) for j in todo if j["kind"] == "voice")
    print(f"audio: {len(jobs)} clips defined, {len(jobs) - len(todo)} cached in the repo, {len(todo)} to generate (~{chars} voice characters)")

    if not todo:
        set_output("changed", "false")
        return 0
    if not KEY:
        print("ELEVENLABS_API_KEY is not set -> skipping audio generation (the game builds without sound).")
        set_output("changed", "false")
        return 0

    made = 0
    for j in todo[:MAX_NEW]:
        print(f"  [{j['kind']}] {j['id']}: {j['text'][:60]!r}")
        try:
            audio = make_voice(j) if j["kind"] == "voice" else make_sfx(j)
        except QuotaExceeded as e:
            print(f"::warning::ElevenLabs refused the request ({e}). Keeping what was generated so far.")
            break
        except Exception as e:  # noqa: BLE001
            print(f"::warning::could not generate {j['id']}: {e}")
            continue
        with open(os.path.join(AUDIO, j["path"]), "wb") as f:
            f.write(audio)
        index[j["id"]] = j["hash"]
        made += 1
        time.sleep(0.4)
    if len(todo) > MAX_NEW:
        print(f"::notice::{len(todo) - MAX_NEW} clips left for the next run (ELEVEN_MAX_NEW={MAX_NEW}).")
    with open(INDEX, "w", encoding="utf-8") as f:
        json.dump(index, f, indent=1, sort_keys=True)
    print(f"generated {made} new clips")
    set_output("changed", "true" if made else "false")
    return 0


if __name__ == "__main__":
    sys.exit(main())
