# Stardust Petals - Chapter 1: "An Ordinary Day"  (part 1 of 10)

A cozy anime story adventure built with Godot 4.4 for budget Android phones (made for a Samsung Galaxy A05s).
You play **Shino**, a 19-year-old florist's assistant in the everyday city of Hoshigaoka. Shino speaks first,
tells you about her life, then you deliver five bouquets to the neighbours on the day of the Lantern Festival.
The day turns from morning to sunset to night, and something small and strange happens when the first lantern is lit.

## Build it on GitHub (from your phone)
1. Put this zip in the root of your GitHub repo (**Add file -> Upload files**).
2. Create the file `.github/workflows/build.yml` and paste the `build.yml` you were given (**Add file -> Create new file**).
3. *(Optional, for voice + sound)* Settings -> Secrets and variables -> Actions -> **New repository secret**:
   name `ELEVENLABS_API_KEY`, value = your ElevenLabs key. Never put the key inside the game files.
4. Actions tab -> **Build Stardust Petals** -> **Run workflow**.
   First run takes about 10-15 minutes (downloads Godot, templates and the model); later runs are much faster.
5. Open the finished run -> **Artifacts -> StardustPetals-APK** -> download, unzip, install.

The workflow downloads Godot, the Android templates and the 3D model on GitHub's servers, generates the voice and
sound effects, commits them back into `assets/audio/` (so they are **never generated twice**), signs and builds the APK.
If a build shows no sound, check that the secret exists and look at the "Generate missing ElevenLabs audio" step.

## Controls
- Left thumb: move. Right side of the screen: look around. **JUMP** button. **TALK** button appears next to people.
- Tap anywhere to continue dialogue. (Desktop: WASD / arrows, Space, E, mouse drag.)

## Performance notes
- Compatibility (OpenGL ES 3) renderer, renders at 1280x576 and is scaled to your screen, 60 FPS cap, no shadows,
  no post-processing, one light, props baked into a few meshes, glow faked with additive billboards.
- The heroine's hair and skin were merged from ~100 draw calls to ~27. Typical scene: 55-100 draw calls.
- Weak phone? Open `scripts/game.gd` and set `OUTLINES := false` (removes the character outlines, ~40% fewer triangles).

## Editing the story
Everything (lines, speakers, emotions, voices, sound effects) is in `data/story.json`. Change a line, push, and only that
line is regenerated (`tools/generate_audio.py` hashes every clip).

## Later chapters
Buildings you can walk into are planned: each interior will be its own small scene behind a door, so the city stays cheap.
The other CC0 VRoid characters (Vita, Vivi, Victoria Rubin) can be used for more main characters.

See `CREDITS.md` for licences.
